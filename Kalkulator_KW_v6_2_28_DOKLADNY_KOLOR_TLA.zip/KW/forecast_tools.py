"""Read-only planning functions for optional payroll preview features.

All values remain ESTIMATES. Do not write simulation rows, projected allowances
or YTD figures to the existing database. They are neither payslip amounts nor
verified payroll history.
"""
from __future__ import annotations

import datetime as dt
import math
from collections import defaultdict
from work_card_policy import MIN_CARD_YEAR, supported_date, card_week_from_name, year_from_parent
from company_calendar import day_category
from eu_travel_policy import travel_type_issue

HOUR_KEYS = ('N', 'A', 'B', 'PN', 'P', 'T')
ONE_TIME_FIELDS = ('car_bonus_count', 'shared_room_nights', 'domestic_diet_extra_days',
                   'risk_days', 'other_gross', 'ppe_employer_override',
                   'ppo_employer_override', 'offshore_manual_days')


def _float(value, default=0.0):
    try:
        v = float(value)
        return v if math.isfinite(v) else default
    except (ValueError, TypeError):
        return default


def simulation_result(rows, cfg, calc, overtime_a=0.0, overtime_b=0.0,
                      date=None):
    """Return baseline/new results and net difference; never mutate inputs.

    Date is used solely to obtain the historic work-date hourly rate; the
    synthetic extra hours have no offshore/travel/leave flags.
    """
    a = _float(overtime_a, -1)
    b = _float(overtime_b, -1)
    if not (0 <= a <= 200 and 0 <= b <= 200 and a + b <= 300):
        raise ValueError('Dodatkowe godziny A i B muszą być od 0 do 200 (łącznie do 300).')
    old = calc(rows, cfg)
    if not date:
        date = f"{int(cfg.get('_tax_year', dt.date.today().year)):04d}-06-15"
    dt.date.fromisoformat(date)
    new_rows = list(rows)
    if a or b:
        new_rows.append({'date': date, 'N': 0.0, 'A': a, 'B': b,
                         'PN': 0.0, 'P': 0.0, 'T': 0.0, 'work_type': None,
                         'offshore': False, 'leave_code': False})
    new = calc(new_rows, cfg)
    return {'base': old, 'new': new, 'difference_net': round(new[10] - old[10], 2),
            'difference_gross': round(new[4] - old[4], 2),
            'a': a, 'b': b, 'date': date}


def hypothetical_month_result(period, cfg, calc, overtime_a, overtime_b, travel_hours,
                              offshore_days=0, night_hours=0, shared_room_nights=0,
                              diet_days=0, eu_c_allowance=0., zfss_cash=0.):
    """Independent salary scenario with explicit allowances and no card imports.

    N comes ONLY from the calendar-month nominal. A/B/paid travel and night
    hours are manual totals; PN is an overlapping supplement, not extra hours.
    Offshore is represented by distinct code-9 dates to use the same payroll
    calculation as imported cards. One-off settings are explicitly overridden
    so historical extras are never silently added to a standalone simulation.
    No rows or config values are written to the actual user database.
    """
    raw=(overtime_a,overtime_b,travel_hours,offshore_days,night_hours,
         shared_room_nights,diet_days)
    try:
        a,b,t,d,night,shared,diet=map(float,raw)
    except (TypeError,ValueError,OverflowError) as exc:
        raise ValueError('Wpisz poprawne liczby godzin oraz dni.') from exc
    if any(not math.isfinite(v) or v < 0 or v > 500 for v in (a,b,t,night)):
        raise ValueError('Godziny A, B, PN i podróży muszą mieścić się między 0 a 500.')
    if any(not math.isfinite(v) or v < 0 or v != int(v) for v in (d,shared,diet)):
        raise ValueError('Liczba dni offshore, nocy w kabinie i dni diety musi być nieujemną liczbą całkowitą.')
    year,month=map(int,period.split('-'))
    month_days=__import__('calendar').monthrange(year,month)[1]
    if d>month_days or shared>month_days or diet>month_days:
        raise ValueError(f'Dla {period} można wpisać najwyżej {month_days} dni lub nocy.')
    nominal=float(cfg.get('nominal',0))
    if not math.isfinite(nominal) or nominal<=0 or float(cfg.get('salary',0))<=0:
        raise ValueError('Brak dodatniej pensji zasadniczej lub nominału godzin dla miesiąca.')
    workday=next((dt.date(year,month,day) for day in range(1,month_days+1)
                  if dt.date(year,month,day).weekday()<5),None)
    freeday=next((dt.date(year,month,day) for day in range(1,month_days+1)
                  if dt.date(year,month,day).weekday()==5),None)
    if not workday or not freeday:
        raise ValueError('Brak odpowiednich dni w kalendarzu')
    rows=[{'date':workday.isoformat(),'N':0.0,'A':a,'B':b,
           'PN':night,'P':0.,'T':0.,'work_type':1,
           'offshore':False,'leave_code':False}]
    if t:
        rows.append({'date':freeday.isoformat(),'N':0.,'A':0.,'B':0.,
                     'PN':0.,'P':0.,'T':t,'work_type':2,
                     'offshore':False,'leave_code':False})
    for day in range(1,int(d)+1):
        rows.append({'date':dt.date(year,month,day).isoformat(),
                     'N':0.,'A':0.,'B':0.,'PN':0.,'P':0.,'T':0.,
                     'work_type':9,'offshore':True,'leave_code':False})
    scenario_cfg=dict(cfg)
    scenario_cfg['_leave_variable_pay']=0.0
    for key in ONE_TIME_FIELDS:
        scenario_cfg[key]=-1 if key=='offshore_manual_days' else 0
    scenario_cfg['shared_room_nights']=int(shared)
    scenario_cfg['domestic_diet_extra_days']=int(diet)
    from special_payments import amount
    scenario_cfg['eu_c_allowance']=amount(eu_c_allowance)
    scenario_cfg['zfss_cash']=amount(zfss_cash)
    result=calc(rows,scenario_cfg)
    return {'rows':rows,'cfg':scenario_cfg,'result':result,'nominal':nominal,
            'a':a,'b':b,'travel':t,'offshore_days':int(d),
            'night_hours':night,'shared_room_nights':int(shared),
            'diet_days':int(diet),'eu_c_allowance':scenario_cfg['eu_c_allowance'],
            'zfss_cash':scenario_cfg['zfss_cash'],'period':period}


def yearly_projection(year, db, config_for_month, calc, accounting_month,
                      leave_for_rows=None, today=None):
    """Compute a sequential hypothetical year using stored cards and settings.

    A month without cards is modelled using fixed base pay, not claimed as an
    actual payment. One-off bonuses are zeroed for UNRECORDED FUTURE months.
    Optional verified closing YTD balances, if already stored, are respected.
    """
    today = today or dt.date.today()
    year = int(year)
    excluded = set(db.get('excluded_files') or [])
    grouped = defaultdict(list)
    for row in db.get('rows') or []:
        if row.get('file_id') in excluded or not supported_date(row.get('date')):
            continue
        try:
            period = accounting_month(row.get('date', ''), db)
        except (ValueError, TypeError, KeyError):
            continue
        if period and period.startswith(f'{year:04d}-'):
            grouped[period].append(row)
    out = []
    tax_ytd = social_ytd = 0.0
    anchors = db.get('payslip_balances') or {}
    for month in range(1, 13):
        period = f'{year:04d}-{month:02d}'
        rows = grouped.get(period, [])
        future = (year, month) > (today.year, today.month)
        no_cards = not rows
        entry = {'period': period, 'cards': len({r.get('file_id') for r in rows}),
                 'rows': len(rows), 'future': future, 'no_cards': no_cards,
                 'status': '', 'result': None, 'taxable': 0.0, 'warning': ''}
        try:
            raw = config_for_month(period, _skip_progress=True)
            cfg = dict(raw)
            if cfg.get('salary', 0) <= 0 or cfg.get('nominal', 0) <= 0:
                entry['status'] = 'Brak parametrów'
            else:
                if future and no_cards:
                    # Recurring base pay can be estimated, but an earlier
                    # one-off car/risk award must not recur by assumption.
                    for name in ONE_TIME_FIELDS:
                        cfg[name] = -1 if name == 'offshore_manual_days' else 0
                cfg['ytd_tax_base'] = tax_ytd
                cfg['social_ytd'] = social_ytd
                cfg['_leave_variable_pay'] = 0.0

                def rate_for_date(day):
                    try:
                        source_period = accounting_month(day, db) or day[:7]
                        prior = config_for_month(source_period, _skip_progress=True)
                        nominal = _float(prior.get('nominal', 0))
                        return _float(prior.get('salary', 0)) / nominal if nominal else 0.0
                    except (ValueError, KeyError, TypeError):
                        return 0.0

                cfg['_rate_for_date'] = rate_for_date
                if leave_for_rows and rows and any(r.get('leave_code') or r.get('work_type') == 6 for r in rows):
                    leave = leave_for_rows(rows)
                    if leave.get('complete'):
                        cfg['_leave_variable_pay'] = _float(leave.get('variable_amount', 0))
                        if leave.get('estimated'):
                            entry['warning'] = 'Zmienna część urlopu jest szacunkowa'
                    else:
                        entry['warning'] = 'Brak pełnej podstawy urlopowej'
                result = calc(rows, cfg)
                entry['result'] = result
                entry['taxable'] = result[7]
                entry['status'] = ('Przyszły — baza' if future and no_cards else
                                   'Bez kart — baza' if no_cards else
                                   'Przyszły — karty' if future else 'Z kart — szacunek')
                tax_ytd += result[7]
                benefits = (_float(cfg.get('edenred_benefit', 0)) +
                            _float(cfg.get('luxmed_benefit', 0))) * _float(cfg.get('benefits_in_social', 1))
                social_ytd += result[4] - _float(cfg.get('zfss_cash',0)) + benefits
        except Exception as exc:
            entry['status'] = 'Brak prognozy'
            entry['warning'] = str(exc)
        # An explicitly recorded closing balance is an optional YTD anchor
        # for the NEXT month, not proof that this month's forecast is actual.
        anchor = anchors.get(period)
        if isinstance(anchor, dict):
            # Confirmed PIT and ZUS opening balances can be entered separately.
            try:
                if 'tax' in anchor:
                    tax_ytd=max(0.0,float(anchor['tax']))
                if 'social' in anchor:
                    social_ytd=max(0.0,float(anchor['social']))
            except (ValueError, TypeError):
                pass
        out.append(entry)
    return out


def validate_cards(db, accounting_month, read_source=None, year=None):
    """Non-destructive validation of meaningful rows from the current calendar year.

    Empty three-row template slots are already omitted by read_xlsx. Missing
    values must be distinguished from legitimate zero hours on leave/off days.
    """
    year = dt.date.today().year if year is None else int(year)
    def current_year_row(row):
        try:
            return dt.date.fromisoformat(str(row.get('date') or '')[:10]).year == year
        except (ValueError, TypeError):
            return False

    excluded = set(db.get('excluded_files') or [])
    issues = []
    seen_ids = set()
    day_hours = defaultdict(float)
    unknown_periods = set()
    active = 0
    # The old N/A/B/PN distribution audit is disabled by user preference.
    # The return key stays at zero for compatibility with earlier UI versions.
    unchecked_clock_rows = 0
    source_cache = {}
    incomplete_sources = set()
    # Leave and days off are allowed to have zero working/travel hours.
    non_work_types = {5, 6}
    # Decide whether a date has work using ALL rows from that date. A dated
    # template row can be empty while another row on the same date has hours.
    # Do not report such placeholder rows as missing work.
    date_rows = defaultdict(list)
    for item in db.get('rows') or []:
        if item.get('file_id') in excluded or not current_year_row(item) or not supported_date(item.get('date')):
            continue
        try:
            day = dt.date.fromisoformat(str(item.get('date')))
        except (TypeError, ValueError):
            continue
        date_rows[day].append(item)
    date_has_hours = {}
    date_has_absence = {}
    date_has_work_assignment = {}
    for day, items in date_rows.items():
        date_has_hours[day] = any(
            any(_float(item.get(key)) > 0 for key in HOUR_KEYS)
            for item in items)
        date_has_absence[day] = any(item.get('work_type') in non_work_types
                                    for item in items)
        # An empty weekday can be an authorized day at home between service
        # assignments (FSE Annex 1, section I). The company calendar alone
        # cannot tell if a specific engineer was assigned work that day.
        date_has_work_assignment[day] = any(
            (item.get('work_type') is not None and item.get('work_type') not in non_work_types)
            or bool(str(item.get('job') or '').strip())
            or str(item.get('sea_work_raw') or '').strip().upper() == 'TAK'
            for item in items)
    checked_missing_days = set()
    # Keep imported values unchanged. The checker no longer re-reads source
    # clocks or assesses how N/A/B/PN were split within a shift. Source-card
    # fallback for other checks (e.g. sea-work column O) is retained below.
    enriched_rows=[r for r in db.get('rows') or []
                   if current_year_row(r) and r.get('file_id') not in excluded]

    def add(level, item, description):
        issues.append({'level': level,
                       'file': str(item.get('file') or item.get('source_path') or '—'),
                       'date': str(item.get('date') or '—'),
                       'row': item.get('row'),
                       'source_path': str(item.get('source_path') or ''),
                       'message': description})

    for row in enriched_rows:
        if row.get('file_id') in excluded or not current_year_row(row) or not supported_date(row.get('date')):
            continue
        active += 1
        date = str(row.get('date') or '')
        try:
            day = dt.date.fromisoformat(date)
        except (ValueError, TypeError):
            add('BŁĄD', row, 'Nieprawidłowa data w karcie pracy')
            continue

        # The filename's KPnn is an ISO week number. Never infer it from an
        # arbitrary job number or from the numeric part of the employee name.
        week = card_week_from_name(row.get('file') or row.get('source_path') or '')
        if week is not None and day.isocalendar().week != week:
            add('BŁĄD', row, f'Data należy do tygodnia ISO W{day.isocalendar().week:02d}, '
                              f'a nazwa karty wskazuje KP{week:02d} (wiersz {row.get("row", "?")})')

        signature_id = (row.get('file_id'), row.get('row'), date)
        if row.get('row') is not None and signature_id in seen_ids:
            add('BŁĄD', row, 'Powtórzony numer wiersza Excel w tej samej karcie i dniu')
        seen_ids.add(signature_id)

        values = []
        for key in HOUR_KEYS:
            try:
                value = float(row.get(key, 0) or 0)
            except (ValueError, TypeError):
                value = float('nan')
            if not math.isfinite(value) or value < 0 or value > 24:
                add('BŁĄD', row, f'Nieprawidłowa wartość godzin {key}: {row.get(key)}')
            values.append(value)
        total = sum(values[:3])+sum(values[4:])  # PN overlaps N/A/B
        if math.isfinite(total):
            day_hours[date] += total
            if total > 24.0001:
                add('UWAGA', row, f'Łącznie {total:g} h w jednym wierszu (> 24 h)')
            # Annex 1 sets a 13-hour CONTINUOUS-work limit. Across multiple
            # rows we cannot infer continuity/rest, so flag only a single
            # individual row above 13 hours as an advisory check.
            work_hours = sum(values[:3])
            if work_hours > 13.0001:
                add('UWAGA', row, f'{work_hours:g} h pracy w jednym wpisie — '
                                  'sprawdź, czy zachowano limit 13 h ciągłej pracy '
                                  'bez odpoczynku (regulamin FSE)')

        # Do not evaluate the correctness of the N/A/B/PN distribution.
        # Values remain available unmodified to all payroll calculations.

        kind = row.get('work_type')
        raw_kind = str(row.get('work_type_raw') or '').strip()
        planned_workday = day_category(day) == 'workday'
        day_is_worked = date_has_hours[day]
        day_is_absence = date_has_absence[day]
        # Saturday, Sunday, statutory/company holiday: no hours means a
        # legitimate free day. On a scheduled weekday, absence codes 5 (paid
        # day off) and 6 (leave) also legitimately have no working hours.
        if (planned_workday and not day_is_worked and not day_is_absence
                and date_has_work_assignment[day]
                and day not in checked_missing_days):
            add('BŁĄD', row, 'Brak wpisanych godzin przy oznaczonym zadaniu/pracy '
                            'w dniu roboczym (sprawdź kartę)')
            checked_missing_days.add(day)

        # A blank weekday with no assignment is NOT proof of missing hours.
        # Conversely, a declared job with no hours merits a genuine warning.
        work_entry = math.isfinite(total) and total > 0 and kind not in non_work_types
        coded_empty_workday = (planned_workday and not day_is_worked
                               and date_has_work_assignment[day]
                               and kind not in non_work_types)
        check_work_fields = work_entry or coded_empty_workday
        # Work-card legend + EU Annex 5: only explicitly recorded travel
        # to one of five listed countries is eligible for this code check.
        # No inference is made from non-travel assignments or nearby dates.
        travel_issue = travel_type_issue(row, day)
        if travel_issue:
            add(travel_issue[0], row, travel_issue[1])
        if kind is None:
            if raw_kind:
                add('BŁĄD', row, f'Niepoprawny typ pracy: {raw_kind!r}')
            elif check_work_fields and not travel_issue:
                add('UWAGA', row, 'Brak wpisanego typu pracy (kolumna N)')
        if row.get('needs_type_refresh') and check_work_fields:
            add('UWAGA', row, 'Historyczny wpis bez potwierdzonego typu pracy')

        # Legacy imports did not preserve raw O values; those cards require
        # re-import before an empty O can be diagnosed without false alerts.
        # For cards imported with older software, column O was reduced to
        # a boolean, so an absent value cannot be distinguished from NIE.
        # Re-read only such source workbooks (once per file), without writing
        # anything back to the database or changing calculation results.
        raw_sea_present = 'sea_work_raw' in row
        raw_sea_value = row.get('sea_work_raw')
        if check_work_fields and not raw_sea_present and read_source is not None and row.get('source_path'):
            path = str(row['source_path'])
            if path not in source_cache:
                try:
                    from pathlib import Path
                    source_cache[path] = {r.get('row'):r for r in read_source(Path(path))}
                except (OSError, ValueError, KeyError, TypeError):
                    source_cache[path] = None
            match = (source_cache[path] or {}).get(row.get('row'))
            if match and match.get('date') == row.get('date') and 'sea_work_raw' in match:
                raw_sea_value = match['sea_work_raw']
                raw_sea_present = True
        if raw_sea_present:
            sea = str(raw_sea_value or '').strip().upper()
            if check_work_fields and not sea:
                add('UWAGA', row, 'Brak oznaczenia Praca w morzu (TAK/NIE, kolumna O)')
            elif sea and sea not in ('TAK', 'NIE'):
                add('BŁĄD', row, 'Nieprawidłowe oznaczenie Praca w morzu: '+sea)
        if (check_work_fields and not raw_sea_present
                and row.get('file_id') not in incomplete_sources):
            incomplete_sources.add(row.get('file_id'))
            add('UWAGA',row,'Nie można zweryfikować kolumny Praca w morzu — odśwież plik Excel')
        if check_work_fields and not str(row.get('job') or '').strip():
            add('UWAGA', row, 'Brak nazwy instalacji / numeru instalacji (kolumna Q)')

        try:
            # Do not require payroll-period assignment for a genuinely free
            # date with no work. This avoids old-year holiday/weekend noise.
            if (day_is_worked or (planned_workday and date_has_work_assignment[day])) and accounting_month(date, db) is None:
                week_year, iso_week, _ = day.isocalendar()
                if (week_year, iso_week) not in unknown_periods:
                    unknown_periods.add((week_year, iso_week))
                    add('UWAGA', row, f'Tydzień ISO {week_year}/W{iso_week:02d} nie jest przypisany do okresu rozliczeniowego')
        except (ValueError, KeyError, TypeError):
            add('UWAGA', row, 'Nie można przypisać wpisu do okresu rozliczeniowego')

    for date, total in sorted(day_hours.items()):
        if math.isfinite(total) and total > 24.0001:
            issues.append({'level': 'UWAGA', 'file': 'Wiele wpisów', 'date': date,
                           'row': None, 'source_path': '',
                           'message': f'Suma godzin tego dnia to {total:g} h — sprawdź nakładające się karty'})
    return {'year': year, 'active_rows': active, 'unchecked_clock_rows': unchecked_clock_rows, 'issues': issues,
            'errors': sum(i['level'] == 'BŁĄD' for i in issues),
            'warnings': sum(i['level'] == 'UWAGA' for i in issues)}
