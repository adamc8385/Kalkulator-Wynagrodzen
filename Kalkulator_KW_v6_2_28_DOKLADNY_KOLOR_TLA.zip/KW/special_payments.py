"""Locally saved, month-of-payment-only manual supplements.

Neither allowance is a recurring rate.  A missing period is zero rather than
inheritance of the last saved payroll settings. No external sync is used.
ZFSS model: cash benefits wholly funded from ZFSS and granted using social
criteria. Other benefits/vouchers need separate tax treatment; do not enter.
"""
import math
import re
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

FIELDS=('eu_c_allowance','zfss_cash')
ZFSS_PIT_EXEMPT_ANNUAL=1000.00
PERIOD=re.compile(r'^\d{4}-(0[1-9]|1[0-2])$')


def amount(value):
    """Strict nonnegative cents for saved user amounts."""
    try:
        raw=Decimal(str(value).replace(' ', '').replace(',', '.'))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError('Dodatek C i ZFŚS wymagają kwot liczbowych brutto.') from exc
    if not raw.is_finite() or raw<0 or raw>10000000:
        raise ValueError('Dodatek C i ZFŚS: wpisz kwotę od 0 do 10 000 000 zł.')
    return float(raw.quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))


def get_month(db, period):
    if not PERIOD.fullmatch(str(period)):
        raise ValueError('Nieprawidłowy miesiąc wypłaty')
    data=db.get('monthly_special_payments') or {}
    record=data.get(period) if isinstance(data,dict) else None
    if not isinstance(record,dict):record={}
    return {name:amount(record.get(name,0)) for name in FIELDS}


def save_month(db, period, values):
    if not PERIOD.fullmatch(str(period)):
        raise ValueError('Nieprawidłowy miesiąc wypłaty')
    values={name:amount(values[name]) for name in FIELDS}
    mapping=db.setdefault('monthly_special_payments',{})
    if not isinstance(mapping,dict):raise ValueError('Nieprawidłowe dane dodatków miesięcznych')
    if any(values.values()):mapping[period]=values
    else:mapping.pop(period,None)
    return values


def zfss_prior(db, period):
    """Only locally entered qualifying benefits paid in the same tax year."""
    if not PERIOD.fullmatch(str(period)):
        raise ValueError('Nieprawidłowy miesiąc wypłaty')
    mapping=db.get('monthly_special_payments') or {}
    if not isinstance(mapping,dict):return 0.0
    prefix=period[:4]+'-'
    total=Decimal('0')
    for key,record in mapping.items():
        if isinstance(key,str) and key.startswith(prefix) and key<period and PERIOD.fullmatch(key) and isinstance(record,dict):
            total+=Decimal(str(amount(record.get('zfss_cash',0))))
    return float(total.quantize(Decimal('0.01')))


def zfss_tax_split(current,prior):
    current=amount(current)
    prior=amount(prior)
    free=max(0., ZFSS_PIT_EXEMPT_ANNUAL-prior)
    exempt=round(min(current,free),2)
    taxable=round(current-exempt,2)
    return exempt,taxable
