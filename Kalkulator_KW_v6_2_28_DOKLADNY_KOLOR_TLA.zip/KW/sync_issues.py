"""Persistent, inspectable report for work-card synchronization problems.

This module intentionally does not parse the source workbooks or suppress errors.
The check box controls *only automatic dialog visibility*.
"""
from __future__ import annotations

import os
import re
import sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

NAVY = '#071b2c'
PANEL = '#0a2439'
GOLD = '#f3b94e'
WHITE = '#f4f6fa'
MUTED = '#b7cbd8'


def normalize_issues(issues, configured_root=''):
    """Build JSON-safe entries, carrying path, year and detailed explanation.

    `errors` are produced by card_sync as an absolute path + ': ' + reason.
    Keep generic scan_root messages too, without inventing their locations.
    """
    root = Path(configured_root).expanduser() if configured_root else None
    normalized = []
    for raw in issues:
        if isinstance(raw, dict):
            normalized.append({k: str(raw.get(k) or '') for k in ('path', 'relative', 'year', 'message')})
            continue
        raw = str(raw)
        path = ''
        problem = raw
        # Windows 'C:\\...' is fine because separator includes a trailing space.
        if ': ' in raw:
            candidate, detail = raw.rsplit(': ', 1)
            if Path(candidate).suffix.lower() in ('.xlsx', '.xlsm', '.xls'):
                path, problem = candidate, detail
        if path:
            p = Path(path)
            relative = str(p)
            if root:
                try:
                    relative = str(p.relative_to(root))
                except ValueError:
                    pass
            year = next((part for part in p.parts if re.fullmatch(r'(?:19|20)\d{2}', part)), '')
        else:
            relative = ''
            year = ''
        normalized.append({'path': path, 'relative': relative, 'year': year, 'message': problem})
    return normalized


def show_sync_report(parent, issues, language='pl', initial_hidden=False):
    """Modal scrollable report. Returns desired 'hide future alerts' state."""
    english = language == 'en'
    labels = ({
        'title': 'Work-card synchronization', 'found': '{} issue(s) detected',
        'intro': 'These files could not be read. Other cards may still have synchronized.',
        'location': 'Year / file', 'reason': 'Problem', 'details': 'Selected problem and full path:',
        'folder': 'Open containing folder', 'close': 'Close',
        'hide': 'Hide — do not show automatically again',
        'missing': 'Select an item to view its exact location.',
        'not_found': 'The source directory is currently unavailable.',
    } if english else {
        'title': 'Synchronizacja kart pracy', 'found': 'Wykryto {} problemów',
        'intro': 'Nie udało się odczytać wskazanych plików. Pozostałe karty mogły zostać zsynchronizowane.',
        'location': 'Rok / plik', 'reason': 'Problem', 'details': 'Szczegóły i pełna ścieżka:',
        'folder': 'Otwórz folder karty', 'close': 'Zamknij',
        'hide': 'Ukryj — nie pokazuj więcej',
        'missing': 'Zaznacz pozycję, aby zobaczyć dokładną lokalizację.',
        'not_found': 'Folder źródłowy jest obecnie niedostępny.',
    })
    from ui_assets import schedule_navy_titlebar
    win = tk.Toplevel(parent)
    # Background and caption will match the current application theme.
    try:
        from ui_theme import register_popup
        register_popup(win,parent._app_instance)
    except AttributeError:pass
    schedule_navy_titlebar(win,background=NAVY,foreground="#ffffff")
    win.title(labels['title'])
    win.configure(bg=NAVY)
    win.geometry('880x590')
    win.minsize(630, 430)
    win.transient(parent)
    try:
        from ui_assets import set_window_icon
        set_window_icon(win)
    except (ImportError, OSError, tk.TclError):
        pass
    head = tk.Frame(win, bg=NAVY)
    head.pack(fill='x', padx=22, pady=(18, 10))
    tk.Label(head, text=labels['title'], font=('Segoe UI', 17, 'bold'), fg=GOLD, bg=NAVY).pack(anchor='w')
    tk.Label(head, text=labels['found'].format(len(issues)), font=('Segoe UI', 11, 'bold'), fg=WHITE, bg=NAVY).pack(anchor='w', pady=(8, 0))
    tk.Label(head, text=labels['intro'], wraplength=780, justify='left', font=('Segoe UI', 10), fg=MUTED, bg=NAVY).pack(anchor='w', pady=(4, 0))

    table_box = tk.Frame(win, bg=PANEL)
    table_box.pack(fill='both', expand=True, padx=20, pady=5)
    tree = ttk.Treeview(table_box, columns=('location', 'reason'), show='headings', selectmode='browse')
    tree.heading('location', text=labels['location'])
    tree.heading('reason', text=labels['reason'])
    tree.column('location', width=330, minwidth=210, stretch=False)
    tree.column('reason', width=420, minwidth=200, stretch=True)
    scroll = ttk.Scrollbar(table_box, orient='vertical', command=tree.yview)
    tree.configure(yscrollcommand=scroll.set)
    tree.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')
    records = list(issues)
    for n, item in enumerate(records):
        location = item.get('relative') or item.get('path') or ('—' if english else 'Problem ogólny')
        # Full relative path already contains the year when under a year folder.
        if item.get('year') and item['year'] not in Path(location).parts:
            location = item['year'] + ' / ' + location
        tree.insert('', 'end', iid=str(n), values=(location, item.get('message') or '—'))
    detail_frame = tk.Frame(win, bg=NAVY)
    detail_frame.pack(fill='x', padx=22, pady=(8, 4))
    tk.Label(detail_frame, text=labels['details'], fg=GOLD, bg=NAVY, font=('Segoe UI', 10, 'bold')).pack(anchor='w')
    details = tk.Text(detail_frame, height=3, wrap='word', font=('Consolas', 9), bg=PANEL, fg=WHITE,
                      relief='flat', padx=9, pady=7)
    details.pack(fill='x', pady=(5, 0))
    details.insert('1.0', labels['missing'])
    details.configure(state='disabled')
    def selected_record():
        current = tree.selection()
        return records[int(current[0])] if current else None
    def render_selection(_event=None):
        item = selected_record()
        if not item:
            return
        output = (item.get('path') or item.get('relative') or '') + '\n' + (item.get('message') or '')
        details.configure(state='normal')
        details.delete('1.0', 'end')
        details.insert('1.0', output.strip())
        details.configure(state='disabled')
    tree.bind('<<TreeviewSelect>>', render_selection)
    def open_folder():
        item = selected_record()
        if not item or not item.get('path'):
            return
        folder = Path(item['path']).parent
        if not folder.is_dir():
            messagebox.showwarning(labels['title'], labels['not_found'], parent=win)
            return
        try:
            if sys.platform == 'win32':
                os.startfile(str(folder))
            else:
                import subprocess
                subprocess.Popen(['open' if sys.platform == 'darwin' else 'xdg-open', str(folder)])
        except (OSError, RuntimeError) as exc:
            messagebox.showwarning(labels['title'], str(exc), parent=win)
    tree.bind('<Double-1>', lambda event: open_folder())
    if records:
        tree.selection_set('0')
        tree.see('0')
        render_selection()
    footer = tk.Frame(win, bg=NAVY)
    footer.pack(fill='x', padx=22, pady=(12, 18))
    hide = tk.BooleanVar(value=bool(initial_hidden))
    check = tk.Checkbutton(footer, text=labels['hide'], variable=hide, bg=NAVY, fg=WHITE,
                           activebackground=NAVY, activeforeground=WHITE, selectcolor=PANEL,
                           font=('Segoe UI', 10))
    check.pack(side='left')
    tk.Button(footer, text=labels['close'], command=win.destroy, bg=GOLD, fg=NAVY,
              activebackground='#ffd17e', font=('Segoe UI', 10, 'bold'), relief='flat',
              bd=0, padx=23, pady=8).pack(side='right', padx=(8, 0))
    tk.Button(footer, text=labels['folder'], command=open_folder, bg=PANEL, fg=WHITE,
              font=('Segoe UI', 10), relief='flat', bd=0, padx=12, pady=8).pack(side='right')
    win.bind('<Escape>', lambda _event: win.destroy())
    win.grab_set()
    parent.wait_window(win)
    return bool(hide.get())
