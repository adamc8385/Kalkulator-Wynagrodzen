"""Optional v6.2 forecast screens; existing tabs and payroll remain unchanged."""
from __future__ import annotations

import datetime as dt
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter import font as tkfont

from forecast_tools import yearly_projection, simulation_result, validate_cards
from ui_theme import register_popup as theme_popup

NAVY = '#081725'
PANEL = '#10293c'
PANEL2 = '#193a51'
GOLD = '#d8b16b'
WHITE = '#f2f6f9'
MUTED = '#aec0cd'
GREEN = '#138567'


def _t(app, pl, en):
    return en if app.language == 'en' else pl


def _popup(app, title, geometry='950x625', maximize=False, popup_surface=None):
    win = tk.Toplevel(app.root)
    theme_popup(win,app,keep_visible=True,popup_surface=popup_surface)
    win.title(title)
    win.configure(bg=NAVY)
    width, height = map(int, geometry.split('x'))
    app.root.update_idletasks()
    px = app.root.winfo_rootx() + max(0, (app.root.winfo_width() - width) // 2)
    py = app.root.winfo_rooty() + max(0, (app.root.winfo_height() - height) // 2)
    px = min(px, max(0, app.root.winfo_screenwidth() - width))
    py = min(py, max(0, app.root.winfo_screenheight() - height))
    win.geometry(f'{width}x{height}+{px}+{py}')
    win.minsize(640, 430)
    if not maximize:
        win.transient(app.root)
    else:
        # A modal Tk grab prevents normal minimization/taskbar interaction on
        # Windows. The validation report is read-only and can be modeless.
        win.resizable(True, True)
    try:
        from ui_assets import set_window_icon
        set_window_icon(win)
    except Exception:
        pass
    from ui_assets import set_navy_titlebar
    win.after_idle(lambda: set_navy_titlebar(win, background=NAVY, foreground=WHITE)
                   if win.winfo_exists() else None)
    # Explicit closure only: X / Zamknij; not Escape, FocusOut or parent click.
    # The resizable card-check report must behave like an ordinary Windows
    # window (minimize/maximize/restore). Other small dialogs remain modal.
    if not maximize:
        win.grab_set()
    return win


def _button(parent, caption, action, background=PANEL2):
    b = tk.Button(parent, text=caption, command=action, font=('Segoe UI', 10, 'bold'),
                  bg=background, fg=WHITE, activebackground=GOLD,
                  activeforeground=NAVY, relief='flat', bd=0, padx=15, pady=8,
                  cursor='hand2')
    return b


def attach_preview_tools(app, parent, include_pdf=False):
    bar = tk.Frame(parent, bg=PANEL, highlightbackground='#365b72', highlightthickness=1)
    bar.pack(fill='x', padx=3, pady=(0, 12))
    headline = _t(app, 'NOWOŚCI 6.2 — NARZĘDZIA TESTOWE', 'NEW IN 6.2 — PREVIEW TOOLS')
    tk.Label(bar, text=headline, bg=PANEL, fg=GOLD,
             font=('Segoe UI', 11, 'bold')).pack(anchor='w', padx=14, pady=(10, 7))
    actions = tk.Frame(bar, bg=PANEL)
    actions.pack(fill='x', padx=11, pady=(0, 11))
    _button(actions, _t(app, 'Rok w liczbach', 'Year overview'),
            lambda: open_year_overview(app)).pack(side='left', padx=3)
    _button(actions, _t(app, 'Symulator wynagrodzenia', 'Salary simulator'),
            lambda: open_overtime_simulator(app)).pack(side='left', padx=3)
    if include_pdf:
        _button(actions, _t(app, 'Eksport PDF', 'Export PDF'),
                lambda: export_current_month_pdf(app), GREEN).pack(side='left', padx=3)


def attach_card_validation(app, parent):
    bar = tk.Frame(parent, bg=NAVY)
    bar.pack(fill='x', padx=8, pady=(0, 7))
    _button(bar, _t(app, 'Sprawdź poprawność zaimportowanych kart', 'Validate imported work cards'),
            lambda: open_card_check(app), GREEN).pack(side='left')


def open_year_overview(app):
    from kalkulator_wynagrodzenia import calc, accounting_month, MONTHS
    year = int(app.month.get()[:4])
    title = _t(app, f'Rok {year} — prognoza wynagrodzeń', f'Year {year} — salary estimates')
    win = _popup(app, title, '1050x645')
    tk.Label(win, text=title, fg=GOLD, bg=NAVY,
             font=('Segoe UI', 19, 'bold')).pack(anchor='w', padx=19, pady=(17, 5))
    note = _t(app,
              'Szacunek na podstawie obecnych kart i ustawień. Puste miesiące: tylko wariant bazowy. '
              'Rzeczywiste terminy wypłat mogą zmienić PIT/ZUS.',
              'Estimate from work cards and settings. Months without cards use base-pay assumptions. '
              'Actual payment dates may change PIT/social deductions.')
    tk.Label(win, text=note, fg=MUTED, bg=NAVY, wraplength=970,
             justify='left', font=('Segoe UI', 10)).pack(anchor='w', padx=20, pady=(0, 15))
    try:
        from kalkulator_wynagrodzenia import DATA_REVISION
        cache_key=(year,DATA_REVISION,__import__('datetime').date.today().strftime('%Y-%m'))
        if getattr(app,'_year_overview_cache_key',None)==cache_key:
            months=app._year_overview_cache_value
        else:
            months=yearly_projection(year, app.db, app.cfg_for_month, calc,
                                     accounting_month, leave_for_rows=app.leave_report)
            app._year_overview_cache_key=cache_key
            app._year_overview_cache_value=months
    except Exception as exc:
        messagebox.showerror(title, str(exc), parent=win)
        win.destroy()
        return
    frame = tk.Frame(win, bg=PANEL)
    frame.pack(fill='both', expand=True, padx=18)
    columns = ('month', 'gross', 'social', 'health', 'pit', 'net', 'status')
    headings = dict(zip(columns, (
        [_t(app,'Miesiąc','Month'),_t(app,'Brutto','Gross'),'ZUS',
         _t(app,'Zdrowotna','Health'),'PIT',_t(app,'Przelew','Net'),_t(app,'Status','Status')])))
    tree = ttk.Treeview(frame, columns=columns, show='headings',
                        height=13, style='Payroll.Treeview')
    widths = [140, 132, 124, 116, 110, 140, 172]
    for key, width in zip(columns, widths):
        tree.heading(key, text=headings[key])
        tree.column(key, width=width, anchor='w' if key in ('month','status') else 'e', stretch=True)
    sy = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
    tree.configure(yscrollcommand=sy.set)
    tree.pack(side='left', fill='both', expand=True)
    sy.pack(side='right', fill='y')
    tree.tag_configure('base', background='#fff0d8', foreground='#4a3622')
    tree.tag_configure('regular', background='#f1f5f9', foreground='#193047')
    tree.tag_configure('future', background='#e4eef9', foreground='#143a58')
    tree.tag_configure('missing', background='#ffe2df', foreground='#5f2424')
    gross = social = health = pit = net = 0.0
    filled = 0
    base_months = 0
    for item in months:
        idx = int(item['period'][5:]) - 1
        values = item['result']
        if values is None:
            numbers = ['—'] * 5
            tag = 'missing'
        else:
            gross += values[4]
            social += values[5]
            health += values[6]
            pit += values[8]
            net += values[10]
            numbers = [f'{values[k]:,.2f}'.replace(',',' ').replace('.',',')
                       for k in (4,5,6,8,10)]
            filled += 1
            if item['no_cards']:
                base_months += 1
            tag = 'base' if item['no_cards'] else 'future' if item['future'] else 'regular'
        status = item['status']
        if app.language == 'en':
            status = {'Przyszły — baza':'Future, base only',
                      'Bez kart — baza':'No cards, base only',
                      'Przyszły — karty':'Future, cards',
                      'Z kart — szacunek':'Cards, estimate',
                      'Brak parametrów':'Missing settings',
                      'Brak prognozy':'Not available'}.get(status, status)
        name = MONTHS[idx] if app.language == 'pl' else [
            'January','February','March','April','May','June','July',
            'August','September','October','November','December'][idx]
        tree.insert('', 'end', values=(name, *numbers, status), tags=(tag,))
    footer = tk.Frame(win, bg=NAVY)
    footer.pack(fill='x', padx=20, pady=(10, 13))
    total = (_t(app, 'SUMA WARIANTÓW SZACUNKOWYCH', 'TOTAL ESTIMATED SCENARIOS') +
             f'   {net:,.2f} PLN'.replace(',',' ').replace('.',','))
    tk.Label(footer, text=total, bg=NAVY, fg=GOLD,
             font=('Segoe UI', 13, 'bold')).pack(anchor='w')
    tk.Label(footer,
             text=_t(app, f'Policzono {filled}/12 miesięcy, w tym {base_months} bez kart. '
                     'Suma nie oznacza faktycznie wypłaconej kwoty.',
                     f'Calculated {filled}/12 months, including {base_months} without cards. '
                     'This is not total salary actually paid.'),
             bg=NAVY, fg=MUTED, font=('Segoe UI', 9)).pack(anchor='w', pady=(5,0))
    _button(footer, _t(app,'Zamknij','Close'),win.destroy).pack(side='right')
    return win


def open_overtime_simulator(app):
    """Independent monthly scenario; scroll content, NEVER scroll the footer."""
    from kalkulator_wynagrodzenia import calc, payroll_breakdown, travel_bonus
    from payroll_rules import overtime_components
    from night_work import night_bonus_detail
    from forecast_tools import hypothetical_month_result

    period=app.month.get()
    # Modeless native Windows title bar retains minimize, maximize/restore and X.
    # A Tk grab/transient can hide minimize controls, so do not apply either.
    win=_popup(app,_t(app,'Symulator wynagrodzenia','Salary simulator'),
               '845x735',maximize=True,popup_surface='main')
    win.minsize(605,435)

    # Pack footer FIRST so resizing never pushes Calculate/Close below the window.
    footer=tk.Frame(win,bg=NAVY)
    footer.pack(side='bottom',fill='x',padx=18,pady=(8,12))
    view=tk.Frame(win,bg=NAVY)
    view.pack(side='top',fill='both',expand=True,padx=(18,12),pady=(10,0))
    view.grid_columnconfigure(0,weight=1)
    view.grid_rowconfigure(0,weight=1)
    canvas=tk.Canvas(view,bg=NAVY,highlightthickness=0,bd=0)
    canvas.grid(row=0,column=0,sticky='nsew')
    scrollbar=ttk.Scrollbar(view,orient='vertical',command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    content=tk.Frame(canvas,bg=NAVY)
    content_id=canvas.create_window((0,0),window=content,anchor='nw')

    def refresh_scroll(_event=None):
        if not win.winfo_exists():return
        bbox=canvas.bbox('all')
        if bbox is None:return
        canvas.configure(scrollregion=bbox)
        overflow=bbox[3]-bbox[1] > canvas.winfo_height()+2
        if overflow and not scrollbar.winfo_ismapped():
            scrollbar.grid(row=0,column=1,sticky='ns')
        elif not overflow and scrollbar.winfo_ismapped():
            scrollbar.grid_remove()
            canvas.yview_moveto(0)

    def resize_canvas(event):
        canvas.itemconfigure(content_id,width=event.width)
        # Avoid canvas-event loops: geometry will trigger a new frame configure.
        detail.configure(wraplength=max(360,event.width-35))
        win.after_idle(refresh_scroll)

    canvas.bind('<Configure>',resize_canvas)
    content.bind('<Configure>',refresh_scroll)

    def wheel(event):
        if not scrollbar.winfo_ismapped():return
        if getattr(event,'num',None)==4:direction=-1
        elif getattr(event,'num',None)==5:direction=1
        else:
            delta=getattr(event,'delta',0)
            if not delta:return
            direction=-int(delta/120) if abs(delta)>=120 else (-1 if delta>0 else 1)
        canvas.yview_scroll(direction,'units')
        return 'break'

    # Bind at the toplevel; children inherit it via Tk bindtags. This binding
    # belongs to this window only, not the rest of the application.
    win.bind('<MouseWheel>',wheel)
    win.bind('<Button-4>',wheel)
    win.bind('<Button-5>',wheel)

    tk.Label(content,text=_t(app,'SYMULATOR WYNAGRODZENIA','SALARY SIMULATOR'),
             fg=GOLD,bg=NAVY,font=('Segoe UI',19,'bold')).pack(anchor='w',padx=6,pady=(12,8))
    tk.Label(content,text=_t(app,f'Miesiąc: {period} — scenariusz niezależny od kart pracy.',
                                 f'Month: {period} — independent of imported work cards.'),
             bg=NAVY,fg=MUTED,font=('Segoe UI',10)).pack(anchor='w',padx=7,pady=(0,11))

    field_defs=(('a','Nadgodziny A (+50%) — godziny','Overtime A (+50%) — hours'),
                ('b','Nadgodziny B (+100%) — godziny','Overtime B (+100%) — hours'),
                ('travel','Płatne godziny podróży','Paid travel hours'),
                ('offshore','Offshore — liczba dni','Offshore — days'),
                ('pn','Praca nocna PN — liczba godzin','Night work PN — hours'),
                ('cabin','Wspólna kabina — liczba nocy','Shared cabin — nights'),
                ('diet','Dodatek do diety — liczba dni','Diet supplement — days'),
                ('eu_c','Dodatek C — kwota brutto (zł)','EU C allowance — gross PLN'),
                ('zfss','ZFŚS — kwota świadczenia (zł)','ZFSS cash benefit — PLN'))
    saved_cfg=app.cfg_for_month(period)
    vars_={key:tk.StringVar(master=win,value=(str(saved_cfg.get('eu_c_allowance',0)) if key=='eu_c' else str(saved_cfg.get('zfss_cash',0)) if key=='zfss' else '0')) for key,_,_ in field_defs}
    fields=tk.Frame(content,bg=NAVY)
    fields.pack(fill='x',padx=6,pady=5)
    theme=getattr(app,'theme_mode','dark')
    label_color='#173449' if theme=='light' else WHITE
    outline='#bdcfde' if theme=='light' else '#355773'
    for index,(key,pl,en) in enumerate(field_defs):
        # Base dialog background is #10293c; distinct palette bands keep
        # the nine form rows legible without altering their entries.
        stripe_bg='#e5eff7' if theme=='light' else ('#142f43' if index%2==0 else '#1b394f')
        stripe=tk.Frame(fields,bg=stripe_bg,highlightbackground=outline,
                        highlightthickness=1)
        stripe.pack(fill='x',padx=1,pady=3)
        tk.Label(stripe,text=_t(app,pl,en),bg=stripe_bg,fg=label_color,
                 font=('Segoe UI',10),justify='left',anchor='w').pack(
                 side='left',fill='x',expand=True,padx=(15,8),pady=8)
        tk.Entry(stripe,textvariable=vars_[key],width=12,bg='#ffffff',fg=NAVY,
                 font=('Segoe UI',12),justify='right').pack(
                 side='right',padx=(8,15),pady=6)
    cfg=app.cfg_for_month(period)
    tk.Label(content,text=_t(app,f'Nominał N: {cfg["nominal"]:g} h — z kalendarza miesiąca.  '
                              f'Stawka offshore: {cfg["offshore"]:g} zł/dzień.',
                              f'Nominal N: {cfg["nominal"]:g} h — from the calendar.  '
                              f'Offshore rate: {cfg["offshore"]:g} PLN/day.'),
             bg=NAVY,fg=MUTED,font=('Segoe UI',10)).pack(anchor='w',padx=7,pady=(11,4))
    tk.Label(content,text=_t(app,'Przelicz = tylko podgląd. Kwoty C i ZFŚS możesz osobno zapisać w tym miesiącu przyciskiem poniżej lub przez Ustawienia.',
                                  'Calculate only previews. Save C and ZFSS for this month with the separate button below or in Settings.'),
             bg=NAVY,fg=MUTED,font=('Segoe UI',9)).pack(anchor='w',padx=7)

    results=tk.Frame(content,bg=NAVY)
    results.pack(fill='x',padx=6,pady=(12,16))
    result_label=tk.Label(results,text=_t(app,'Wprowadź dane i kliknij Przelicz.',
                                          'Enter values and click Calculate.'),
                          bg=NAVY,fg=GOLD,font=('Segoe UI',15,'bold'),justify='left',anchor='w')
    result_label.pack(fill='x',anchor='w',pady=(8,10))
    detail=tk.Label(results,text='',bg=NAVY,fg=WHITE,font=('Segoe UI',10),
                    justify='left',anchor='nw',wraplength=760)
    detail.pack(fill='x',anchor='w')

    def fmt(value):return f'{value:,.2f} zł'.replace(',',' ').replace('.',',')
    def calculate():
        try:
            values={key:float(var.get().strip().replace(',','.')) for key,var in vars_.items()}
            active_cfg=app.cfg_for_month(period)
            simulation=hypothetical_month_result(
                period,active_cfg,calc,values['a'],values['b'],values['travel'],
                offshore_days=values['offshore'],night_hours=values['pn'],
                shared_room_nights=values['cabin'],diet_days=values['diet'],
                eu_c_allowance=values['eu_c'],zfss_cash=values['zfss'])
            result=simulation['result']
            active=simulation['cfg']
            rows=simulation['rows']
            pay=payroll_breakdown(rows,active,result)
            overtime=overtime_components(rows,active.get('_rate_for_date') or (lambda _:result[2]))
            pn=night_bonus_detail(rows)
            travel=travel_bonus(rows,active)
            offshore=result[1]*active['offshore']
            cabin=active['shared_room_nights']*100
            diet=active['domestic_diet_extra_days']*55
            result_label.configure(text=_t(app,'Prognoza przelewu: ',
                                           'Estimated bank transfer: ')+fmt(result[10]))
            if app.language=='en':
                lines=[f'Nominal N: {simulation["nominal"]:g} h | A: {values["a"]:g} h | B: {values["b"]:g} h',
                       f'Travel: {values["travel"]:g} h | PN: {values["pn"]:g} h | Offshore: {result[1]} days',
                       f'Base salary: {fmt(active["salary"])}',
                       f'1700 — overtime basic pay 100%: {fmt(overtime["all_base"])}',
                       f'A premium 50%: {fmt(overtime["premium_a"])}',
                       f'B premium 100%: {fmt(overtime["premium_b"])}',
                       f'Travel allowance: {fmt(travel)}',
                       f'PN night premium: {fmt(pn["amount"])}',
                       f'Offshore: {fmt(offshore)}',f'Shared cabin: {fmt(cabin)}',
                       f'Diet supplement: {fmt(diet)}',
                       f'EU C allowance (gross): {fmt(active["eu_c_allowance"])}',
                       f'ZFSS cash: {fmt(active["zfss_cash"])} (PIT exempt: {fmt(pay["zfss_exempt"])}; taxable: {fmt(pay["zfss_taxable"])})',
                       f'Gross allowances: {fmt(result[3])}',f'Total gross cash: {fmt(result[4])}',
                       f'Employee social: -{fmt(result[5])}',f'Health: -{fmt(result[6])}',
                       f'PIT advance: -{fmt(result[8])}',f'PPK: -{fmt(result[9])}',
                       f'PPE and other deductions: -{fmt(active.get("ppe_extra",0)+active.get("other_deductions",0))}']
            else:
                lines=[f'N: {simulation["nominal"]:g} h | A: {values["a"]:g} h | B: {values["b"]:g} h',
                       f'Podróż: {values["travel"]:g} h | PN: {values["pn"]:g} h | Offshore: {result[1]} dni',
                       f'Pensja zasadnicza: {fmt(active["salary"])}',
                       f'1700 — podstawa nadgodzin 100%: {fmt(overtime["all_base"])}',
                       f'1711 — dodatek A 50%: {fmt(overtime["premium_a"])}',
                       f'1721 — dodatek B 100%: {fmt(overtime["premium_b"])}',
                       f'Dodatek za podróż: {fmt(travel)}',
                       f'Dodatek nocny PN: {fmt(pn["amount"])}',
                       f'Dodatek offshore: {fmt(offshore)}',
                       f'Wspólna kabina: {fmt(cabin)}',
                       f'Dodatek do diety: {fmt(diet)}',
                       f'Dodatek C brutto: {fmt(active["eu_c_allowance"])}',
                       f'ZFŚS: {fmt(active["zfss_cash"])} (zwolnione PIT: {fmt(pay["zfss_exempt"])}; opodatkowane: {fmt(pay["zfss_taxable"])})',
                       f'Dodatki brutto: {fmt(result[3])}',
                       f'Łącznie brutto: {fmt(result[4])}',
                       f'ZUS pracownika: -{fmt(result[5])}',
                       f'Składka zdrowotna: -{fmt(result[6])}',
                       f'Zaliczka PIT: -{fmt(result[8])}',
                       f'PPK: -{fmt(result[9])}',
                       f'PPE i pozostałe potrącenia: -{fmt(active.get("ppe_extra",0)+active.get("other_deductions",0))}']
            if pn['unpriced_hours']:
                lines.append(_t(app,'UWAGA: nieustalona stawka PN dla części godzin.',
                                    'WARNING: PN rate unavailable for some night hours.'))
            lines.append(_t(app,f'Stawka podróży: {active["travel_rate"]*100:g}% stawki godzinowej',
                                f'Travel premium: {active["travel_rate"]*100:g}% of hourly pay'))
            detail.configure(text='\n'.join(lines))
            win.after_idle(refresh_scroll)
        except (ValueError,TypeError,ArithmeticError) as exc:
            messagebox.showerror(_t(app,'Nieprawidłowe dane','Invalid input'),str(exc),parent=win)
        except Exception as exc:
            messagebox.showwarning(_t(app,'Brak prognozy','Estimate unavailable'),str(exc),parent=win)

    def save_specials():
        from special_payments import amount
        try:
            c=amount(vars_['eu_c'].get())
            social=amount(vars_['zfss'].get())
            app.save_special_from_simulator(period,c,social)
        except (ValueError,TypeError) as exc:
            messagebox.showerror(_t(app,'Błędna kwota','Invalid amount'),str(exc),parent=win)
            return
        messagebox.showinfo(_t(app,'Zapisano','Saved'),
           _t(app,f'Zapisano dodatek C i ZFŚS dla miesiąca wypłaty {period}. Inne miesiące bez zmian.',
                     f'Saved EU C and ZFSS for payment month {period}. Other months unchanged.'),parent=win)
    _button(footer,_t(app,'Przelicz','Calculate'),calculate,GREEN).pack(side='left')
    _button(footer,_t(app,'Zapisz C i ZFŚS','Save C and ZFSS'),save_specials).pack(side='left',padx=(10,0))
    _button(footer,_t(app,'Zamknij','Close'),win.destroy).pack(side='right')
    tk.Label(footer,text=_t(app,'PIT/ZUS uwzględniają saldo z poprzednich okresów.',
                                   'PIT/social use opening balances from prior months.'),
             bg=NAVY,fg=MUTED,font=('Segoe UI',9),wraplength=340,
             justify='left').pack(side='left',padx=14)
    win.after_idle(refresh_scroll)
    return win


def open_card_check(app):
    from kalkulator_wynagrodzenia import accounting_month, read_xlsx
    report = validate_cards(app.db,accounting_month,read_source=read_xlsx)
    win = _popup(app, _t(app,'Kontrola kart pracy','Work-card validation'), '1050x675', maximize=True)
    tk.Label(win,text=_t(app,'KONTROLA POPRAWNOŚCI KART','WORK-CARD VALIDATION')+f" — {report['year']}",
             bg=NAVY,fg=GOLD,font=('Segoe UI',17,'bold')).pack(anchor='w',padx=20,pady=(17,7))
    info = (_t(app,'Wierszy aktywnych: ','Active rows: ')+str(report['active_rows'])+
            '  |  '+_t(app,'Błędy: ','Errors: ')+str(report['errors'])+
            '  |  '+_t(app,'Uwagi: ','Warnings: ')+str(report['warnings']))
    tk.Label(win,text=info,bg=NAVY,fg=WHITE,font=('Segoe UI',11,'bold')).pack(anchor='w',padx=21,pady=(0,4))
    frame=tk.Frame(win,bg=PANEL)
    frame.pack(fill='both',expand=True,padx=18)
    frame.grid_rowconfigure(0,weight=1)
    frame.grid_columnconfigure(0,weight=1)
    columns=('level','date','file','row','description')
    tree=ttk.Treeview(frame,columns=columns,show='headings',style='Payroll.Treeview')
    headings=[_t(app,'Status','Status'),_t(app,'Data','Date'),
              _t(app,'Karta pracy','Work card'),_t(app,'Wiersz Excel','Excel row'),
              _t(app,'Opis problemu','Issue')]
    # Make every title centered over its actual column, even after resizing
    # or horizontal scrolling. Keep content columns at fixed widths, so the
    # long diagnosis never gets silently compressed to the window width.
    text_font=tkfont.Font(root=win,family='Segoe UI',size=10)
    heading_font=tkfont.Font(root=win,family='Segoe UI',size=10,weight='bold')
    displayed=sorted(report['issues'],key=lambda issue: issue.get('date',''),reverse=True)[:1500]
    description_width=max(600,
        max((text_font.measure(str(i.get('message','')))+36 for i in displayed),default=600))
    widths=[110,135,240,150,description_width]
    for col,label,width in zip(columns,headings,widths):
        width=max(width,heading_font.measure(label)+32)
        tree.heading(col,text=label,anchor='center')
        tree.column(col,width=width,minwidth=width,stretch=False,
                    anchor='w' if col=='description' else 'center')
    scroll=ttk.Scrollbar(frame,orient='vertical',command=tree.yview)
    scroll_x=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview)
    tree.configure(yscrollcommand=scroll.set,xscrollcommand=scroll_x.set)
    tree.grid(row=0,column=0,sticky='nsew')
    scroll.grid(row=0,column=1,sticky='ns')
    scroll_x.grid(row=1,column=0,sticky='ew')
    tree.tag_configure('BŁĄD',background='#ffdddd',foreground='#702222')
    tree.tag_configure('UWAGA',background='#fff0db',foreground='#63420b')
    # Newest first, with stable relative order for multiple alerts from one row.
    selected_rows = {}
    for item in displayed:
        iid=tree.insert('','end',values=(item['level'],item['date'],item['file'],item.get('row') or '—',item['message']),tags=(item['level'],))
        selected_rows[iid] = item
    def open_selected(_event=None):
        if _event is not None and getattr(_event, 'y', None) is not None:
            hit=tree.identify_row(_event.y)
            if hit:tree.selection_set(hit)
        selection=tree.selection()
        if not selection:return
        issue=selected_rows.get(selection[0])
        if not issue or not issue.get('source_path'):
            messagebox.showwarning(_t(app,'Brak pliku','File unavailable'),
               _t(app,'Brak ścieżki źródłowej. Zaimportuj ponownie tę kartę.',
                       'No source file path. Reimport this work card.'),parent=win)
            return
        app._open_original_card([{'source_path':issue['source_path'],
                                  'file':issue['file'],'date':issue['date']}])
    tree.bind('<Double-1>',open_selected)
    tree.bind('<Return>',open_selected)

    footer=tk.Frame(win,bg=NAVY)
    footer.pack(fill='x',padx=19,pady=15)
    note = (_t(app,'Wyniki są orientacyjne. Program niczego nie usuwa ani nie zmienia. ',
                    'Checks are advisory. No data is modified. ')+
            (_t(app,'Wyświetlono pierwsze 1500 uwag.', 'Showing the first 1500 issues.')
             if len(report['issues'])>1500 else
             _t(app,'Brak uwag oznacza jedynie brak wykrytych problemów.',
                    'No flagged issues does not guarantee full correctness.')))
    tk.Label(footer,text=note,bg=NAVY,fg=MUTED,wraplength=720,justify='left',
             font=('Segoe UI',9)).pack(side='left',fill='x',expand=True)
    _button(footer,_t(app,'Zamknij','Close'),win.destroy).pack(side='right')
    _button(footer,_t(app,'Otwórz kartę Excel','Open Excel card'),open_selected,GREEN).pack(side='right',padx=10)
    return win


def export_current_month_pdf(app):
    from kalkulator_wynagrodzenia import calc, payroll_breakdown
    period = app.month.get()
    rows = app.current()
    if not rows:
        yes = messagebox.askyesno(
            _t(app,'Brak kart pracy','No work cards'),
            _t(app,'Nie ma kart pracy w tym miesiącu. Raport zawierałby jedynie szacowane wynagrodzenie bazowe. Eksportować mimo to?',
                    'No work cards for this month. The report would only reflect base-pay assumptions. Export anyway?'),
            parent=app.root)
        if not yes:
            return
    output = filedialog.asksaveasfilename(parent=app.root,
        title=_t(app,'Zapisz prognozę jako PDF','Save salary estimate PDF'),
        defaultextension='.pdf', filetypes=[('PDF','*.pdf')],
        initialfile=f'Prognoza_wyplaty_{period}.pdf')
    if not output:
        return
    try:
        from forecast_pdf import export_month_pdf
        cfg = app.cfg_for_month()
        leave = app.leave_report(rows) if any(r.get('leave_code') or r.get('work_type')==6 for r in rows) else {}
        cfg['_leave_variable_pay'] = leave.get('variable_amount', 0.0) if leave.get('complete') else 0.0
        result = calc(rows,cfg)
        breakdown = payroll_breakdown(rows,cfg,result)
        export_month_pdf(output,period,rows,cfg,result,breakdown,leave_report=leave,
                         language=app.language)
    except ImportError as exc:
        messagebox.showerror('PDF',_t(app,'Brakuje pakietu reportlab. Uruchom ponownie skrypt budujący program, który instaluje tę bibliotekę.',
                                        'The reportlab package is missing. Rebuild the app using the updated build script.')+
                             '\n'+str(exc),parent=app.root)
        return
    except Exception as exc:
        messagebox.showerror('PDF',str(exc),parent=app.root)
        return
    messagebox.showinfo('PDF',_t(app,'Zapisano prognozę w pliku:\n','Saved salary estimate to:\n')+output,
                        parent=app.root)
