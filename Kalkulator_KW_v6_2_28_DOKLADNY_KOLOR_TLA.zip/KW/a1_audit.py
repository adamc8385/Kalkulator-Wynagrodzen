"""Audyt krajów A1. Brak zależności GUI i plików użytkownika.

Wpis z dwiema nazwami tego samego kraju (np. Włochy/Italy) nie tworzy konfliktu.
Wpisy z różnymi krajami na jednej dacie są pokazywane do ręcznego wyjaśnienia,
nie rozstrzygane automatycznie na potrzeby urzędowego raportu A1.
"""
from collections import defaultdict
from datetime import date
import re
import unicodedata

# Kanoniczne polskie nazwy. Rozpoznawane są wyłącznie jednoznaczne aliasy.
ALIASES = {
    'Polska': ('polska', 'poland', 'pl'),
    'Włochy': ('wlochy', 'italy', 'italia', 'it'),
    'Hiszpania': ('hiszpania', 'spain', 'espana', 'es'),
    'Wielka Brytania': ('wielka brytania', 'united kingdom', 'great britain', 'uk', 'gb', 'england'),
    'Belgia': ('belgia', 'belgium', 'be'),
    'Francja': ('francja', 'france', 'fr'),
    'Niemcy': ('niemcy', 'germany', 'deutschland', 'de'),
    'Holandia': ('holandia', 'niderlandy', 'netherlands', 'the netherlands', 'nl'),
    'Dania': ('dania', 'denmark', 'dk'),
    'Finlandia': ('finlandia', 'finland', 'fi'),
    'Norwegia': ('norwegia', 'norway', 'no'),
    'Szwecja': ('szwecja', 'sweden', 'se'),
    'Szwajcaria': ('szwajcaria', 'switzerland', 'ch'),
    'Austria': ('austria', 'at'),
    'Irlandia': ('irlandia', 'ireland', 'ie'),
    'Portugalia': ('portugalia', 'portugal', 'pt'),
    'Grecja': ('grecja', 'greece', 'gr'),
    'Czechy': ('czechy', 'czech republic', 'czechia', 'cz'),
    'Słowacja': ('slowacja', 'slovakia', 'sk'),
    'Chorwacja': ('chorwacja', 'croatia', 'hr'),
    'Węgry': ('wegry', 'hungary', 'hu'),
    'Rumunia': ('rumunia', 'romania', 'ro'),
    'Litwa': ('litwa', 'lithuania', 'lt'),
    'Łotwa': ('lotwa', 'latvia', 'lv'),
    'Estonia': ('estonia', 'ee'),
    'Turcja': ('turcja', 'turkey', 'turkiye', 'tr'),
    'USA': ('usa', 'united states', 'united states of america', 'us'),
}


def _key(value):
    value = unicodedata.normalize('NFKD', str(value or ''))
    value = ''.join(ch for ch in value if not unicodedata.combining(ch))
    value = value.replace('ł', 'l').replace('Ł', 'L').casefold()
    return re.sub(r'\s+', ' ', value.strip(' .;,\t\n'))


LOOKUP = {_key(alias): country for country, aliases in ALIASES.items() for alias in (country, *aliases)}
MISSING = {_key(x) for x in ('', 'BRAK', 'brak danych', 'N/A', 'None', '—', '-', 'unknown')}


def canonical_country(raw):
    """(kanoniczna nazwa kraju, oryginalna wartość); brak -> (None, wartość)."""
    orig = str(raw or '').strip()
    key = _key(orig)
    if key in MISSING:
        return None, orig
    return LOOKUP.get(key, re.sub(r'\s+', ' ', orig)), orig


def _is_travel(entries):
    """Travel intent, never interpreted as an unambiguous direction alone."""
    for entry in entries:
        row = entry['source']
        if row.get('work_type') in (2, 10, 11):
            return True
        try:
            if float(row.get('P') or 0) + float(row.get('T') or 0) > 0:
                return True
        except (ValueError, TypeError):
            pass
    return False


def _meaningful_country_missing(entries):
    """An empty country is only actionable for actual work/travel, not a free day."""
    for entry in entries:
        row = entry['source']
        # Leave (6) and approved day off (5) do not require a workplace
        # country, even if N is used to record nominal leave hours.
        if row.get('work_type') in (5, 6):
            try:
                if not any(float(row.get(key) or 0) > 0 for key in ('A', 'B', 'PN', 'P', 'T')):
                    continue
            except (ValueError, TypeError):
                return True
        if row.get('work_type') is not None:
            return True
        if str(row.get('job') or '').strip():
            return True
        try:
            if any(float(row.get(key) or 0) > 0 for key in ('N', 'A', 'B', 'PN', 'P', 'T')):
                return True
        except (ValueError, TypeError):
            return True
    return False


def a1_audit(rows, start, end, excluded_ids=(), file_names=None):
    """Count residence dates from cards and *bounded* assignment continuity.

    The user-defined estimate treats a confirmed return trip on Friday as
    finishing the foreign assignment that day; a blank weekend afterwards is
    Polish. The country on types 2, 10 or 11 does not by itself say travel direction:
    preceding and subsequent assignments must corroborate a return.

    All inferred dates are labelled separately from explicit card countries.
    Genuinely ambiguous boundary gaps and worked dates with an absent country
    remain unresolved, not silently marked Poland. No source rows are mutated.
    """
    from datetime import timedelta
    excluded = set(excluded_ids or ())
    file_names = file_names or {}
    context_start, context_end = start - timedelta(days=10), end + timedelta(days=10)
    by_date = defaultdict(list)
    for row in rows:
        if row.get('file_id') in excluded:
            continue
        try:
            day = date.fromisoformat(str(row['date']))
        except (ValueError, TypeError, KeyError):
            continue
        if not context_start <= day <= context_end:
            continue
        country, raw = canonical_country(row.get('country', ''))
        entry = {
            'date': day, 'country': country, 'raw_country': raw,
            'file': str(row.get('file') or file_names.get(row.get('file_id')) or '(brak nazwy pliku)'),
            'source_path': str(row.get('source_path') or ''),
            'file_id': row.get('file_id'), 'row': row.get('row', ''), 'source': row,
        }
        by_date[day].append(entry)

    direct = {}
    conflicts = {}
    for day, entries in by_date.items():
        countries = {item['country'] for item in entries if item['country'] is not None}
        if len(countries) == 1:
            direct[day] = next(iter(countries))
        elif len(countries) > 1 and start <= day <= end:
            conflicts[day] = sorted(entries, key=lambda r: (r['country'] or '', r['file'], str(r['row'])))

    # Only fill short gaps BETWEEN two known country anchors. A country alone
    # never causes indefinite forward/backward extrapolation of a delegation.
    anchors = sorted(direct)
    inferred = {}
    uncertain = set()
    for index, (left, right) in enumerate(zip(anchors, anchors[1:])):
        count = (right - left).days - 1
        if count <= 0:
            continue
        country_left, country_right = direct[left], direct[right]
        previous_foreign = (index > 0 and direct[anchors[index-1]] == country_left
                            and country_left != 'Polska')
        left_return = (country_left != 'Polska' and country_right == 'Polska'
                       and _is_travel(by_date[left]) and previous_foreign)
        right_departure = (country_left == 'Polska' and country_right != 'Polska'
                           and _is_travel(by_date[right]))
        if country_left == country_right:
            # Friday return and Monday departure to the SAME foreign country
            # cannot establish where the weekend was actually spent.
            if country_left != 'Polska' and _is_travel(by_date[left]) and _is_travel(by_date[right]):
                target = None
            else:
                target = country_left
        elif left_return or right_departure:
            target = 'Polska'
        else:
            target = None
        for offset in range(1, count+1):
            day = left + timedelta(days=offset)
            if _is_travel(by_date.get(day, [])):
                target = None
            if not start <= day <= end or day in conflicts:
                continue
            if target is None:
                uncertain.add(day)
            else:
                inferred[day] = target

    def _unused_weekend(entries):
        for entry in entries:
            row=entry['source']
            if row.get('work_type') not in (None, '', 0, '0', 5, 6):
                return False
            if str(row.get('job') or '').strip() and 'wolny' not in str(row.get('job')).lower():
                return False
            try:
                if any(float(row.get(key) or 0) != 0 for key in ('N','A','B','PN','P','T')):
                    return False
            except (TypeError, ValueError):
                return False
        return True


    # Continue the last confirmed country into immediately following blank weekend.
    # Do not assume a multi-month foreign assignment from one isolated record.
    if anchors:
        last = anchors[-1]
        day = last + timedelta(days=1)
        while day <= end and day.weekday() >= 5 and day <= last + timedelta(days=2):
            # A work/travel weekend without a country is not a blank weekend;
            # do not silently infer residence from a prior Friday.
            if not _unused_weekend(by_date.get(day, [])) or _is_travel(by_date.get(day, [])):
                break
            if day not in conflicts and day not in direct:
                # A departure/return is not proven by work type 2, 10 or 11.
                # If the final known day is travel, the following weekend is
                # unresolved until a subsequent country anchor confirms it.
                if _is_travel(by_date[last]):
                    uncertain.add(day)
                else:
                    inferred[day] = direct[last]
            day += timedelta(days=1)

    # A non-working Saturday/Sunday with a source row but no recorded work or
    # travel is not a missing workplace country. A1 defaults to Poland only
    # when no nearby FOREIGN assignment evidence or unresolved travel exists.
    # Unlike a blanket "all weekends = Poland" rule, this preserves foreign
    # assignment weekends (including the ambiguous boundaries above).
    for day, entries in by_date.items():
        if not start <= day <= end or day.weekday() < 5:
            continue
        if day in direct or day in inferred or day in conflicts or day in uncertain:
            continue
        if not entries or _is_travel(entries):
            continue
        def _unused_day(row):
            if row.get('work_type') in (2, 9, 10, 11):
                return False
            try:
                if any(float(row.get(k) or 0) != 0 for k in ('N','A','B','PN','P','T')):
                    return False
            except (ValueError, TypeError):
                return False
            return not str(row.get('job') or '').strip() or 'wolny' in str(row.get('job') or '').lower()
        if not all(_unused_day(item['source']) for item in entries):
            continue
        # A confirmed foreign day within ten days or a foreign journey with an
        # unconfirmed endpoint is evidence against assuming domestic residence.
        if any(other_country != 'Polska' and abs((other_day-day).days) <= 10
               for other_day, other_country in direct.items()):
            continue
        if any(abs((other_day-day).days) <= 3 and _is_travel(other_entries)
               for other_day,other_entries in by_date.items()):
            continue
        inferred[day]='Polska'  # estimated, not written to any source XLSX

    # A confirmed Polish Friday that is not a travel day anchors a *blank*
    # Saturday and Sunday at home. This is an estimate of residence, not proof:
    # do not bridge a foreign/travel entry inside the weekend or an actual
    # worked day. In particular, a Monday foreign job alone is no proof that
    # Saturday/Sunday were already abroad. Earlier general continuity analysis
    # can mark these dates uncertain, so explicitly clear only these two days.

    for friday,country in direct.items():
        if country!='Polska' or friday.weekday()!=4 or _is_travel(by_date[friday]):
            continue
        weekend=(friday+timedelta(days=1),friday+timedelta(days=2))
        # An explicit foreign country on Saturday or Sunday prevents any
        # assumption about the earlier blank day of that weekend.
        if any((day in direct and direct[day]!='Polska') or day in conflicts for day in weekend):
            continue
        for offset in (1,2):
            day=friday+timedelta(days=offset)
            if not start<=day<=end:
                continue
            entries=by_date.get(day,[])
            if day in conflicts or day in direct or not _unused_weekend(entries):
                break
            if _is_travel(entries):
                break
            inferred[day]='Polska'
            uncertain.discard(day)

    # No-country auxiliary rows from a day with an explicit country must not
    # create false issues. Blank days in the office/home are also legitimate.
    missing = {}
    for day, entries in by_date.items():
        if not start <= day <= end or day in direct or day in inferred or day in conflicts:
            continue
        empty = [e for e in entries if e['country'] is None]
        if not empty:
            continue
        if day in uncertain or _meaningful_country_missing(empty):
            missing[day] = empty
            uncertain.add(day)

    foreign_by_country = defaultdict(set)
    for day, country in direct.items():
        if start <= day <= end and country != 'Polska':
            foreign_by_country[country].add(day)
    for day, country in inferred.items():
        if country != 'Polska':
            foreign_by_country[country].add(day)
    foreign_dates = set().union(*foreign_by_country.values()) if foreign_by_country else set()
    unresolved = uncertain | set(conflicts)
    unresolved.difference_update(foreign_dates)
    total_days = (end - start).days + 1
    counts = sorted(((country, len(days)) for country, days in foreign_by_country.items()),
                    key=lambda item: (-item[1], item[0]))
    details = []
    for day in sorted(set(conflicts) | set(missing) | uncertain):
        reason = ('Różne kraje' if day in conflicts else
                  'Nieustalony pobyt' if day in uncertain and day not in missing else
                  'Brak kraju')
        records = sorted(by_date.get(day, []),
                         key=lambda r: (r['file'], str(r['row']), r['country'] or ''))
        if not records:
            # No work card row on this date; report the uncertainty without
            # pretending that a specific XLSX source contains that date.
            records = [{'date': day, 'country': None, 'raw_country': '',
                        'file': '—', 'source_path': '', 'file_id': None,
                        'row': '', 'source': {}}]
        for entry in records:
            details.append({**entry, 'reason': reason})
    return {
        'counts': counts, 'poland': total_days-len(foreign_dates)-len(unresolved),
        'total': total_days, 'foreign': len(foreign_dates),
        'unresolved': len(unresolved), 'conflict_count': len(conflicts),
        'conflicts': conflicts, 'missing': missing,
        'inferred': {day: inferred[day] for day in sorted(inferred)},
        'details': details, 'period': (start, end),
    }
