"""Shared payroll arithmetic of both ACH/KW editions.

Payslip-confirmed model (v6.2.17): each A/B hour receives a separate
100% basic overtime payment (code 1700), plus A 50% or B 100% premium.
Round the hourly rate and the 50% premium to PLN 0.01 before multiplying
by hours. Settlement-period historic rates come from the caller.
"""
from decimal import Decimal, ROUND_HALF_UP


def cent(value):
    return float(Decimal(str(value)).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))


def zloty(value):
    """Half-up rounding to a whole PLN for income tax calculations."""
    return int(Decimal(str(value)).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def overtime_components(rows,rate_for_date):
    """Break down payslip codes 1700, 1711 (A +50%), 1721 (B +100%).

    N is the calendar-month nominal, NEVER the work-card sum. The A/B hours
    come solely from the work cards in the company ISO payroll weeks.
    Hourly rate and A 50% are each rounded to cents before multiplying hours.
    """
    base_a=base_b=premium_a=premium_b=Decimal("0")
    retro=[]
    for row in rows:
        hourly=cent(rate_for_date(str(row.get('date',''))))
        hours_a=float(row.get('A',0) or 0)
        hours_b=float(row.get('B',0) or 0)
        base_a+=Decimal(str(hours_a))*Decimal(str(hourly))
        base_b+=Decimal(str(hours_b))*Decimal(str(hourly))
        premium_a+=Decimal(str(hours_a))*Decimal(str(cent(hourly*.5)))
        premium_b+=Decimal(str(hours_b))*Decimal(str(hourly))
        if (hours_a or hours_b) and row.get('date'):
            retro.append((row['date'],hourly,hours_a,hours_b))
    return {'base_a':cent(base_a),'base_b':cent(base_b),
            'premium_a':cent(premium_a),'premium_b':cent(premium_b),
            'all_base':cent(base_a+base_b),'all_premiums':cent(premium_a+premium_b),
            'rate_details':retro}


def pension_employer_estimate(cfg,eligible_salary):
    """Wärtsilä PPE 3.5%, PPO 0.5% when employee is eligible.

    Employer pension accrual is *not cash*. The reference payslip may include
    bonuses/corrections not present in work cards; this is only an estimate.
    Explicit month-specific overrides take priority.
    """
    base=max(0,float(eligible_salary))
    ppe=cent(base*.035) if cfg.get('ppe_auto_enabled',0) else 0.
    ppo=cent(base*.005) if cfg.get('ppo_auto_enabled',0) else 0.
    if float(cfg.get('ppe_employer_override',0) or 0)>0: ppe=cent(cfg['ppe_employer_override'])
    if float(cfg.get('ppo_employer_override',0) or 0)>0: ppo=cent(cfg['ppo_employer_override'])
    return ppe,ppo


def tax_schedule(year,confirmed_only=True):
    """2027 proposed brackets are NOT effective until enacted and verified."""
    if year>=2027 and not confirmed_only:
        raise ValueError('Niepotwierdzone progi PIT 2027 nie mogą być użyte w rozliczeniu płacowym.')
    return [(120000.,.12),(float('inf'),.32)],'CONFIRMED_CURRENT'


def marginal_tax(ytd, current, year,confirmed_only=True):
    brackets,status=tax_schedule(year,confirmed_only=confirmed_only)
    def total(x):
        start=0.; out=0.
        for limit,rate in brackets:
            out+=max(0.,min(x,limit)-start)*rate
            start=limit
            if x<=limit:break
        return out
    begin=max(0.,float(ytd)); end=begin+max(0.,float(current))
    return cent(total(end)-total(begin)),status


def bracket_name(ytd,taxable,year,confirmed_only=True):
    brackets,status=tax_schedule(year,confirmed_only)
    start=max(0.,float(ytd)); end=start+max(0.,float(taxable)); prev=0.; found=[]
    if end <= start:
        return '—',status
    for limit,rate in brackets:
        if start<limit and end>prev:
            if max(0.,min(end,limit)-max(prev,start))>0:
                found.append(f'{round(rate*100):d}%')
        prev=limit
    if not found:
        for limit,rate in brackets:
            if start<limit:
                found=[f'{round(rate*100):d}%'];break
    return '/'.join(found or ['32%']),status
