@echo off
cd /d "%~dp0"
python run_tests.py --suite all
if errorlevel 1 (echo TESTY NIE PRZESZLY. & exit /b 1)
echo TESTY ZALICZONE.
