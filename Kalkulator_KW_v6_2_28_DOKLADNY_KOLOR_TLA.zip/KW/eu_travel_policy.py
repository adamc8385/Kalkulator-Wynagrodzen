"""Advisory verification of work-card travel codes against EU assignment rules.

Source: WPL Annex 5 rev. 03 (15 July 2026), plus the work-card
legend: type 11 = "PODRÓŻ DK, FR, NL, IT itp.". The document describes
allowance C but does not itself define the numeric type code. This checker
never computes C payments or guesses an assignment from adjacent dates.
"""
from __future__ import annotations
import datetime as dt
import math
import unicodedata

# Regulatory scope expressly listed in Annex 5. No automatic extrapolation to
# all European Union countries, nor to countries in which rules may change.
_AFFECTED = {
    'dania': 'Dania', 'denmark': 'Dania', 'dk': 'Dania',
    'finlandia': 'Finlandia', 'finland': 'Finlandia', 'fi': 'Finlandia',
    'francja': 'Francja', 'france': 'Francja', 'fr': 'Francja',
    'holandia': 'Holandia', 'niderlandy': 'Holandia',
    'netherlands': 'Holandia', 'holland': 'Holandia', 'nl': 'Holandia',
    'wlochy': 'Włochy', 'italia': 'Włochy', 'italy': 'Włochy', 'it': 'Włochy',
}
DOCUMENT_REVISION = dt.date(2026, 7, 15)


def eligible_country(value):
    """Return a listed country only for an unambiguous country field."""
    text = unicodedata.normalize('NFKD', str(value or '').strip())
    token = ''.join(char for char in text if not unicodedata.combining(char)).casefold().replace('ł', 'l')
    return _AFFECTED.get(token)


def travel_type_issue(row, date):
    """Return (level, text) or None without altering the imported row.

    Explicit P/T travel hours and an unambiguous country are required. Type 10
    represents offshore mobilization/demobilization and has distinct rules.
    Older cards are advisory only: the supplied annex's revision was in 2026.
    """
    country = eligible_country(row.get('country'))
    if country is None:
        return None
    try:
        hours = sum(max(0.0, float(row.get(k) or 0)) for k in ('P', 'T'))
    except (ValueError, TypeError):
        return None
    if not math.isfinite(hours) or hours <= 0 or row.get('work_type') in (10, 11):
        return None
    severity = 'BŁĄD' if date >= DOCUMENT_REVISION else 'UWAGA'
    return severity, (f'Podróż ({hours:g} h) — kraj: {country}. '
                      f'Typ pracy {row.get("work_type") if row.get("work_type") is not None else "niewpisany"}; '
                      'według legendy KP dla tej podróży wymagany jest typ 11 '
                      '(podróż DK/FR/NL/IT itp.). '
                      'Zweryfikuj kraj podróży, zwłaszcza przy powrocie z delegacji.')
