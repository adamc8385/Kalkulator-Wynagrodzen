#define MyAppName "Kalkulator wynagrodzen KW v6.2.28"
#define MyAppExeName "KW_Kalkulator_Wynagrodzenia.exe"
[Setup]
AppId=PL.KW.KalkulatorWynagrodzen.KW.V62TEST
AppName={#MyAppName}
AppVersion=6.2.28
AppPublisher=KW
DefaultDirName={localappdata}\Programs\KalkulatorWynagrodzen\KW_v6_2_TEST
DefaultGroupName={#MyAppName}
PrivilegesRequired=lowest
OutputDir=GOTOWY_INSTALATOR
OutputBaseFilename=Kalkulator_Wynagrodzen_KW_v6_2_28_Setup
Compression=lzma2
SolidCompression=yes
UninstallDisplayIcon={app}\{#MyAppExeName}
SetupIconFile=kw_icon.ico
WizardStyle=modern
DisableProgramGroupPage=yes
[Files]
Source: "GOTOWY_EXE\KW_Kalkulator_Wynagrodzenia\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion
[Icons]
Name: "{autodesktop}\Kalkulator wynagrodzen KW v6.2.28"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"
Name: "{group}\Kalkulator wynagrodzen KW v6.2.28"; Filename: "{app}\{#MyAppExeName}"
[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Uruchom Kalkulator wynagrodzen"; Flags: nowait postinstall skipifsilent
