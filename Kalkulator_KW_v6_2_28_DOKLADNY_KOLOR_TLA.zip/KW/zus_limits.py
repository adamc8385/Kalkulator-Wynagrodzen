"""Annual Polish pension/disability contribution-base limits ('30-krotnosc').

Official references:
- ZUS historical register: https://bip.zus.pl/pl/web/guest/baza-wiedzy/skladki-wskazniki-odsetki/wskazniki/roczna-podstawa-wymiaru-skladek-na-ubezpieczenia-emerytalne-i-rentowe-od-1999-r
- 2027: Monitor Polski 2026 item 1098, published 4 Nov 2026.

The embedded, promulgated numbers work offline. Future years are added only after
retrieval from the official ZUS site. No forecasts or previous-year substitutions.
"""

import datetime as dt
from html.parser import HTMLParser
import re
from urllib.request import Request, urlopen

OFFICIAL_ZUS_URL = (
    'https://bip.zus.pl/pl/web/guest/baza-wiedzy/skladki-wskazniki-odsetki/'
    'wskazniki/roczna-podstawa-wymiaru-skladek-na-ubezpieczenia-emerytalne-i-rentowe-od-1999-r'
)
ELI_2027_URL = 'https://eli.gov.pl/eli/MP/2026/1098/ogl/pol'

# Exact official ZUS historical amounts; 2027 confirmed by Monitor Polski.
# Do not use the current-year value for a different year.
PUBLISHED = {
    2008: 85290, 2009: 95790, 2010: 94380, 2011: 100770,
    2012: 105780, 2013: 111390, 2014: 112380, 2015: 118770,
    2016: 121650, 2017: 127890, 2018: 133290, 2019: 142950,
    2020: 156810, 2021: 157770, 2022: 177660, 2023: 208050,
    2024: 234720, 2025: 260190, 2026: 282600, 2027: 300990,
}


class MissingAnnualLimit(ValueError):
    """No verified official contribution cap for a year."""


def annual_limit(year, cache=None):
    """Return published amount as int or None; never guess for unknown years."""
    year = int(year)
    if year in PUBLISHED:
        return PUBLISHED[year]
    record = (cache or {}).get(str(year), {})
    if not isinstance(record, dict):
        return None
    try:
        value = int(record.get('amount'))
    except (TypeError, ValueError):
        return None
    return value if record.get('source') == OFFICIAL_ZUS_URL and 10000 <= value <= 2000000 and value % 30 == 0 else None


def source_for_year(year, cache=None):
    if int(year) == 2027:
        return ELI_2027_URL
    if annual_limit(year, cache) is not None:
        return OFFICIAL_ZUS_URL
    return None


class _HTMLText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.bits = []
    def handle_data(self, data):
        self.bits.append(data)
    def get_text(self):
        return ' '.join(self.bits)


def extract_official_limits(html):
    """Read explicit amounts from ZUS's published historical year/value list.

    Fails closed if the portal is redesigned: an amount is accepted only when
    the same span explicitly says it is the annual cap for a numbered year.
    """
    p = _HTMLText()
    p.feed(html)
    s = re.sub(r'\s+', ' ', p.get_text().replace('\u200b', '').replace('\ufeff', ''))
    out = {}
    pattern = re.compile(
        r'(\d{2,3}(?:[\s\u00a0]?\d{3})+)(?:[,\.]00)?\s*zł\s*[-–—]\s*'
        r'kwota\s+rocznego\s+ograniczenia\s+podstawy\s+w\s+(20\d{2})\s*r(?:\.|oku)?',
        re.I)
    for m in pattern.finditer(s):
        value = int(re.sub(r'\s+', '', m.group(1)))
        year = int(m.group(2))
        if 2000 <= year <= dt.date.today().year + 2 and 10000 <= value <= 2000000 and value % 30 == 0:
            # Reject contradictory values for a year instead of selecting one.
            if year in out and out[year] != value:
                out[year] = None
            else:
                out[year] = value
    return {year: amount for year, amount in out.items() if amount is not None}


def fetch_official_limits(timeout=6, opener=None):
    """Network I/O. Run only in worker thread; caller persists verified values."""
    opener = opener or urlopen
    req = Request(OFFICIAL_ZUS_URL, headers={'User-Agent': 'Mozilla/5.0 (KW Payroll; official contribution rates)'})
    with opener(req, timeout=timeout) as response:
        final_url = response.geturl() if hasattr(response, 'geturl') else OFFICIAL_ZUS_URL
        # No untrusted host, even after redirect.
        from urllib.parse import urlparse
        u = urlparse(final_url)
        if u.scheme != 'https' or u.hostname not in {'bip.zus.pl', 'www.zus.pl', 'zus.pl'}:
            raise ValueError('Official ZUS source unexpectedly redirected')
        raw = response.read(1500000)
        encoding = response.headers.get_content_charset() if hasattr(response, 'headers') else None
    return extract_official_limits(raw.decode(encoding or 'utf-8', errors='replace'))


def update_verified_cache(cache, rates):
    """Return (new_cache, new_years, conflicts) without modifying input data."""
    updated = dict(cache or {})
    added, conflicts = [], []
    for year, amount in rates.items():
        year = int(year)
        amount = int(amount)
        if year in PUBLISHED:
            if PUBLISHED[year] != amount:
                conflicts.append(year)
            continue
        if annual_limit(year, updated) is not None:
            if annual_limit(year, updated) != amount:
                conflicts.append(year)
            continue
        if 2000 <= year <= dt.date.today().year + 2 and 10000 <= amount <= 2000000 and amount % 30 == 0:
            updated[str(year)] = {
                'amount': amount, 'source': OFFICIAL_ZUS_URL,
                'verified_on': dt.date.today().isoformat(),
            }
            added.append(year)
    return updated, sorted(added), sorted(set(conflicts))
