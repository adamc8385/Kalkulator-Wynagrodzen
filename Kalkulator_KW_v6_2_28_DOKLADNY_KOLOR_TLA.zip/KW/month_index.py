"""In-memory month lookup; does not mutate or persist work cards."""
from collections import defaultdict

def build(rows, excluded_file_ids, supported_date, accounting_month, db):
    result = defaultdict(list)
    excluded = set(excluded_file_ids)
    for row in rows:
        date = row.get('date')
        if not supported_date(date) or row.get('file_id') in excluded:
            continue
        month = accounting_month(date, db)
        if month is not None:
            result[month].append(row)
    return dict(result)
