"""Presentation-only dark/light themes for Tk widgets; never edits payroll data.

Preserves the existing dark palette on the main window. Popup surfaces adopt
one unified navy tone and the system caption uses the same live background.
"""
import tkinter as tk
from tkinter import ttk
from ui_assets import schedule_navy_titlebar

DARK = {'#081725':'#081725', '#10293c':'#10293c', '#193a51':'#193a51'}
LIGHT = {
    # Refined light mode: warm-white paper, white cards and dark-blue navigation.
    # This is colour mapping ONLY; widget geometry, image banners, and payroll stay intact.
    '#081725':'#f7f9fc', '#10293c':'#ffffff', '#193a51':'#edf3f9',
    '#142f43':'#e5eff7', '#1b394f':'#d9e8f4',
    '#092238':'#0b3152',
    '#163447':'#2c587a', '#173c56':'#194d70', '#365b72':'#c0d0de',
    '#476079':'#b6c9d8', '#24465c':'#ffffff',
    '#d8b16b':'#9b641c', '#f2f6f9':'#1a344d', '#aec0cd':'#526c80',
    '#b9dff5':'#dceaf6', '#ffffff':'#ffffff',
}
# Match the main panel and dashboard metric-card background EXACTLY.
# Reference from the existing UI palette: PANEL = '#10293c'.
DARK_POPUP = '#10293c'
DARK_MAIN_SURFACE = '#10293c' 
LIGHT_POPUP = '#f4f8fc'


def _hex(value):
    return value.lower().strip() if isinstance(value,str) else value


def _change_widget(widget, mode, popup=False, popup_surface=None):
    if not isinstance(widget,(tk.Frame,tk.Label,tk.Button,tk.Canvas,tk.Checkbutton,
                              tk.Radiobutton,tk.Entry,tk.Text,tk.LabelFrame,tk.Listbox,
                              tk.Scale,tk.Spinbox,tk.Toplevel,tk.Tk)):
        return
    if not hasattr(widget,'_theme_initial_options'):
        widget._theme_initial_options = {}
        for option in ('bg','fg','activebackground','activeforeground',
                       'insertbackground','highlightbackground','selectcolor'):
            try: widget._theme_initial_options[option] = widget.cget(option)
            except tk.TclError: pass
    original=widget._theme_initial_options
    is_close=(isinstance(widget,tk.Button) and
              str(widget.cget('text')).strip().casefold() in ('zamknij','close','anuluj','cancel'))
    result={}
    for option,value in original.items():
        source=_hex(value)
        mapped=value
        if mode=='light':
            mapped=LIGHT.get(source,value)
            # White navigation/toolbar pictograms need a dark button surface
            # in light mode; otherwise they disappear against light-blue.
            if isinstance(widget,tk.Button) and option in ('bg','fg'):
                widget_text=str(widget.cget('text')).strip().lower()
                on_nav=(widget_text in ('pulpit','karty pracy','podsumowanie','rozliczenie',
                                         'zestawienie do a1','kalendarz','historia','ustawienia',
                                         'wyloguj się','log out') or
                        bool(widget.cget('image')) and not widget_text.startswith('◀'))
                if on_nav and source in ('#193a51','#163447') and option=='bg':
                    mapped='#1b4b6d'
                if on_nav and option=='fg' and source in ('#f2f6f9','#d8b16b'):
                    mapped='#ffffff'

            if source=='#092238' and option in ('fg','activeforeground'):
                mapped='#f8fbff' if source!='#d8b16b' else '#f3c775'
            if option in ('fg','activeforeground') and _hex(original.get('bg'))=='#092238':
                mapped='#f4c877' if source=='#d8b16b' else '#ffffff'
            if popup and option in ('bg','activebackground') and source in DARK:
                mapped=LIGHT_POPUP
            if popup and is_close and option=='bg':
                mapped='#bfd5e5'
            # Green action buttons must retain high-contrast white lettering.
            if option in ('fg','activeforeground') and source=='#ffffff':
                mapped='#243b4d'
            if option in ('fg','activeforeground') and isinstance(widget,tk.Button):
                if _hex(original.get('bg')) in ('#138567','#0d896b'):
                    mapped='#ffffff'
        else:
            if popup and option in ('bg','activebackground'):
                # Previous code flattened ALL three navy shades.  This made
                # popups far too dark and also erased the month-tile and row
                # contrast.  Only the dialog's base canvas needs repainting.
                # Panels (#10293c) and dark-blue bands (#193a51) retain their
                # original colours, as do explicit alternating row stripes.
                if source == '#081725' or (
                    isinstance(widget, (tk.Toplevel, tk.Tk)) and source in DARK
                ):
                    mapped = DARK_MAIN_SURFACE
            if popup and is_close and option=='bg':mapped='#2b5670'
        if mapped != widget.cget(option): result[option]=mapped
    if result:
        try: widget.configure(**result)
        except tk.TclError:
            for name,val in result.items():
                try: widget.configure(**{name:val})
                except tk.TclError:pass
    # Form entries: always white, even when the rest of the form is dark.
    if isinstance(widget,(tk.Entry,tk.Spinbox)):
        try:widget.configure(bg='#ffffff',fg='#172e40',insertbackground='#172e40')
        except tk.TclError:pass


def apply_tree(widget,mode='dark',popup=False,popup_surface=None):
    """Reversible recolouring. Uses original dark colours per Tk widget."""
    try:
        if not widget.winfo_exists():return
        _change_widget(widget,mode,popup,popup_surface)
        for child in widget.winfo_children():apply_tree(child,mode,popup,popup_surface)
    except tk.TclError:pass


def apply_style(style, mode):
    """Consistent ttk tables, tabs and scrollbars in both modes."""
    if mode == 'light':
        popup_bg, popup_fg, header_bg, header_fg = '#ffffff','#193047','#dce9f3','#19394e'
    else:
        popup_bg, popup_fg, header_bg, header_fg = DARK_MAIN_SURFACE,'#f2f6f9','#193a51','#f2f6f9'
    for name in ('Audit.Treeview','LeaveHistory.Treeview'):
        style.configure(name,background=popup_bg,fieldbackground=popup_bg,
                        foreground=popup_fg,borderwidth=0,font=('Segoe UI',10),rowheight=30)
        style.map(name,background=[('selected','#355773')],foreground=[('selected','#ffffff')])
        style.configure(name+'.Heading',background=header_bg,foreground=header_fg,
                        font=('Segoe UI',10,'bold'),padding=(8,9),relief='flat')
        style.map(name+'.Heading',background=[('active',header_bg),('pressed',header_bg)],
                  foreground=[('active',header_fg),('pressed',header_fg)])
    if mode=='light':
        style.configure('Payroll.TNotebook',background='#f7f9fc')
        style.configure('Payroll.TNotebook.Tab',background='#e2eaf3',foreground='#243b4d')
        style.map('Payroll.TNotebook.Tab',background=[('selected','#ffffff'),('!selected','#e2eaf3')],
                  foreground=[('selected','#183649'),('!selected','#243b4d')])
        style.configure('Payroll.Treeview.Heading',background='#dce9f3',foreground='#19394e')
        style.map('Payroll.Treeview.Heading',background=[('active','#bad2e0'),('pressed','#bad2e0'),('!active','#dce9f3')],
                  foreground=[('active','#19394e'),('pressed','#19394e')])
        style.configure('Payroll.Treeview',background='#ffffff',foreground='#193047',fieldbackground='#ffffff')
    else:
        style.configure('Payroll.TNotebook',background='#10293c')
        style.configure('Payroll.TNotebook.Tab',background='#193a51',foreground='#ffffff')
        style.map('Payroll.TNotebook.Tab',background=[('selected','#b9dff5'),('!selected','#193a51')],
                  foreground=[('selected','#123d5c'),('!selected','#ffffff')])
        style.configure('Payroll.Treeview.Heading',background='#173c56',foreground='#ffffff')
        style.map('Payroll.Treeview.Heading',background=[('active','#173c56'),('pressed','#173c56'),('!active','#173c56')],
                  foreground=[('active','#ffffff'),('pressed','#ffffff')])
        style.configure('Payroll.Treeview',background='#ffffff',foreground='#193047',fieldbackground='#ffffff')


def update_caption(window):
    try:
        if window.winfo_exists():
            mode=getattr(window,'_payroll_theme_mode','dark')
            background=window.cget('bg')
            # Native caption contrast follows the actual background, not a stale constant.
            schedule_navy_titlebar(window,background=background,
                                  foreground='#ffffff' if mode=='dark' else '#1c3449')
    except tk.TclError:pass


def register_popup(win, app, keep_visible=False, popup_surface=None):
    """Apply theme after the dialog's child widgets exist; retain native chrome.

    keep_visible re-raises the popup above *its own application* upon returning
    to the main window; does not set always-on-top across other applications.
    """
    root=app.root
    def refresh():
        if not win.winfo_exists():return
        mode=getattr(app,'theme_mode','dark')
        win._payroll_theme_mode=mode
        apply_tree(win,mode,popup=True,popup_surface=popup_surface)
        update_caption(win)
    win._refresh_payroll_theme=refresh
    pending=[win.after(90,refresh)]
    def cancel_on_destroy(event):
        if event.widget is win:
            for task in pending:
                try:win.after_cancel(task)
                except tk.TclError:pass
    win.bind('<Destroy>',cancel_on_destroy,add='+')
    if keep_visible:
        def keep(event):
            if event.widget is root and win.winfo_exists():
                win.after_idle(lambda:win.lift(root) if win.winfo_exists() else None)
        handler=root.bind('<FocusIn>',keep,add='+')
        def click_parent(event):
            try:
                if event.widget.winfo_toplevel() is root and win.winfo_exists():
                    win.after_idle(lambda: win.lift(root) if win.winfo_exists() else None)
            except tk.TclError:pass
        click_handler=root.bind('<ButtonRelease-1>',click_parent,add='+')
        def cleanup(event):
            if event.widget is win:
                for sequence, ident in (('<FocusIn>',handler),('<ButtonRelease-1>',click_handler)):
                    try:root.unbind(sequence,ident)
                    except tk.TclError:pass
        win.bind('<Destroy>',cleanup,add='+')
    return win
