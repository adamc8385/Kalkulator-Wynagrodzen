"""Versioned user payroll parameters by the YYYY-MM effective period.

Never infer historical salary amounts that were not saved. Existing databases
receive a baseline snapshot of their last known settings without destroying
legacy keys. Period snapshots remain intact when an earlier period is edited.
"""
import re

PAYROLL_FIELDS=(
 'salary','offshore','travel_rate','costs','pit_relief',
 'ppe_auto_enabled','ppo_auto_enabled','ppe_employer_override','ppo_employer_override','ppk','benefits_in_social',
 'employer_pension_taxable','edenred_benefit','luxmed_benefit',
 'ppe_employer_reference','ppo_employer_reference','ppe_extra',
 'car_bonus_count','shared_room_nights','domestic_diet_extra_days',
 'risk_days','risk_factor','other_gross','other_deductions'
)

def snapshot(db):
    return {k:float(db.get(k,0) or 0) for k in PAYROLL_FIELDS}

def seed_baseline(db):
    if not isinstance(db.get('legacy_settings_baseline'),dict):
        db['legacy_settings_baseline']=snapshot(db)
    if not isinstance(db.get('monthly_settings_history'),dict):
        db['monthly_settings_history']={}

def active_month_version(db,month_id):
    """Latest saved state from month <= selected, else pre-upgrade baseline."""
    history=db.get('monthly_settings_history') or {}
    available=[m for m,v in history.items() if isinstance(m,str) and isinstance(v,dict) and re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',m) and m<=month_id]
    if not available:
        return dict(db.get('legacy_settings_baseline') or snapshot(db)),None
    period=max(available)
    return dict(history[period]),period

def save_month_version(db,month_id,values):
    if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',month_id):
        raise ValueError('Nieprawidłowy miesiąc rozliczeniowy')
    seed_baseline(db)
    snap,_=active_month_version(db,month_id)
    snap.update({k:float(values[k]) for k in PAYROLL_FIELDS if k in values})
    # Any legacy manually saved statutory cap is ignored/removed.
    snap.pop('social_limit',None)
    db['monthly_settings_history'][month_id]=snap
    # Do not overwrite the global latest configuration when correcting history.
    valid=[m for m,v in db['monthly_settings_history'].items()
           if isinstance(m,str) and isinstance(v,dict)
           and re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',m)]
    if valid and month_id==max(valid):
        db.update(snap)
    return snap
