"""Company work-calendar dates transcribed from supplied 2024–2026 PDFs.

The *company schedule* and *statutory holiday* are distinct concepts.
An employer-granted free day is NOT silently recategorised as a public holiday,
and special holiday remuneration is governed separately by the FSE rules.
"""
import datetime as dt
import calendar

COMPANY_DAYS_OFF = {
    # Sources: supplied WPL/FS company calendars and overtime editions,
    # 2024 and 2025. These are employer days off, not statutory holidays.
    2024: {
        dt.date(2024, 3, 29): ('Wielki Piątek — wolne za 6 stycznia', 'Good Friday — day off in lieu of 6 January'),
        dt.date(2024, 12, 24): ('Wigilia — dodatkowy dzień wolny firmy', 'Christmas Eve — additional employer day off'),
    },
    2025: {
        dt.date(2025, 4, 18): ('Wielki Piątek — dodatkowy dzień wolny', 'Good Friday — additional employer day off'),
        dt.date(2025, 5, 2): ('Dzień wolny za 3 maja', 'Day off in lieu of 3 May'),
        dt.date(2025, 11, 10): ('Dzień wolny za 1 listopada', 'Day off in lieu of 1 November'),
        # 24 December is a statutory holiday from 2025: statutory_holidays().
    },
    2026: {
        dt.date(2026, 4, 3): ('Wielki Piątek — wolne za 15 sierpnia', 'Good Friday — day off in lieu of 15 August'),
        dt.date(2026, 12, 31): ('Dzień wolny za 26 grudnia', 'Day off in lieu of 26 December'),
    }
}


def easter_sunday(year):
    a=year%19; b=year//100; c=year%100; d=b//4; e=b%4; f=(b+8)//25
    g=(b-f+1)//3; h=(19*a+b-d-g+15)%30; i=c//4; k=c%4
    l=(32+2*e+2*i-h-k)%7; m=(a+11*h+22*l)//451
    return dt.date(year, (h+l-7*m+114)//31, (h+l-7*m+114)%31+1)


def statutory_holidays(year):
    fixed=[(1,1),(1,6),(5,1),(5,3),(8,15),(11,1),(11,11),(12,25),(12,26)]
    if year>=2025: fixed.append((12,24))
    easter=easter_sunday(year)
    return ({dt.date(year,m,d) for m,d in fixed}
            | {easter,easter+dt.timedelta(days=1),easter+dt.timedelta(days=49),easter+dt.timedelta(days=60)})


def day_category(day):
    if day in statutory_holidays(day.year): return 'holiday'
    if day in COMPANY_DAYS_OFF.get(day.year,{}): return 'company'
    if day.weekday()==6: return 'sunday'
    if day.weekday()==5: return 'saturday'
    return 'workday'


def day_description(day,language='pl'):
    category=day_category(day)
    if category=='company': return COMPANY_DAYS_OFF[day.year][day][language=='en']
    pl={'holiday':'Święto ustawowe','sunday':'Niedziela','saturday':'Sobota — dzień wolny','workday':'Zwykły dzień pracy'}
    en={'holiday':'Statutory public holiday','sunday':'Sunday','saturday':'Saturday — scheduled day off','workday':'Regular workday'}
    return (en if language=='en' else pl)[category]


def scheduled_hours(year,month):
    """Firm schedule for confirmed 2024–2026 years; statutory monthly nominal otherwise.

    In published company years, days off explicitly replace Saturday-holiday
    compensation dates, hence the Saturday holiday is not deducted *again* from
    its calendar month. 2026-04=160, 2026-08=168; full 2026=2008h.
    """
    days=[dt.date(year,month,d) for d in range(1,calendar.monthrange(year,month)[1]+1)]
    if year in COMPANY_DAYS_OFF:
        return 8*sum(d.weekday()<5 and day_category(d)=='workday' for d in days)
    weekdays=sum(d.weekday()<5 for d in days)
    holidays=sum(d.month==month and d.weekday()!=6 for d in statutory_holidays(year))
    return 8*(weekdays-holidays)


def has_confirmed_company_schedule(year):
    return year in COMPANY_DAYS_OFF


def payroll_week_nominal(iso_year,week_numbers):
    """Regular hours in entire ISO payroll weeks assigned to a month.

    Iterate real dates, so adjacent-year days, public holidays, and confirmed
    employer days off are accounted for on their own calendar dates.
    Weekday-only scheduled hours are 8h/day; repeated weeks count once.
    """
    days=set()
    for raw_week in week_numbers:
        week=int(raw_week)
        try:
            monday=dt.date.fromisocalendar(int(iso_year),week,1)
        except ValueError as error:
            raise ValueError(f'Invalid ISO week {iso_year}-W{week:02d}') from error
        for day_offset in range(7):
            days.add(monday+dt.timedelta(days=day_offset))
    return 8*sum(day_category(day)=='workday' for day in days)
