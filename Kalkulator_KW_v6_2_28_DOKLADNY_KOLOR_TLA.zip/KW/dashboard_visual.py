"""Dashboard visuals for ACH/KW.

Pure presentation: no reads/writes of payroll settings, calculations or cards.
Draws crisp antialiased vector-like icons in Pillow, then presents them in
responsive Tk canvases. No platform-dependent emoji fonts are required.
"""
import tkinter as tk
from PIL import Image, ImageDraw, ImageTk

NAVY = '#0a2947'
BLUE = '#07588d'
GOLD = '#e4a920'
LIGHT_GOLD = '#f6c75c'
PAPER = '#f7f9fc'


def _rgb(color):
    color = color.lstrip('#')
    return tuple(int(color[i:i+2], 16) for i in (0, 2, 4))


def _interpolate(first, second, amount):
    return tuple(round(a + (b - a) * amount) for a, b in zip(first, second))


def _vector_icon(kind, size, color):
    """Render coherent iconography without installed font or image assets."""
    unit = 10
    s = max(40, int(size * unit))
    image = Image.new('RGBA', (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(image)
    col = _rgb(color) + (255,)
    fill = _rgb('#f9c75c') + (238,)
    dark_fill = _rgb('#0a3554') + (255,)
    def X(v):
        return round(v * s / 100)
    def line(points, width=4, color_=col):
        d.line([(X(x), X(y)) for x, y in points], fill=color_, width=max(1, X(width)), joint='curve')
    def ell(box, width=3, color_=col, fill_=None):
        d.ellipse(tuple(map(X, box)), outline=color_, fill=fill_, width=max(1, X(width)))
    def rr(box, radius=7, width=3, color_=col, fill_=None):
        d.rounded_rectangle(tuple(map(X, box)), radius=X(radius), outline=color_, fill=fill_, width=max(1, X(width)))
    if kind == 'coins':
        stacks=((12,49,29,30),(38,40,29,30),(58,28,29,30))
        for lx, top, w, h in stacks:
            bottom=top+h
            d.rectangle((X(lx), X(top+8), X(lx+w), X(bottom-5)), fill=fill, outline=col, width=X(2.5))
            ell((lx, top, lx+w, top+14), 2.5, col, fill)
            for yy in (top+11, top+19, top+27):
                d.arc(tuple(map(X, (lx, yy-7, lx+w, yy+7))), 0, 180, fill=col, width=X(2.5))
    elif kind == 'wallet':
        rr((14, 30, 74, 72), 8, 4, col, None)
        rr((48, 39, 86, 66), 7, 4, col, fill)
        line([(18, 31), (66, 18), (75, 24)], 3)
        ell((62, 48, 68, 54), 2, col, dark_fill)
    elif kind == 'clock':
        ell((15, 15, 85, 85), 5)
        line([(50, 28), (50, 52), (67, 63)], 5)
    elif kind == 'double_clock':
        ell((8, 20, 56, 68), 5)
        line([(32, 31), (32, 46), (43, 54)], 4)
        ell((44, 32, 92, 80), 5)
        line([(68, 43), (68, 58), (80, 66)], 4)
    elif kind in ('calendar', 'calendar_x', 'calendar_check'):
        rr((12, 20, 88, 88), 7, 4)
        line([(12, 38), (88, 38)], 4)
        for x in (31, 68):
            line([(x, 10), (x, 28)], 5)
        if kind == 'calendar_x':
            line([(35, 56), (63, 76)], 5)
            line([(63, 56), (35, 76)], 5)
        elif kind == 'calendar_check':
            line([(28, 64), (43, 76), (73, 49)], 5)
        else:
            for x in (29, 49, 68):
                for y in (55, 72):
                    ell((x-2.5,y-2.5,x+2.5,y+2.5), 1, col, col)
    elif kind == 'hourglass':
        line([(24, 13), (76, 13)], 4)
        line([(24, 87), (76, 87)], 4)
        line([(32, 19), (68, 19), (58, 38), (50, 49), (42, 38), (32, 19)], 4)
        line([(32, 81), (68, 81), (58, 62), (50, 51), (42, 62), (32, 81)], 4)
        line([(43, 46), (57, 46)], 3)
        line([(43, 54), (57, 54)], 3)
    elif kind == 'chart':
        for box in ((16, 58, 29, 84), (41, 43, 54, 84), (66, 24, 79, 84)):
            rr(box, 2, 3, col, None)
        line([(10, 87), (90, 87)], 3)
    elif kind == 'umbrella':
        d.pieslice(tuple(map(X,(13, 15, 88, 70))), 180, 360, fill=fill, outline=col, width=X(4))
        line([(50, 43), (50, 83), (61, 83), (67, 76)], 5)
        line([(23, 43), (34, 49), (50, 43), (66, 49), (79, 43)], 3)
    elif kind == 'home':
        line([(11, 46),(50, 13),(89,46)],6)
        rr((24,43,76,88),4,4)
        rr((44,62,58,88),2,3)
    elif kind == 'plane':
        # Simple recognizable aircraft outline selected by user (option 1).
        # Thick contours stay readable at 16–24px after supersampling.
        line([(10,64),(27,56),(12,43),(20,36),(46,46),(73,17),
              (88,13),(91,18),(87,29),(59,56),(68,83),(59,91),
              (46,65),(23,81),(12,75),(28,58)],5)
    elif kind == 'moon':
        # Thick tapered crescent: the user's chosen moon silhouette.
        # Remove the inner circle from a binary mask, then supersample.
        outer=Image.new('L',(s,s),0)
        md=ImageDraw.Draw(outer)
        md.ellipse((X(16),X(9),X(84),X(91)), fill=255)
        md.ellipse((X(35),X(1),X(101),X(74)), fill=0)
        image.putalpha(outer)
        # For a solid symbol, use the target color underneath the alpha mask.
        solid=Image.new('RGBA',(s,s),col)
        solid.putalpha(outer)
        image=solid
    elif kind == 'sun':
        ell((27, 27, 73, 73), 4, col, fill)
        rays=[((50,9),(50,21)),((50,79),(50,91)),((9,50),(21,50)),((79,50),(91,50)),
              ((19,19),(28,28)),((72,72),(81,81)),((19,81),(28,72)),((72,28),(81,19))]
        for a,b in rays:
            line([a,b],4)
    elif kind == 'ship':
        line([(10,61),(24,80),(72,80),(90,61),(10,61)],5)
        line([(48,15),(48,60)],5)
        line([(48,20),(80,48),(48,48)],4)
    elif kind == 'check':
        rr((15,17,85,85),9,5)
        line([(29,52),(45,66),(74,35)],7)
    elif kind == 'car':
        rr((11,42,89,73),9,5)
        line([(24,42),(36,23),(66,23),(77,42)],4)
        ell((19,66,35,82),4)
        ell((66,66,82,82),4)
    else:
        ell((16,16,84,84),5)
        line([(50,31),(50,54),(68,65)],5)
    return image.resize((int(size), int(size)), Image.Resampling.LANCZOS)


def icon_image(root, kind, theme, size=46, color=None):
    # Callers already convert their geometry to UI-scale pixels. Scaling
    # again would make icons oversized at 125-200% Windows DPI.
    pixel_size=max(1, round(size))
    if color is None:
        color = GOLD if theme == 'light' else LIGHT_GOLD
        if kind in ('calendar','calendar_x','calendar_check','check'):
            color = '#17649c' if theme == 'light' else '#e6f0f8'
    cache=getattr(root,'_dashboard_icon_cache',None)
    if cache is None:
        cache={}
        root._dashboard_icon_cache=cache
    key=(kind,theme,pixel_size,color)
    if key not in cache:
        cache[key]=ImageTk.PhotoImage(_vector_icon(kind,pixel_size,color), master=root)
    return cache[key]


def _panel_gradient(width, height, colors, radius=9, outline='#bcd0e1', shadow=True, base_bg=PAPER):
    """One image per resize, rounded corners, restrained shadow and gradient."""
    w, h = max(2,int(width)), max(2,int(height))
    img = Image.new('RGB', (w, h), _rgb(base_bg))
    d = ImageDraw.Draw(img)
    if shadow:
        d.rounded_rectangle((2, 3, w-1, h-1), radius=radius,
                            fill=_rgb('#dce6ef'))
    top, bottom = (_rgb(c) for c in colors)
    area = Image.new('RGB', (w, h), top)
    pixels = ImageDraw.Draw(area)
    for y in range(h):
        color = _interpolate(top, bottom, y/max(1,h-1))
        pixels.line([(0,y),(w,y)],fill=color)
    mask = Image.new('L',(w,h),0)
    ImageDraw.Draw(mask).rounded_rectangle((1,1,w-3,h-4),radius=radius,fill=255)
    img.paste(area,(0,0),mask)
    d.rounded_rectangle((1,1,w-3,h-4),radius=radius,
                        outline=_rgb(outline),width=1)
    return img


def metric_card(parent, title, value, icon, theme, root, scale=1, prominent=False, vacation=False):
    """Compact responsive KPI with a separate, left-aligned pictogram."""
    light = theme=='light'
    h = int((62 if vacation else 72)*scale)
    desired_width = int((182 if vacation else 205)*scale)
    bg = '#f7f9fc' if light else '#081725'
    card = tk.Canvas(parent, bg=bg, bd=0, highlightthickness=0,
                     width=desired_width, height=h)
    card.pack(side='left',fill='both',expand=True,padx=max(2,int(4*scale)),pady=max(1,int(2*scale)))
    photo = icon_image(root,icon,theme,int((24 if vacation else 27)*scale))
    card._metric_icon=photo
    current=[None]
    def repaint(event=None):
        w=card.winfo_width(); height=card.winfo_height()
        if w<20 or height<20:return
        if current[0]==(w,height):return
        current[0]=(w,height)
        card.delete('all')
        if light:
            gradient=('#237fb7','#075185') if prominent else (('#fffaf0','#fdf0d4') if vacation and icon=='hourglass' else ('#ffffff','#eaf3fb'))
            border='#d6a94a' if vacation and icon=='hourglass' else ('#b8cfe2' if not prominent else '#116197')
        else:
            gradient=('#10293c','#10293c') if not vacation else ('#193a51','#193a51')
            border='#365b72'
        bitmap=_panel_gradient(w,height,gradient,outline=border,shadow=light,base_bg=bg)
        card._metric_background=ImageTk.PhotoImage(bitmap,master=root)
        card.create_image(0,0,image=card._metric_background,anchor='nw')
        x=int((12 if vacation else 14)*scale)
        icon_y=height//2
        card.create_image(x,icon_y,image=card._metric_icon,anchor='w')
        textx=x+int((31 if vacation else 35)*scale)
        top_y=height//2-int((13 if vacation else 14)*scale)
        label_color='#fffdfa' if light and prominent else ('#122d4c' if light else '#aec0cd')
        value_color='#ffffff' if light and prominent else ('#a36b17' if light and vacation and icon=='hourglass' else '#103762' if light else '#d8b16b')
        card.create_text(textx,top_y,anchor='w',text=title,fill=label_color,
                         font=('Segoe UI',max(8,round((8 if vacation else 8)*scale)),'bold'))
        card.create_text(textx,top_y+int(22*scale),anchor='w',text=value,fill=value_color,
                         font=('Segoe UI',max(11,round((13 if vacation else 14)*scale)),'bold'))
    card.bind('<Configure>',repaint)
    return card


def section_heading(parent,title,icon,theme,root,scale=1,command=None,button_text=None):
    """Section title with no rewritten texts; premium banner in light only."""
    light=theme=='light'
    height=int((40 if light else 42)*scale)
    bg='#ffffff' if light else '#10293c'
    container=tk.Frame(parent,bg=bg)
    container.pack(fill='x')
    canvas=tk.Canvas(container,bg=bg,bd=0,highlightthickness=0,height=height)
    canvas.pack(fill='x')
    icon_photo=icon_image(root,icon,theme,int(24*scale))
    canvas._heading_icon=icon_photo
    cache=[None]
    def redraw(event=None):
        w=canvas.winfo_width(); h=canvas.winfo_height()
        if w<20 or h<20:return
        if cache[0]==(w,h):return
        cache[0]=(w,h)
        canvas.delete('all')
        if light:
            bitmap=_panel_gradient(w,h,('#126299','#063c6c'),radius=8,outline='#166097',shadow=False)
            d=ImageDraw.Draw(bitmap)
            slash_x=min(w-90,max(220,round(w*.46)))
            d.polygon([(slash_x,1),(slash_x+13,1),(slash_x-9,h-4),(slash_x-22,h-4)],fill=_rgb('#e7af39'))
            canvas._heading_bg=ImageTk.PhotoImage(bitmap,master=root)
            canvas.create_image(0,0,image=canvas._heading_bg,anchor='nw')
        x=int(18*scale)
        canvas.create_image(x,h//2,image=canvas._heading_icon,anchor='w')
        canvas.create_text(x+int(34*scale),h//2,anchor='w',text=title,
                           fill='#fffefa' if light else '#d8b16b',
                           font=('Segoe UI',max(11,round(12.5*scale)),'bold'))
    canvas.bind('<Configure>',redraw)
    if command is not None:
        btn=tk.Button(container,text=button_text,command=command,
                      bg='#ffffff' if light else '#193a51',
                      fg='#123453' if light else '#f2f6f9',
                      font=('Segoe UI',9),relief='flat',bd=0,padx=12,pady=6)
        btn.place(relx=1,x=-int(12*scale),rely=.5,anchor='e')
    return container
