"""Opt-in-safe local diagnostics: timing only; never log salary, user data or card paths."""
import logging
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

_logger = None

def initialize(data_dir, edition):
    global _logger
    if _logger is not None:
        return _logger
    logger = logging.getLogger('payroll.performance.' + edition)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    try:
        Path(data_dir).mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(Path(data_dir) / 'wydajnosc.log',
                                      maxBytes=512 * 1024, backupCount=2,
                                      encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(handler)
        logger.info('startup edition=%s', edition)
    except OSError:
        # Lack of logging must never prevent payroll from operating.
        logger.addHandler(logging.NullHandler())
    _logger = logger
    return logger

def measure(event, start, **numbers):
    if _logger is None:
        return
    allowed = {'page', 'cache', 'rows', 'files', 'changed', 'errors'}
    values = ' '.join('%s=%s' % (k, v) for k, v in numbers.items()
                      if k in allowed and isinstance(v, (str, int, float))
                      and (k != 'page' or v in {'Pulpit', 'Karty pracy', 'Podsumowanie',
                               'Rozliczenie', 'Zestawienie do A1', 'Kalendarz',
                               'Historia', 'Ustawienia'}))
    # Strict event allowlist prevents accidental inclusion of sensitive data.
    if event not in {'app_init', 'page_render', 'monthly_index', 'card_sync'}:
        return
    try:
        _logger.info('%s duration_ms=%.2f %s', event,
                     (time.perf_counter() - start) * 1000, values)
    except (OSError, ValueError, TypeError):
        pass

def monotonic():
    return time.perf_counter()


def record_error(stage, exception):
    """Log only exception class and known operation; no traceback, PII or secrets."""
    if _logger is None or stage not in {'gui_callback', 'card_sync'}:
        return
    try:
        _logger.error('%s type=%s', stage, type(exception).__name__)
    except (OSError, ValueError, TypeError):
        pass
