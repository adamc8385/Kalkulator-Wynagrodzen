"""Atomic JSON data persistence for the payroll calculator (v6.0).

A verified previous version is kept as dane.json.bak. A corrupted original
is never silently replaced by a blank default database.
"""
import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path


class DataIntegrityError(RuntimeError):
    pass


def _read_verified(path):
    content = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(content, dict):
        raise DataIntegrityError('Baza danych musi zawierać obiekt JSON.')
    return content


def load_verified(path):
    """Return (data, recovered). Missing DB means first run, NOT corruption."""
    path = Path(path)
    if not path.exists():
        backup = path.with_name(path.name + '.bak')
        if backup.exists():
            try:
                return _read_verified(backup), True
            except (OSError, ValueError, DataIntegrityError) as error:
                raise DataIntegrityError(
                    'Brak pliku dane.json, a kopia zapasowa jest uszkodzona. '
                    'Nie utworzono pustej bazy. Plik: ' + str(backup)
                ) from error
        return None, False
    try:
        return _read_verified(path), False
    except (OSError, ValueError, DataIntegrityError) as first_error:
        backup = path.with_name(path.name + '.bak')
        try:
            return _read_verified(backup), True
        except (OSError, ValueError, DataIntegrityError):
            raise DataIntegrityError(
                'Nie można odczytać bazy danych ani jej kopii zapasowej. '
                'Nie utworzono pustej bazy i nie nadpisano Twoich danych. '
                f'Plik: {path}. Pierwotny błąd: {first_error}'
            ) from first_error


def _write_temp(destination, payload):
    fd, filename = tempfile.mkstemp(prefix='.' + destination.name + '-',
                                    suffix='.tmp', dir=destination.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        return Path(filename)
    except BaseException:
        try: os.unlink(filename)
        except OSError: pass
        raise


def _replace_from_bytes(destination, payload):
    temp = _write_temp(destination, payload)
    try:
        os.replace(temp, destination)
    finally:
        if temp.exists(): temp.unlink()


def save_atomic(path, data):
    """Persist atomically and preserve last valid backup before replacing."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    backup = path.with_name(path.name + '.bak')
    if path.exists():
        try:
            _read_verified(path)
            # A valid previous main replaces the previous backup, atomically.
            _replace_from_bytes(backup, path.read_bytes())
        except (ValueError, DataIntegrityError):
            # A corrupted primary must not destroy a known-good .bak.
            if backup.exists():
                _read_verified(backup)
            stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
            corrupt = path.with_name(path.name + '.corrupt-' + stamp)
            shutil.copy2(path, corrupt)
    _replace_from_bytes(path, payload)
    if not backup.exists():
        _replace_from_bytes(backup, payload)
    # directory fsync is supported on Unix; Windows has different semantics.
    if hasattr(os, 'O_DIRECTORY'):
        try:
            fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
            try: os.fsync(fd)
            finally: os.close(fd)
        except OSError:
            pass
