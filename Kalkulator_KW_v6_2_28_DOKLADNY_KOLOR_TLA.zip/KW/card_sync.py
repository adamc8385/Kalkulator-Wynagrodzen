"""Incremental and reversible synchronization with a work-card folder.

A folder is authoritative only if it can be read. Workbooks manually imported
from *outside* the configured folder are never removed by its synchronization.
Existing digest-based card IDs are migrated to stable IDs based on absolute
source path. Consequently editing an Excel file does not reset its checkbox.
"""
from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path

from work_card_policy import MIN_CARD_YEAR, supported_date, unsupported_legacy_path, UnsupportedCardYear

_YEAR = re.compile(r'^\d{4}$')


def canonical(path):
    return os.path.normcase(str(Path(path).expanduser().resolve()))


def stable_id(path):
    return 'path-' + hashlib.sha256(canonical(path).casefold().encode('utf-8')).hexdigest()


def scan_root(root, year_folders=True):
    """Return (existing XLSX paths, successfully enumerated directories, warnings).

    The absence of a whole configured folder is *never* interpreted as the
    deletion of each of its files. Individual missing files in a readable
    existing directory, however, are removals.
    """
    root = Path(root).expanduser()
    if not root.is_dir():
        return [], set(), [f'Folder kart pracy jest niedostępny: {root}']
    dirs = [root]
    if year_folders:
        try:
            dirs += sorted(p for p in root.iterdir() if _YEAR.fullmatch(p.name) and int(p.name) >= MIN_CARD_YEAR and p.is_dir())
        except OSError as exc:
            return [], set(), [f'Nie można odczytać folderu {root}: {exc}']
    found = []
    scanned = set()
    warnings = []
    for directory in dirs:
        try:
            # Use iterdir (not glob), since glob may silently ignore I/O errors.
            items = list(directory.iterdir())
            files = [p for p in items if p.is_file() and p.suffix.lower() == '.xlsx'
                     and not p.name.startswith('~$')]
            found.extend(sorted(files))
            scanned.add(canonical(directory))
        except OSError as exc:
            warnings.append(f'Nie można odczytać {directory}: {exc}')
    return found, scanned, warnings


def sync_cards(db, paths, reader, scanned_dirs=(), allow_removals=False):
    """Mutate db in-place, return dict containing counts and errors.

    Only successfully parsed replacements are committed. A corrupted workbook
    never destroys its last valid imported data. Re-reading even identical-size
    files via SHA-256 detects Excel edits regardless of timestamps.
    """
    old_rows = list(db.get('rows', []))
    index = dict(db.get('source_index') or {})
    original_index = dict(index)
    excluded = set(db.get('excluded_files') or [])
    updates = {}
    errors = []
    visible = set()
    changed = imported = removed = 0

    by_path = {}
    for row in old_rows:
        if row.get('source_path'):
            by_path.setdefault(canonical(row['source_path']), []).append(row)
    for path in paths:
        key = canonical(path)
        if key in visible:
            continue
        if unsupported_legacy_path(path, by_path.get(key, [])):
            continue
        visible.add(key)
        existing = by_path.get(key, [])
        rec = index.get(key, {})
        try:
            # Read bytes for a definitive file-change check (mtime/size can be
            # artificially preserved by Excel, cloud syncing and ZIP restores).
            digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
            new_id = stable_id(key)
            old_ids = {r.get('file_id') for r in existing if r.get('file_id')}
            old_ids.discard(None)
            migrated = any(r.get('file_id') != new_id for r in existing)
            old_type_missing = any('work_type' not in r or r.get('needs_type_refresh')
                                   or 'sea_work_raw' not in r or 'work_type_raw' not in r
                                   for r in existing)
            same_hash = (rec.get('sha256') == digest or
                         (not rec and bool(existing) and old_ids == {digest}))
            # v6.2.13: one-time upgrade for travel times previously omitted
            # from the cached rows. Keep each source file and checkbox identity.
            missing_trip_clocks = any(
                (float(r.get('P', 0) or 0) + float(r.get('T', 0) or 0)) > 0
                and not r.get('work_clock_source') for r in existing)
            upgrade_trip_clock = (missing_trip_clocks and
                                  rec.get('travel_clock_parser_version') != 1)
            if existing and same_hash and not old_type_missing and not upgrade_trip_clock:
                # Migrate digest IDs to source-path IDs once, without parsing.
                if migrated or any(r.get('file') != Path(path).name for r in existing):
                    updates[key] = [dict(r, file_id=new_id, file=Path(path).name,
                                         source_path=key) for r in existing]
                    changed += 1 if migrated else 0
            else:
                fresh = [r for r in reader(Path(path)) if supported_date(r.get('date'))]
                if not fresh:
                    raise ValueError('Arkusz nie zawiera rozpoznanych danych karty pracy')
                updates[key] = [dict(r, file_id=new_id, file=Path(path).name,
                                     source_path=key) for r in fresh]
                if existing:
                    changed += 1
                else:
                    imported += 1
            if migrated and excluded.intersection(old_ids):
                excluded.add(new_id)
            index[key] = {'sha256': digest, 'file_id': new_id,
                          'name': Path(path).name, 'travel_clock_parser_version': 1}
        except UnsupportedCardYear:
            # Old workbooks are intentionally ignored, not import errors.
            continue
        except Exception as exc:
            errors.append(f'{Path(path).resolve()}: {exc}')
            # Do not delete or replace data from a file that cannot be parsed.

    scanned_dirs = {canonical(d) for d in scanned_dirs}
    removed_paths = set()
    if allow_removals:
        known = set(by_path).union(index)
        for key in known:
            # Only remove a card when the containing directory was actually
            # read. Disconnected drives and missing year directories are safe.
            if (canonical(Path(key).parent) in scanned_dirs and key not in visible
                    and not unsupported_legacy_path(key, by_path.get(key, []))):
                removed_paths.add(key)
        # Never treat a parse failure for an existing file as a missing file.
        removed = len([key for key in removed_paths if key in by_path or key in index])
        for key in removed_paths:
            index.pop(key, None)

    if updates or removed_paths:
        replace_paths = set(updates).union(removed_paths)
        new_rows = [r for r in old_rows if not r.get('source_path') or
                    canonical(r['source_path']) not in replace_paths or
                    not supported_date(r.get('date'))]
        for key, rows in updates.items():
            new_rows.extend(rows)
        db['rows'] = new_rows
        # Keep orphaned legacy `files` entries only if still referenced by rows.
        name_by_id = dict(db.get('files') or {})
        active_ids = {r.get('file_id') for r in new_rows}
        name_by_id = {fid: name for fid, name in name_by_id.items() if fid in active_ids}
        for key in updates:
            name_by_id[stable_id(key)] = Path(key).name
        db['files'] = name_by_id
        db['excluded_files'] = sorted(fid for fid in excluded if fid in active_ids)
    db['source_index'] = index
    return {'new': imported, 'updated': changed, 'removed': removed,
            'errors': errors, 'scanned': len(visible),
            'dirty': bool(updates or removed_paths or index != original_index)}
