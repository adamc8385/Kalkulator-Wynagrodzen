"""Separately run pure logic and GUI suites; existing tests remain in place."""
import argparse
import os
import subprocess
import sys
from pathlib import Path

GUI_MODULES = {
    'test_gui_simulator_v6218',
    'test_dashboard_visual_v6222',
    'test_dashboard_compact_v6223',
    'test_updates_v6220',
    'test_reminder_window_v629',
    'test_updates_v6211',
    'test_updates_v630',
    'test_eu_travel_and_fse_v625',
}
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--suite', choices=('logic','gui','all'), default='all')
    args = parser.parse_args()
    modules = sorted(f.stem for f in (Path(__file__).parent / 'tests').glob('test_*.py'))
    # Use unittest discovery on each existing file, without altering file layout.
    sets = [('logic', [x for x in modules if x not in GUI_MODULES]),
            ('gui', [x for x in modules if x in GUI_MODULES])]
    for kind, selected in sets:
        if args.suite not in ('all',kind):
            continue
        print('SUITE:',kind,'modules:',len(selected),flush=True)
        # PYTHONPATH is set to directory containing tested modules as in original run.
        for module in selected:
            command=[sys.executable,'-m','unittest',f'tests.{module}', '-q']
            result=subprocess.run(command,cwd=Path(__file__).parent)
            if result.returncode:
                return result.returncode
    return 0
if __name__=='__main__':
    raise SystemExit(main())
