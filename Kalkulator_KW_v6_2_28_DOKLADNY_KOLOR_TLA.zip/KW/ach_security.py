"""Local PIN gate. Email delivery requires a trusted external backend (not bundled)."""
import ach_dialogs
ach_dialogs.install()
import os, json, hashlib, hmac, secrets, re, time, urllib.request, urllib.error
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

DATA_DIR=Path(os.environ['KW_DATA_DIR']).expanduser() if os.environ.get('KW_DATA_DIR','').strip() else Path.home()/'.kalkulator_wynagrodzenia_kw'
STORE=DATA_DIR/'ach_security.json'
LEGACY_STORE=DATA_DIR/'kw_security.json'
ITER=600_000
OTP_URL='https://kalkulator-wynagrodzenia-auth.adamc8385.workers.dev'

def _otp(path, payload):
 """Send only email, purpose, request id and OTP. Never transmit PIN or recovery secret."""
 raw=json.dumps(payload).encode('utf-8')
 req=urllib.request.Request(OTP_URL+path,data=raw,headers={'Content-Type':'application/json; charset=utf-8','Accept':'application/json','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ACH-Payroll/6.2'},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=15) as response:
   result=json.load(response)
 except urllib.error.HTTPError as exc:
  try: error=json.loads(exc.read().decode('utf-8')).get('error','Błąd serwera')
  except Exception:error='Błąd HTTP '+str(exc.code)
  if exc.code == 403:
   error += ' (HTTP 403: serwer odrzucił żądanie; sprawdź identyfikator CF-Ray w logach Cloudflare)'
  raise ValueError(error) from exc
 except (urllib.error.URLError,TimeoutError,OSError) as exc:
  raise ValueError('Nie można połączyć się z serwerem weryfikacji. Sprawdź internet.') from exc
 if not isinstance(result,dict) or result.get('ok') is not True:raise ValueError('Nie udało się wykonać operacji.')
 return result

def _email_verify(parent,email,purpose):
 """Automatically send OTP on opening, allow throttled manual resend."""
 w=_window(parent,'KW — weryfikacja adresu e-mail')
 _label(w,'Adres: '+email)
 status=tk.Label(_target(w),text='Przygotowanie wiadomości...',bg='#0d2537',fg='#e5edf4',font=('Segoe UI',10),wraplength=390,justify='left')
 status.pack(anchor='w',padx=12,pady=(7,3))
 _label(w,'Kod z wiadomości (6 cyfr)');entry=_entry(w)
 result=[False];request_id=[None];sending=[False];last_send=[0.0]
 def send():
  if sending[0] or time.monotonic()-last_send[0]<60:return
  sending[0]=True;last_send[0]=time.monotonic()
  resend.config(state='disabled')
  status.config(text='Wysyłanie kodu...');w.update_idletasks()
  try:
   data=_otp('/otp/request',{'email':email,'purpose':purpose})
   request_id[0]=data.get('request_id')
   if not isinstance(request_id[0],str) or not (1<=len(request_id[0])<=128) or not request_id[0].isascii():
    raise ValueError('Serwer nie zwrócił prawidłowego identyfikatora żądania.')
   status.config(text='Kod weryfikacyjny został wysłany. Sprawdź skrzynkę odbiorczą i folder Spam, a następnie wpisz kod poniżej.')
   entry.focus_set()
  except ValueError as exc:
   status.config(text='Nie udało się wysłać kodu: '+str(exc))
  finally:
   sending[0]=False
   if w.winfo_exists():w.after(60000,lambda:resend.config(state='normal') if resend.winfo_exists() else None)
 def verify():
  if not request_id[0]:messagebox.showwarning('Brak kodu','Kod nie został jeszcze wysłany.',parent=w);return
  code=entry.get().strip()
  if not re.fullmatch(r'[0-9]{6}',code):messagebox.showerror('Błąd','Wpisz sześciocyfrowy kod.',parent=w);return
  try:
   data=_otp('/otp/verify',{'email':email,'purpose':purpose,'request_id':request_id[0],'code':code})
   if data.get('verified') is not True or data.get('purpose')!=purpose:raise ValueError('Serwer nie potwierdził weryfikacji.')
   result[0]=True;w.destroy()
  except ValueError as exc:messagebox.showerror('Niepoprawny kod',str(exc),parent=w)
 _btn(w,'Potwierdź kod',verify)
 resend=tk.Button(_target(w),text='Wyślij kod ponownie (po 60 s)',command=send,bg='#0d2537',fg='#d8ad62',font=('Segoe UI',10),relief='flat',state='disabled')
 resend.pack(padx=24,pady=6)
 _label(w,'Anulowanie nie zmienia zapisanych ustawień.')
 w.after(150,send)
 _wait(w)
 return result[0]


def _hash(secret,salt):
 return hashlib.pbkdf2_hmac('sha256',secret.encode('utf-8'),bytes.fromhex(salt),ITER).hex()
class SecurityStoreError(RuntimeError):
 """Existing authentication data could not be safely loaded; fail closed."""


def _read_security_profile(path):
 try:
  result=json.loads(path.read_text(encoding='utf-8'))
 except (OSError, ValueError) as exc:
  raise SecurityStoreError('Nie można odczytać pliku zabezpieczeń: '+str(path)) from exc
 if not isinstance(result,dict) or not result.get('pin_hash') or not result.get('pin_salt'):
  raise SecurityStoreError('Niekompletny plik zabezpieczeń: '+str(path))
 return result


def _load():
 if STORE.exists():
  return _read_security_profile(STORE)
 if not LEGACY_STORE.exists():
  return {}
 old=_read_security_profile(LEGACY_STORE)
 # Preserve recovery codes and existing email; never silently discard credentials.
 fields=('pin_hash','pin_salt','failures','locked_until',
         'recovery_salt','recovery_hash','email','email_verified')
 value={k:old[k] for k in fields if k in old}
 value['email_verified']=bool(old.get('email_verified',False))
 _save(value)
 return value

def _save(data):
 STORE.parent.mkdir(parents=True,exist_ok=True)
 temp=STORE.with_name(STORE.name+'.tmp')
 with open(temp,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
 os.replace(temp,STORE)
 try:os.chmod(STORE,0o600)
 except OSError:pass

def _valid(pin):
 return isinstance(pin,str) and pin.isascii() and pin.isdecimal() and 6<=len(pin)<=20

def _gmail_address(username):
 """Only the local part is editable; Gmail suffix is fixed in the UI."""
 name=username.strip()
 if not re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9.+_-]{0,62}[A-Za-z0-9])?',name) or '..' in name:
  raise ValueError('Wpisz poprawną pierwszą część adresu Gmail (bez @gmail.com).')
 return name.lower()+'@gmail.com'

def _gmail_entry(w):
 """Empty editable Gmail local part with visually locked domain."""
 target=_target(w)
 outer=tk.Frame(target,bg='#0d2537',height=46,width=400)
 outer.pack(padx=12,pady=(2,5));outer.pack_propagate(False)
 bg=tk.Canvas(outer,width=400,height=44,highlightthickness=0,bg='#0d2537')
 bg.place(x=0,y=0)
 _rounded(bg,1,1,398,42,10,'#1b4159','#7794a9',2)
 bg.create_rectangle(244,3,396,40,fill='#536d83',outline='')
 bg.create_line(244,2,244,42,fill='#93abbc',width=2)
 bg.create_text(320,21,text='@gmail.com',fill='#071b2c',font=('Segoe UI',12,'bold'))
 entry=tk.Entry(outer,font=('Segoe UI',12),bg='#1b4159',fg='#f3f5f8',insertbackground='white',relief='flat',bd=0,highlightthickness=0)
 entry.place(x=13,y=9,width=220,height=26)
 return entry


def _rounded(canvas,x1,y1,x2,y2,r,fill,outline,width=1):
 points=[x1+r,y1,x2-r,y1,x2,y1,x2,y1+r,x2,y2-r,x2,y2,x2-r,y2,x1+r,y2,x1,y2,x1,y2-r,x1,y1+r,x1,y1]
 return canvas.create_polygon(points,smooth=True,splinesteps=18,fill=fill,outline=outline,width=width)

def _navy_caption(window):
 """Use the native Windows caption, recolored to match the maritime UI.

 Keeps Windows drag, close, minimize and system accessibility behavior.
 DWM caption colors require supported Windows 10/11 builds; older builds
 fall back to immersive dark mode without replacing native controls.
 """
 import sys
 if sys.platform != 'win32':return
 try:
  import ctypes
  from ctypes import byref,c_int,c_uint32,sizeof
  window.update_idletasks()
  user32=ctypes.windll.user32
  hwnd=user32.GetParent(window.winfo_id()) or window.winfo_id()
  dwm=ctypes.windll.dwmapi.DwmSetWindowAttribute
  dark=c_int(1)
  for attribute in (20,19):
   if dwm(hwnd,attribute,byref(dark),sizeof(dark)) == 0:break
  caption=c_uint32(0x003C2B10) # #102b3c, Windows COLORREF BGR
  dwm(hwnd,35,byref(caption),sizeof(caption))
  white=c_uint32(0x00FFFFFF)
  dwm(hwnd,36,byref(white),sizeof(white))
 except (OSError,AttributeError,ValueError):pass

def _window(parent,title):
 """Maritime security dialog: compact layout on approved theme."""
 from PIL import Image,ImageTk
 w=tk.Toplevel(parent);w.title(title);w.configure(bg='#0d2537');w.resizable(False,False)
 width,height=540,550
 w.geometry(f'{width}x{height}+{max(0,(w.winfo_screenwidth()-width)//2)}+{max(0,(w.winfo_screenheight()-height)//2)}')
 canvas=tk.Canvas(w,width=width,height=height,bg='#0d2537',highlightthickness=0);canvas.pack()
 base=Path(getattr(__import__('sys'),'_MEIPASS',Path(__file__).resolve().parent))
 photo=ImageTk.PhotoImage(Image.open(base/'kw_approved_dialog.jpg'),master=w)
 canvas.create_image(0,0,anchor='nw',image=photo);w.ach_photo=photo
 content=tk.Frame(canvas,bg='#0d2537');canvas.create_window(width//2,55,window=content,anchor='n',width=width-110)
 w.ach_content=content
 if parent.winfo_viewable():w.transient(parent)
 from ui_assets import set_window_icon
 set_window_icon(w)
 _navy_caption(w)
 w.lift();w.grab_set();w.protocol('WM_DELETE_WINDOW',w.destroy)
 return w

def _gate_window(parent):
 """Uses the user's exact approved reference as the visual surface."""
 from PIL import Image,ImageTk
 w=tk.Toplevel(parent);w.title('KW — logowanie');w.configure(bg='#071b2c');w.resizable(False,False)
 width,height=618,632
 w.geometry(f'{width}x{height}+{max(0,(w.winfo_screenwidth()-width)//2)}+{max(0,(w.winfo_screenheight()-height)//2)}')
 canvas=tk.Canvas(w,width=width,height=height,highlightthickness=0,bg='#071b2c');canvas.pack()
 base=Path(getattr(__import__('sys'),'_MEIPASS',Path(__file__).resolve().parent))
 photo=ImageTk.PhotoImage(Image.open(base/'kw_approved_login.png'),master=w)
 canvas.create_image(0,0,image=photo,anchor='nw');w.ach_photo=photo
 w.ach_canvas=canvas;w.ach_login=True
 from ui_assets import set_window_icon
 set_window_icon(w)
 _navy_caption(w)
 w.protocol('WM_DELETE_WINDOW',w.destroy);w.lift();w.grab_set()
 return w

def _target(w):return getattr(w,'ach_content',w)

def _label(w,text):
 heading=text.isupper() and len(text)<55
 tk.Label(_target(w),text=text,bg='#0d2537',fg='#e4b867' if heading else '#e5edf4',font=('Segoe UI',15,'bold') if heading else ('Segoe UI',10),wraplength=395,justify='left').pack(anchor='center' if heading else 'w',padx=12,pady=(6,17) if heading else (7,3))

def _entry(w,secret=False):
 holder=tk.Frame(_target(w),bg='#0d2537',height=43,width=400)
 holder.pack(padx=12,pady=(2,7));holder.pack_propagate(False)
 bg=tk.Canvas(holder,width=400,height=43,highlightthickness=0,bg='#0d2537')
 bg.place(x=0,y=0)
 _rounded(bg,1,1,398,41,11,'#1b4159','#7794a9',2)
 e=tk.Entry(holder,show='•' if secret else '',font=('Segoe UI',12),bg='#1b4159',fg='#f3f5f8',insertbackground='#ffffff',relief='flat',bd=0,highlightthickness=0)
 e.place(x=15,y=9,width=370,height=25)
 return e

def _btn(w,text,action):
 from PIL import Image,ImageTk
 base=Path(getattr(__import__('sys'),'_MEIPASS',Path(__file__).resolve().parent))
 holder=tk.Frame(_target(w),bg='#0d2537',width=400,height=52)
 holder.pack(padx=12,pady=(14,10));holder.pack_propagate(False)
 photo=ImageTk.PhotoImage(Image.open(base/'kw_gold_button.png').resize((400,52),Image.Resampling.LANCZOS),master=holder)
 btn=tk.Button(holder,text=text,image=photo,compound='center',command=action,font=('Segoe UI',11,'bold'),fg='#102b3c',activeforeground='#102b3c',bg='#0d2537',activebackground='#0d2537',relief='flat',bd=0,highlightthickness=0,cursor='hand2')
 btn.image=photo;btn.pack(fill='both',expand=True)

def _wait(w):w.wait_window()

def _register_screen(root,allowed):
 """First registration follows the approved nautical/gold composition.

 The Gmail local-part field starts truly empty for every new installation.
 """
 from PIL import Image,ImageTk
 import sys
 base=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
 w=tk.Toplevel(root);w.title('KW — pierwsza rejestracja');w.configure(bg='#061827');w.resizable(False,False)
 src=Image.open(base/'kw_registration_background.png').convert('RGB')
 sw=w.winfo_screenwidth();sh=w.winfo_screenheight()
 scale=min(1.0,(sw-35)/740,(sh-90)/760)
 scale=max(.60,scale)
 width,height=round(740*scale),round(760*scale)
 w.geometry(f'{width}x{height}+{max(0,(sw-width)//2)}+{max(0,(sh-height)//2)}')
 canv=tk.Canvas(w,width=width,height=height,bg='#061827',highlightthickness=0)
 canv.pack()
 photo=ImageTk.PhotoImage(src.resize((width,height),Image.Resampling.LANCZOS),master=w)
 canv.create_image(0,0,anchor='nw',image=photo);w.registration_bg=photo
 fg='#f3f5f8';gold='#f6bc4c';navy='#082038';blue='#193f58'
 def xy(v):return round(v*scale)
 def font(size,bold=False):return ('Segoe UI',max(9,round(size*scale)),'bold' if bold else 'normal')
 def text(x,y,value,size=13,colour=fg,bold=False,anchor='center'):
  canv.create_text(xy(x),xy(y),text=value,fill=colour,font=font(size,bold),anchor=anchor)
 def entry(y,show=None):
  canv.create_rectangle(xy(125),xy(y),xy(615),xy(y+47),fill=blue,outline='#86abc4',width=max(1,xy(2)))
  e=tk.Entry(w,font=font(17),bg=blue,fg=fg,insertbackground='white',relief='flat',bd=0,highlightthickness=0,show=show or '')
  canv.create_window(xy(145),xy(y+24),window=e,anchor='w',width=xy(450),height=xy(34))
  return e
 text(370,284,'PIERWSZA REJESTRACJA',26,gold,True)
 canv.create_line(xy(142),xy(318),xy(598),xy(318),fill='#7b93a5',width=1)
 text(370,338,'UTWÓRZ PIN I PODAJ ADRES E-MAIL',12,'#dce8f0')
 text(125,365,'Utwórz PIN (6–20 cyfr)',13,gold,True,'w')
 p1=entry(379,'•')
 text(125,445,'Powtórz PIN',13,gold,True,'w')
 p2=entry(460,'•')
 text(125,527,'Adres e-mail',13,gold,True,'w')
 # E-mail control consists of an entirely empty editable local part and a fixed suffix.
 canv.create_rectangle(xy(125),xy(542),xy(615),xy(589),fill=blue,outline='#86abc4',width=max(1,xy(2)))
 canv.create_rectangle(xy(440),xy(545),xy(612),xy(586),fill='#9eabb6',outline='')
 text(526,566,'@gmail.com',13,navy,True)
 username=tk.Entry(w,font=font(17),bg=blue,fg=fg,insertbackground='white',relief='flat',bd=0,highlightthickness=0)
 canv.create_window(xy(145),xy(565),window=username,anchor='w',width=xy(282),height=xy(35))
 text(370,605,'Wpisz tylko pierwszą część adresu. @gmail.com jest stałe.',10,'#dde7f0')
 # Native widgets keep keyboard/tab interaction and focus accessibility.
 b=tk.Button(w,text='Zarejestruj',command=lambda:create(),font=font(16,True),fg=navy,bg='#f6bd4c',activebackground='#ffe19b',activeforeground=navy,bd=1,relief='raised',cursor='hand2')
 canv.create_window(xy(125),xy(625),window=b,anchor='nw',width=xy(328),height=xy(47))
 cancel=tk.Button(w,text='Anuluj',command=w.destroy,font=font(14,True),fg=fg,bg='#14364f',activebackground='#24536b',activeforeground=fg,bd=1,relief='raised',cursor='hand2')
 canv.create_window(xy(466),xy(625),window=cancel,anchor='nw',width=xy(149),height=xy(47))
 text(370,693,'Kod e-mail potwierdzi adres; otrzymasz też kod awaryjny.',11,'#dde7f0')
 def create():
  try:address=_gmail_address(username.get())
  except ValueError as exc:messagebox.showerror('Adres e-mail',str(exc),parent=w);username.focus_set();return
  if not _valid(p1.get()):messagebox.showerror('PIN','PIN musi mieć od 6 do 20 cyfr.',parent=w);p1.focus_set();return
  if p1.get()!=p2.get():messagebox.showerror('PIN','PIN-y nie są identyczne.',parent=w);p2.focus_set();return
  if not _email_verify(w,address,'register'):return
  recovery='-'.join(secrets.token_hex(4).upper() for _ in range(4))
  salt=secrets.token_hex(16);rsalt=secrets.token_hex(16)
  _save({'email':address,'email_verified':True,'pin_salt':salt,'pin_hash':_hash(p1.get(),salt),'recovery_salt':rsalt,'recovery_hash':_hash(recovery,rsalt),'failures':0,'locked_until':0})
  messagebox.showinfo('Kod awaryjny — zapisz go','Zapisz ten kod w bezpiecznym miejscu. Będzie potrzebny do odzyskania PIN-u bez internetu:\n\n'+recovery+'\n\nAdres e-mail został zweryfikowany.',parent=w)
  allowed[0]=True;w.destroy()
 for e in (p1,p2,username):e.bind('<Return>',lambda _evt:create())
 p1.focus_set()
 from ui_assets import set_window_icon
 set_window_icon(w)
 _navy_caption(w)
 w.lift();w.grab_set();w.wait_window()

def gate(root):
 """Return True if unlocked; never show payroll window before successful verification."""
 root.withdraw()
 try:
  data=_load()
 except SecurityStoreError as exc:
  root.deiconify()
  messagebox.showerror('Błąd danych logowania / Login data error',
                       str(exc)+'\n\nNie rozpoczynaj nowej rejestracji. Przywróć kopię pliku zabezpieczeń.',parent=root)
  return False
 allowed=[False]
 if not data.get('pin_hash'):
  _register_screen(root,allowed)
 else:
  w=_gate_window(root)
  # The title, instructions, button and recovery links are already painted
  # in the approved reference. Only the PIN field is an overlaid native control.
  pin=tk.Entry(w,show='•',font=('Segoe UI',13),bg='#183e59',fg='#ffffff',insertbackground='white',relief='flat',bd=0,highlightthickness=0)
  pin.place(x=155,y=335,width=348,height=28)
  def focus_pin():
   if not w.winfo_exists() or not pin.winfo_exists():return
   try:
    w.lift();w.focus_force();pin.focus_set()
   except tk.TclError:pass
  w.after_idle(lambda:w.after(90,focus_pin))
  def unlock(event=None):
   d=_load();remaining=int(d.get('locked_until',0)-time.time())
   if remaining>0:messagebox.showwarning('Blokada',f'Spróbuj ponownie za {remaining} s.',parent=w);return
   if hmac.compare_digest(_hash(pin.get(),d['pin_salt']),d['pin_hash']):
    d['failures']=0;d['locked_until']=0;_save(d);allowed[0]=True;w.destroy();return
   d['failures']=int(d.get('failures',0))+1
   if d['failures']>=5:d['failures']=0;d['locked_until']=time.time()+300
   _save(d);pin.delete(0,'end');messagebox.showerror('Błędny PIN','Nieprawidłowy kod PIN. Po 5 próbach następuje blokada na 5 minut.',parent=w)
   w.after_idle(focus_pin)
  def reset():
   d=_load();dialog=_window(w,'KW — reset PIN-u');dialog.protocol('WM_DELETE_WINDOW',dialog.destroy)
   _label(dialog,'Odzyskiwanie za pomocą kodu awaryjnego (bez internetu). Wpisz kod otrzymany podczas rejestracji.')
   code=_entry(dialog)
   _label(dialog,'Nowy PIN (6–20 cyfr)');np=_entry(dialog,True)
   _label(dialog,'Powtórz nowy PIN');cp=_entry(dialog,True)
   def perform():
    current=_load()
    if not current.get('recovery_salt') or not current.get('recovery_hash'):
     messagebox.showwarning('Brak kodu awaryjnego','To starszy profil bez kodu awaryjnego. Zaloguj się dotychczasowym PIN-em i skonfiguruj Gmail w Ustawieniach.',parent=dialog);return
    if not hmac.compare_digest(_hash(code.get().strip().upper(),current['recovery_salt']),current['recovery_hash']):messagebox.showerror('Błąd','Niepoprawny kod awaryjny.',parent=dialog);return
    if not _valid(np.get()) or np.get()!=cp.get():messagebox.showerror('Błąd','PIN musi mieć 6–20 cyfr i być identyczny w obu polach.',parent=dialog);return
    salt=secrets.token_hex(16);current.update(pin_salt=salt,pin_hash=_hash(np.get(),salt),failures=0,locked_until=0)
    recovery='-'.join(secrets.token_hex(4).upper() for _ in range(4));rs=secrets.token_hex(16)
    current.update(recovery_salt=rs,recovery_hash=_hash(recovery,rs));_save(current)
    messagebox.showinfo('Nowy kod awaryjny','Zapisz nowy kod awaryjny (poprzedni już nie działa):\n\n'+recovery,parent=dialog)
    dialog.destroy();messagebox.showinfo('PIN zmieniony','Zaloguj się nowym PIN-em.',parent=w)
   _btn(dialog,'Zresetuj PIN',perform)
  def reset_email():
   current=_load()
   if not current.get('email_verified') or not current.get('email'):
    messagebox.showwarning('Brak weryfikacji','Adres e-mail nie został zweryfikowany. Użyj kodu awaryjnego.',parent=w);return
   if not current['email'].lower().endswith('@gmail.com'):
    # Pre-Gmail legacy profile: retain recovery until address is changed in Settings.
    if not _email_verify(w,current['email'],'reset_pin'):return
   else:
    confirm=_window(w,'KW — wyślij kod e-mail')
    _label(confirm,'PODAJ ADRES E-MAIL')
    _label(confirm,'Wpisz wyłącznie pierwszą część adresu Gmail, użytego podczas rejestracji.')
    name=_gmail_entry(confirm)
    approved=[False]
    def submit():
     try:address=_gmail_address(name.get())
     except ValueError as exc:messagebox.showerror('Błąd',str(exc),parent=confirm);return
     if address.casefold()!=current['email'].casefold():
      messagebox.showerror('Niepoprawny adres','Podany adres nie zgadza się z zapisanym adresem odzyskiwania.',parent=confirm);return
     approved[0]=True;confirm.destroy()
    _btn(confirm,'Wyślij kod e-mail',submit)
    _wait(confirm)
    if not approved[0] or not _email_verify(w,current['email'],'reset_pin'):return
   dialog=_window(w,'KW — nowy PIN')
   _label(dialog,'Nowy PIN (6–20 cyfr)');np=_entry(dialog,True)
   _label(dialog,'Powtórz PIN');cp=_entry(dialog,True)
   def perform():
    if not _valid(np.get()) or np.get()!=cp.get():
     messagebox.showerror('Błąd','PIN musi mieć 6–20 cyfr i być identyczny w obu polach.',parent=dialog);return
    d=_load();salt=secrets.token_hex(16)
    d.update(pin_salt=salt,pin_hash=_hash(np.get(),salt),failures=0,locked_until=0)
    _save(d);dialog.destroy();messagebox.showinfo('PIN zmieniony','Zaloguj się nowym PIN-em.',parent=w)
   _btn(dialog,'Zapisz nowy PIN',perform)
  pin.bind('<Return>',unlock)
  c=w.ach_canvas
  def canvas_click(event):
   x,y=event.x,event.y
   if 95<=x<=523 and 389<=y<=438:unlock()
   elif 113<=x<=306 and 466<=y<=525:reset_email()
   elif 318<=x<=515 and 466<=y<=525:reset()
  c.bind('<Button-1>',canvas_click)
  c.bind('<Motion>',lambda event:c.configure(cursor='hand2' if (95<=event.x<=523 and 389<=event.y<=438) or (113<=event.x<=306 and 466<=event.y<=525) or (318<=event.x<=515 and 466<=event.y<=525) else ''))
  w.after(220,focus_pin)
  _wait(w)
 if allowed[0]:
  root.deiconify()
  # Migrated users keep the old PIN. Offer Gmail verification and emergency code.
  current=_load()
  if not current.get('email_verified'):
   verify_existing_email_dialog(root)
 return allowed[0]

def _verify_current_pin(dialog, pin):
 current=_load()
 if not current.get('pin_hash') or not current.get('pin_salt'):
  messagebox.showerror('Błąd','Nie znaleziono konfiguracji PIN.',parent=dialog)
  return None
 if not hmac.compare_digest(_hash(pin,current['pin_salt']),current['pin_hash']):
  messagebox.showerror('Błąd','Aktualny PIN jest nieprawidłowy.',parent=dialog)
  return None
 return current

def change_pin_dialog(root):
 w=_window(root,'KW — zmiana kodu PIN')
 _label(w,'ZMIANA KODU PIN')
 _label(w,'Aktualny PIN');old=_entry(w,True)
 _label(w,'Nowy PIN (6–20 cyfr)');new=_entry(w,True)
 _label(w,'Potwierdź nowy PIN');repeat=_entry(w,True)
 def change():
  if not _valid(new.get()) or new.get()!=repeat.get():
   messagebox.showerror('Błąd','Nowy PIN musi mieć 6–20 cyfr i być identyczny w obu polach.',parent=w);return
  current=_verify_current_pin(w,old.get())
  if current is None:return
  salt=secrets.token_hex(16)
  current.update(pin_salt=salt,pin_hash=_hash(new.get(),salt),failures=0,locked_until=0)
  _save(current)
  messagebox.showinfo('PIN zmieniony','Nowy PIN został zapisany. Przy następnym uruchomieniu użyj nowego kodu.',parent=w)
  w.destroy()
 _btn(w,'Zmień PIN',change)
 _label(w,'Wymagany jest aktualny PIN.')

def verify_existing_email_dialog(root):
 """Migrate an existing PIN installation without replacing its credentials."""
 current=_load()
 if not current.get('pin_hash'):
  messagebox.showerror('Błąd','Brak skonfigurowanego PIN-u.',parent=root);return
 if current.get('email_verified'):
  messagebox.showinfo('Weryfikacja','Adres e-mail jest już zweryfikowany.',parent=root);return
 w=_window(root,'KW — potwierdzenie istniejącego e-maila')
 _label(w,'WERYFIKACJA ADRESU E-MAIL')
 _label(w,'Zapisany adres: '+(current.get('email') or '(brak)'))
 _label(w,'Adres Gmail do potwierdzenia (bez @gmail.com)');email=_gmail_entry(w)
 _label(w,'Aktualny PIN (potwierdzenie właściciela)');pin=_entry(w,True)
 def verify():
  try:address=_gmail_address(email.get())
  except ValueError as exc:
   messagebox.showerror('Błąd',str(exc),parent=w);return
  verified=_verify_current_pin(w,pin.get())
  if verified is None:return
  purpose='register' if address.lower()==(verified.get('email') or '').lower() else 'change_email'
  if not _email_verify(w,address,purpose):return
  latest=_load()
  if latest.get('pin_hash')!=verified.get('pin_hash') or latest.get('email')!=verified.get('email'):
   messagebox.showerror('Błąd','Konfiguracja zmieniła się podczas weryfikacji. Spróbuj ponownie.',parent=w);return
  latest['email']=address
  latest['email_verified']=True
  recovery=None
  if not latest.get('recovery_hash') or not latest.get('recovery_salt'):
   recovery='-'.join(secrets.token_hex(4).upper() for _ in range(4))
   salt=secrets.token_hex(16)
   latest.update(recovery_salt=salt,recovery_hash=_hash(recovery,salt))
  _save(latest)
  if recovery:
   messagebox.showinfo('Kod awaryjny — zapisz go','Gmail zweryfikowany. Zapisz ten jednorazowo wyświetlany kod awaryjny:\n\n'+recovery,parent=w)
  else:
   messagebox.showinfo('Sukces','Adres e-mail został zweryfikowany. Odzyskiwanie PIN-u przez e-mail jest dostępne.',parent=w)
  w.destroy()
 _btn(w,'Wyślij kod i zweryfikuj e-mail',verify)
 _label(w,'Dotychczasowy PIN, kod awaryjny i ustawienia pozostaną bez zmian.')

def change_email_dialog(root):
 d=_load();w=_window(root,'KW — zmiana adresu e-mail')
 _label(w,'ZMIANA ADRESU E-MAIL')
 _label(w,'Obecny adres: '+d.get('email','brak'))
 _label(w,'Nowy adres Gmail (bez @gmail.com)');email=_gmail_entry(w)
 _label(w,'Aktualny PIN do autoryzacji zmiany');old=_entry(w,True)
 def change():
  try:address=_gmail_address(email.get())
  except ValueError as exc:
   messagebox.showerror('Błąd',str(exc),parent=w);return
  current=_verify_current_pin(w,old.get())
  if current is None:return
  if address.lower()==current.get('email','').lower():
   messagebox.showinfo('Bez zmian','To jest już zapisany adres e-mail.',parent=w);return
  if not _email_verify(w,address,'change_email'):return
  current['email']=address
  current['email_verified']=True
  _save(current)
  messagebox.showinfo('Adres zapisany','Nowy adres e-mail został zweryfikowany i zapisany.',parent=w)
  w.destroy()
 _btn(w,'Zmień adres e-mail',change)
 _label(w,'Nowy adres musi zostać potwierdzony kodem e-mail.')

def settings_dialog(root):
 """Backward-compatible entry point for older navigation code."""
 w=_window(root,'KW — bezpieczeństwo konta')
 _label(w,'BEZPIECZEŃSTWO KONTA')
 _label(w,'Wybierz operację:')
 _btn(w,'Zmień PIN',lambda:(w.destroy(),change_pin_dialog(root)))
 _btn(w,'Zmień adres e-mail',lambda:(w.destroy(),change_email_dialog(root)))
 _label(w,'Do weryfikacji i odzyskiwania PIN-u używamy adresu Gmail.')
