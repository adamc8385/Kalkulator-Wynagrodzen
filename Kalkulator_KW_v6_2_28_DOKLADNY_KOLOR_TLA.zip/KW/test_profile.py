"""v6.2 preview: isolate ALL writes from the stable ACH/KW installation.

On first launch only, copy local data + PIN hash to a separate private
preview folder. Future launches continue in that folder. Existing 6.1
files are never edited, renamed or deleted by this preview build.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path


def prepare_isolated_profile(variant):
    """Set KW_DATA_DIR before either payroll or security modules are imported.

    An explicit KW_DATA_DIR override from the caller is respected, so tests
    may direct the application to a disposable directory.
    """
    already = os.environ.get('KW_DATA_DIR', '').strip()
    if already:
        return Path(already).expanduser()
    if variant not in ('ACH', 'KW'):
        raise ValueError('Unknown variant')
    source_name = '.kalkulator_wynagrodzenia' if variant == 'ACH' else '.kalkulator_wynagrodzenia_kw'
    source = Path.home() / source_name
    target = (Path(os.environ.get('LOCALAPPDATA') or Path.home()) /
              'KalkulatorWynagrodzen' / (variant + '_v6_2_TEST_DANE'))
    target.mkdir(parents=True, exist_ok=True)
    try:
        if os.name != 'nt':
            os.chmod(target, 0o700)
    except OSError:
        pass
    marker = target / '.initialized_v6_2'
    if not marker.exists():
        names = ('dane.json','dane.json.bak','ach_security.json','kw_security.json')
        if source.is_dir():
            for name in names:
                old = source / name
                new = target / name
                if old.is_file() and not new.exists():
                    shutil.copy2(old, new)
        marker.write_text('v6.2 isolated preview; source: '+str(source)+'\n',encoding='utf-8')
    os.environ['KW_DATA_DIR'] = str(target)
    return target
