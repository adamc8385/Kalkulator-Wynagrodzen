"""Brief, practical help for every payroll setting (Polish/English).

Only confirmed statutory references are included. Employer-dependent allowances
are clearly labelled as assumptions; opening help never changes payroll data.
"""
import math
import tkinter as tk
import webbrowser

TAX_SOURCE = 'https://podatki.gov.pl/podatki-osobiste/pit/informacje-podstawowe/co-jest-opodatkowane/dochody-z-pracy'
PIT_SOURCE = 'https://podatki.gov.pl/poradniki-i-informatory/pit-2-pit-2a-pit-3-zasady-skladania-oswiadczen-o-stosowaniu-pomniejszenia-zaliczki-o-kwote-zmniejszajaca-podatek-112-124-lub-136'
ZUS_SOURCE = 'https://bip.zus.pl/pl/web/guest/baza-wiedzy/skladki-wskazniki-odsetki/wskazniki/roczna-podstawa-wymiaru-skladek-na-ubezpieczenia-emerytalne-i-rentowe-od-1999-r'

# Format: (what it is, what to enter, calculation effect, legal note [optional], official URL [optional]).
# Technical folder entries deliberately use one short paragraph, not payroll/legal headings.
HELP_PL = {
    'eu_c_allowance': ('Ręczny dodatek C: wyrównanie wynagrodzenia UE w miesiącu faktycznej wypłaty.', 'Wpisz kwotę BRUTTO z paska płacowego w miesiącu, w którym została wypłacona. 0 = brak.', 'Kwota zwiększa gotówkowe brutto, podstawy PIT, ZUS i zdrowotnej; nie przenosi się automatycznie na inne miesiące.', 'Regulamin Wynagradzania Wärtsilä 2026 §7; Regulamin Pracy §7.', None),
    'zfss_cash': ('Pieniężne świadczenie ZFŚS w miesiącu faktycznej wypłaty.', 'Wpisz kwotę otrzymaną przelewem: wyłącznie świadczenie w całości z ZFŚS, przyznane zgodnie z kryteriami socjalnymi. Nie wpisuj bonów ani wypłat spoza funduszu.', 'Dolicza gotówkę do przelewu. Roczne zwolnienie PIT wynosi 1 000 zł (łącznie ze wszystkimi kwalifikowanymi świadczeniami); nadwyżka podlega PIT i progowi podatkowemu, lecz nadal bez ZUS i zdrowotnej. Uwzględnia tylko kwoty wpisane w kalkulatorze.', 'Ustawa o PIT art. 21 ust. 1 pkt 67; rozporządzenie składkowe §2 ust. 1 pkt 19.', None),
    'ppe_auto_enabled': ('Automatyczne naliczanie składki PPE finansowanej przez pracodawcę.', 'Wpisz 1, jeśli uczestniczysz w firmowym PPE, lub 0, jeśli nie.', 'Program szacuje 3,5% od znanych kwalifikowanych składników brutto; świadczenie nie trafia na przelew. Kwotę potwierdź na pasku.', 'Regulamin Wynagradzania Wärtsilä 2026, § 19.', None),
    'ppo_auto_enabled': ('Automatyczne naliczanie składki PPO finansowanej przez pracodawcę.', 'Wpisz 1 tylko po potwierdzeniu prawa do PPO, w przeciwnym razie 0.', 'Program szacuje 0,5% od znanych kwalifikowanych składników brutto. W firmie wymagana jest odpowiednia dodatkowa składka PPE.', 'Regulamin Wynagradzania Wärtsilä 2026, § 20.', None),
    'ppe_employer_override': ('Kwota PPE faktycznie naliczona przez pracodawcę na pasku płacowym.', 'Pozostaw 0 dla automatycznego szacunku. Wpisz dodatnią kwotę z paska, aby zastąpić szacunek w wybranym miesiącu.', 'Wpływa na część przychodu podatkowego, ale nie na przelew.', '', None),
    'ppo_employer_override': ('Kwota PPO faktycznie naliczona przez pracodawcę na pasku płacowym.', 'Pozostaw 0 dla automatu lub wpisz kwotę z paska, aby ją potwierdzić.', 'Nie jest dodatkiem pieniężnym na konto; może wpływać na PIT.', '', None),

    'nominal': (
        'Planowana liczba godzin pracy w miesiącu, z uwzględnieniem świąt i potwierdzonych dni wolnych firmy.',
        'Nic nie wpisujesz. Dla 2026 roku program uwzględnia kalendarz firmowy; inne lata wymagają sprawdzenia firmowych dni wolnych.',
        'Pensja zasadnicza brutto podzielona przez nominał daje stawkę godzinową używaną do obliczeń.',
        'Kodeks pracy, art. 130.', None),
    'auto_root': (
        'Wybierz folder, z którego program będzie automatycznie pobierał karty pracy. '
        'Zalecamy folder główny „Karty pracy” z osobnymi podfolderami dla każdego roku (np. 2024, 2025, 2026).',
        '', '', '', None),
    'auto_import': (
        'Po włączeniu tej opcji program sprawdza karty pracy przy każdym uruchomieniu. '
        'Dodaje nowe karty, aktualizuje zmienione oraz usuwa z rozliczeń karty, których nie ma już w wybranym folderze.',
        '', '', '', None),
    'salary': (
        'Stała pensja miesięczna brutto wynikająca z umowy o pracę.',
        'Wpisz kwotę brutto obowiązującą w wybranym miesiącu, np. 5 000,00 zł. Zapisana zmiana obowiązuje od tego miesiąca do kolejnej zmiany.',
        'Jest uwzględniana raz w miesięcznym wynagrodzeniu; po podzieleniu przez nominał wyznacza stawkę godzinową.',
        'Kodeks pracy, art. 78 i 80; wysokość stawki wynika z umowy.', None),
    'offshore': (
        'Dzienny dodatek za pracę OFF-SHORE oznaczoną w karcie pracy kodem 9.',
        'Wpisz uzgodnioną z pracodawcą kwotę brutto za dzień, np. 230 zł. Jeśli dodatek nie przysługuje, wpisz 0.',
        'Liczba dni z kodem 9 × podana stawka. Kod 10 (podróż) i samo oznaczenie „Praca w morzu” nie oznaczają tego dodatku.',
        '', None),
    'travel_rate': (
        'Współczynnik do wyliczenia dodatku za kwalifikowane godziny podróży.',
        'Wpisz np. 0,50, jeśli dodatek ma wynosić 50% stawki godzinowej. Wartość sprawdź w zasadach pracodawcy.',
        'Godziny podróży po odliczeniu × stawka godzinowa × współczynnik.',
        '', None),
    'costs': (
        'Koszty uzyskania przychodu pomniejszają dochód, od którego liczony jest PIT. To nie jest potrącenie z wypłaty.',
        'Zwykle 250 zł miesięcznie lub 300 zł, jeśli spełniasz warunki dla pracownika zamiejscowego. Sprawdź pasek płacowy.',
        'Mniejsze opodatkowanie może zwiększyć kwotę netto. Koszty nie obniżają pensji brutto.',
        'Ustawa o PIT, art. 22 ust. 2 (stawki na 2026 r.).', TAX_SOURCE),
    'pit_relief': (
        'Kwota, o którą pracodawca pomniejsza miesięczną zaliczkę podatku PIT.',
        'Wpisz kwotę stosowaną przez płatnika: 300, 150, 100 albo 0 zł, zgodnie z PIT-2 i paskiem płacowym.',
        'Pomniejsza zaliczkę PIT, a nie podstawę opodatkowania.',
        'Ustawa o PIT; zasady oświadczenia PIT-2.', PIT_SOURCE),
    'ytd_tax_base': (
        'Podstawa opodatkowania PIT narastająco od stycznia do końca poprzedniego miesiąca.',
        'Nie wpisujesz jej co miesiąc. Program oblicza ją automatycznie; korektę narastającą możesz wprowadzić jednorazowo z paska płacowego.',
        'Pozwala ustalić, czy bieżący dochód mieści się jeszcze w progu 12%, czy przekracza próg 120 000 zł i podlega 32%.',
        'Ustawa o PIT, art. 27 (skala podatkowa).', TAX_SOURCE),
    'social_ytd': (
        'Łączna podstawa składek emerytalnych i rentowych od początku roku do poprzedniego miesiąca.',
        'Wpisz narastającą kwotę z paska płacowego. Na początku roku, przed pierwszą wypłatą, wpisz 0.',
        'Pokazuje, ile podstawy pozostało do rocznego limitu składek emerytalnych i rentowych.',
        'Ustawa o systemie ubezpieczeń społecznych, art. 19.', ZUS_SOURCE),
    'social_limit': (
        'Roczny limit podstawy naliczania składek emerytalnych i rentowych.',
        'Nic nie wpisuj. Program automatycznie ustala kwotę według wybranego roku, np. 282 600 zł dla 2026 i 300 990 zł dla 2027.',
        'Po osiągnięciu limitu nie nalicza się dalszych składek emerytalnych i rentowych; pozostałe składki mogą nadal obowiązywać.',
        'Ustawa o systemie ubezpieczeń społecznych, art. 19; limity na 2026 i 2027: M.P. 2025 poz. 1206 i M.P. 2026 poz. 1098.', ZUS_SOURCE),
    'ppk': (
        'Procent wpłaty pracownika do Pracowniczych Planów Kapitałowych (PPK).',
        'Wpisz np. 2,00%, jeśli jesteś uczestnikiem PPK ze standardową składką. Gdy nie uczestniczysz, wpisz 0.',
        'Wpłata jest obliczana od właściwej podstawy i pomniejsza prognozowany przelew.',
        'Ustawa o pracowniczych planach kapitałowych — wpłata podstawowa pracownika wynosi co do zasady 2%.', None),
    'benefits_in_social': (
        'Określa, czy świadczenia Edenred i LuxMed mają w tym modelu wejść do podstawy składek i podatku.',
        'Wpisz 1 = tak albo 0 = nie, zgodnie z traktowaniem tych świadczeń na pasku płacowym.',
        'Może zmienić obliczone składki i PIT. Świadczenia te nie są doliczane jako gotówka do przelewu.',
        '', None),
    'employer_pension_taxable': (
        'Określa, czy wpłaty PPE/PPO finansowane przez pracodawcę są uwzględniane w podstawie PIT w symulacji.',
        'Wpisz 1 = tak albo 0 = nie po sprawdzeniu paska płacowego i zasad konkretnego programu.',
        'Wpływa na wyliczenie podatku, ale sama wpłata pracodawcy nie zwiększa gotówkowego przelewu.',
        '', None),
    'edenred_benefit': (
        'Wartość świadczenia Edenred wypłacanego poza standardowym przelewem bankowym.',
        'Wpisz kwotę z paska płacowego, np. 200 zł; jeśli nie występuje, wpisz 0.',
        'Pokazywana osobno od przelewu. Może wpływać na składki/PIT zależnie od ustawień i charakteru świadczenia.',
        '', None),
    'luxmed_benefit': (
        'Wartość pozapłacowego świadczenia medycznego LuxMed.',
        'Wpisz wartość wykazaną na pasku płacowym albo 0, jeśli świadczenia nie ma.',
        'Nie jest dodawana do przelewu; w określonych sytuacjach może wpływać na podatek i składki.',
        '', None),
    'ppe_employer_reference': (
        'Wartość składki PPE finansowanej przez pracodawcę, pokazana informacyjnie.',
        'Wpisz kwotę z odpowiedniego paska płacowego lub 0, jeśli taka składka nie występuje.',
        'Świadczenie jest pokazywane poza gotówkowym przelewem.',
        '', None),
    'ppo_employer_reference': (
        'Wartość składki programu PPO finansowanej przez pracodawcę, pokazana informacyjnie.',
        'Wpisz kwotę z paska płacowego lub 0, jeśli nie występuje.',
        'Świadczenie jest pokazywane poza przelewem; zasady podatkowe zależą od konkretnego programu.',
        '', None),
    'ppe_extra': (
        'Dobrowolna dodatkowa składka PPE potrącana z Twojej wypłaty.',
        'Wpisz kwotę potrącenia z paska płacowego; jeśli nie wpłacasz składki dodatkowej, wpisz 0.',
        'Zmniejsza prognozowany przelew, ale nie jest nowym dodatkiem brutto.',
        '', None),
    'car_bonus_count': (
        'Liczba zatwierdzonych dodatków za podróż służbową samochodem.',
        'Wpisz liczbę zatwierdzonych przypadków, np. 2, a nie kwotę w złotych.',
        'Program liczy 2 × 400 zł = 800 zł brutto. Stawka 400 zł jest ustawieniem firmowym, nie ustawową stawką.',
        '', None),
    'shared_room_nights': (
        'Liczba noclegów kwalifikujących się do dodatku za pokój lub kabinę dwuosobową.',
        'Wpisz liczbę zatwierdzonych nocy, np. 3, albo 0.',
        'Program liczy 3 × 100 zł = 300 zł brutto. Stawka 100 zł zależy od zasad firmowych.',
        '', None),
    'domestic_diet_extra_days': (
        'Liczba dni, za które firma zatwierdziła dodatek do diety (kod 1746).',
        'Wpisz liczbę zatwierdzonych dni. Nie wpisuj kwoty świadczenia.',
        'Zatwierdzone dni × 55 zł są doliczane do gotówkowego wynagrodzenia brutto; składnik uwzględnia się też w szacunku PIT/ZUS. Nie wylicza się dni automatycznie z podróży.',
        '', None),
    'risk_days': (
        'Liczba zatwierdzonych dni pracy w rejonie wysokiego ryzyka.',
        'Wpisz liczbę zatwierdzonych dni, np. 4. Jeśli nie przysługuje dodatek, wpisz 0.',
        'Dni × 230 zł × ustawiony współczynnik ryzyka. Kwota i uprawnienie wynikają z zasad firmy.',
        '', None),
    'risk_factor': (
        'Współczynnik określający, jaka część dodatku za wysokie ryzyko przysługuje.',
        'Wpisz uzgodnioną wartość: 1,00 = 100%, 0,75 = 75%, 0,50 = 50% lub 0,25 = 25%.',
        'Mnoży stawkę 230 zł za dzień i liczbę dni ryzyka; nie jest stawką ustawową.',
        '', None),
    'other_gross': (
        'Dodatkowa kwota brutto nieuwzględniona w innych polach kalkulatora.',
        'Wpisz potwierdzoną kwotę dodatku lub korekty, np. 250 zł; bez takiej kwoty pozostaw 0.',
        'Dodaje kwotę do wynagrodzenia brutto i wpływa na dalsze obliczenia PIT/ZUS.',
        '', None),
    'other_deductions': (
        'Inne potrącenia z kwoty do przelewu, których nie ma w pozostałych polach.',
        'Wpisz sumę potwierdzonych potrąceń z paska płacowego. Jeśli brak, wpisz 0.',
        'Pomniejsza prognozowany przelew, a nie pensję brutto.',
        'Zasady dopuszczalnych potrąceń z wynagrodzenia: Kodeks pracy, art. 87–91.', None),
}

HELP_EN = {
    'eu_c_allowance': ('Manual EU C wage top-up in the actual payment month.', 'Enter the payslip gross amount in the month you received it. Zero means no payment.', 'Included in gross wages and ordinary PIT/social/health bases; month-specific, never carried forward.', '', None),
    'zfss_cash': ('Cash benefit from the company social fund, paid in the selected month.', 'Enter only fully fund-financed cash benefit properly awarded on social criteria. Exclude vouchers and payments from other sources.', 'Added to net cash. Annual PLN 1,000 PIT exemption, excess is taxable but social/health contributions remain excluded. Only entered values are tracked.', '', None),
    'ppe_auto_enabled': ('Calculate the employer-funded PPE contribution automatically.', 'Enter 1 if you participate in the company PPE plan, otherwise 0.', 'Estimates 3.5% of known eligible gross pay. The contribution is not bank-transfer cash; verify with the payslip.', 'Wärtsilä Payroll Regulations 2026, §19.', None),
    'ppo_auto_enabled': ('Calculate employer-funded PPO contribution automatically.', 'Enter 1 only if the PPO entitlement has been confirmed, otherwise 0.', 'Estimates 0.5% of known eligible gross pay; the plan has a separate additional-PPE requirement.', 'Wärtsilä Payroll Regulations 2026, §20.', None),
    'ppe_employer_override': ('Confirmed employer PPE contribution from the payslip.', 'Enter 0 for an automatic estimate, or the actual amount as a month-specific override.', 'Affects taxable benefit, not bank-transfer cash.', '', None),
    'ppo_employer_override': ('Confirmed employer PPO contribution from the payslip.', 'Enter 0 for an automatic estimate, or the actual amount.', 'Non-cash benefit; may affect PIT.', '', None),

    'nominal': (
        'Scheduled working hours in the selected month, taking Polish public holidays into account.',
        'Nothing to enter. The program uses the 2026 company calendar when available; for other years, statutory hours are provisional until a company calendar is supplied.',
        'Gross monthly base salary divided by scheduled hours gives the hourly rate used for calculations.',
        'Polish Labour Code, Article 130.', None),
    'auto_root': (
        'Choose the folder from which the program will automatically load work cards. '
        'We recommend a main folder named “Work cards” with a separate subfolder for each year (e.g. 2024, 2025, 2026).',
        '', '', '', None),
    'auto_import': (
        'When enabled, the program checks the work cards at every startup. '
        'It adds new cards, updates changed cards and removes cards no longer present in the selected folder from payroll calculations.',
        '', '', '', None),
    'salary': (
        'Fixed monthly gross base salary stated in your employment contract.',
        'Enter the gross amount for the selected month, e.g. PLN 5,000. A saved change applies from that month until the next change.',
        'Included once in monthly gross pay; divided by scheduled hours to calculate the hourly rate.',
        'Polish Labour Code, Articles 78 and 80; the amount comes from your contract.', None),
    'offshore': (
        'Daily allowance for OFF-SHORE work marked with work type 9 on a work card.',
        'Enter the agreed gross amount per day, e.g. PLN 230. Enter 0 if not applicable.',
        'Number of type-9 days × daily rate. Type 10 (travel) and “At sea: YES” alone do not qualify.',
        '', None),
    'travel_rate': (
        'Multiplier used to calculate an allowance for eligible travel hours.',
        'Enter e.g. 0.50 for 50% of the hourly rate. Verify the applicable employer rules.',
        'Eligible travel hours after deduction × hourly rate × multiplier.',
        '', None),
    'costs': (
        'Employee tax-deductible costs reduce income subject to PIT; they are not a payroll deduction.',
        'Usually PLN 250 per month, or PLN 300 if you meet the statutory out-of-town employee conditions. Check your payslip.',
        'Lower taxable income may increase net pay; gross salary is unchanged.',
        'Polish PIT Act, Article 22(2) (2026 amounts).', TAX_SOURCE),
    'pit_relief': (
        'Amount by which your employer reduces monthly PIT withholding.',
        'Enter PLN 300, 150, 100 or 0 according to your PIT-2 declaration and payslip.',
        'Reduces the PIT advance, not taxable income.',
        'Polish PIT Act; PIT-2 declaration rules.', PIT_SOURCE),
    'ytd_tax_base': (
        'Cumulative PIT taxable income from January through the end of the previous month.',
        'Enter the year-to-date amount from payroll records. In January, enter 0 if no prior taxable base arose in that year.',
        'Helps determine whether income remains within the 12% band or crosses the PLN 120,000 threshold into 32%.',
        'Polish PIT Act, Article 27.', TAX_SOURCE),
    'social_ytd': (
        'Cumulative pension and disability insurance contribution base from January through the previous month.',
        'Enter the year-to-date figure from your payslip, or 0 before the first payroll of the year.',
        'Determines how much contribution base remains before the annual limit.',
        'Polish Social Insurance System Act, Article 19.', ZUS_SOURCE),
    'social_limit': (
        'Annual upper limit of the pension and disability contribution base.',
        'Nothing to enter. The program uses the official limit for the selected year: PLN 282,600 (2026), PLN 300,990 (2027).',
        'Pension and disability contributions cease above the limit; other contributions may still apply.',
        'Polish Social Insurance System Act, Article 19; Monitor Polski 2025 item 1206 and 2026 item 1098.', ZUS_SOURCE),
    'ppk': (
        'Employee contribution percentage for Employee Capital Plans (PPK).',
        'Enter e.g. 2.00% for the standard employee contribution. Enter 0 if not participating.',
        'Calculated from the applicable base and deducted from the estimated bank transfer.',
        'Polish PPK Act; the standard employee contribution is normally 2%.', None),
    'benefits_in_social': (
        'Whether Edenred and LuxMed benefits are included in the contribution and tax bases in this model.',
        'Enter 1 = yes or 0 = no, based on their treatment on your payslip.',
        'May affect calculated contributions and PIT; these benefits are not added to cash pay.',
        '', None),
    'employer_pension_taxable': (
        'Whether employer-funded PPE/PPO amounts enter the modeled PIT base.',
        'Enter 1 = yes or 0 = no after checking your payslip and the relevant plan rules.',
        'Changes the estimated tax, but the employer contribution itself does not increase cash pay.',
        '', None),
    'edenred_benefit': (
        'Value of an Edenred benefit provided outside the normal bank transfer.',
        'Enter the amount shown on your payslip, e.g. PLN 200, or 0 if not applicable.',
        'Shown separately from cash pay; tax and contribution effects depend on the benefit and settings.',
        '', None),
    'luxmed_benefit': (
        'Value of a LuxMed non-cash medical benefit.',
        'Enter the value shown on your payslip or 0 if there is no benefit.',
        'Not added to the bank transfer; may affect tax and contributions.',
        '', None),
    'ppe_employer_reference': (
        'Informational value of a PPE pension contribution funded by the employer.',
        'Enter the amount from the relevant payslip, or 0 when not applicable.',
        'Shown outside the cash bank transfer.',
        '', None),
    'ppo_employer_reference': (
        'Informational value of a PPO saving-plan contribution funded by the employer.',
        'Enter the amount from the relevant payslip or 0 if none.',
        'Shown outside cash pay; tax rules depend on the specific arrangement.',
        '', None),
    'ppe_extra': (
        'Additional voluntary employee PPE contribution deducted from take-home pay.',
        'Enter the deducted amount from your payslip, or 0 if you do not contribute extra.',
        'Reduces the estimated bank transfer; it is not additional gross earnings.',
        '', None),
    'car_bonus_count': (
        'Number of approved allowances for business travel by car.',
        'Enter the number of approved cases, e.g. 2, rather than a monetary amount.',
        '2 × PLN 400 = PLN 800 gross. This is an employer-specific, not statutory, rate.',
        '', None),
    'shared_room_nights': (
        'Number of qualifying nights in a shared room or cabin.',
        'Enter the number of approved nights, e.g. 3, or 0.',
        '3 × PLN 100 = PLN 300 gross. The rate depends on employer rules.',
        '', None),
    'domestic_diet_extra_days': (
        'Number of employer-approved days eligible for per-diem supplement (code 1746).',
        'Enter the number of approved days, not the total amount.',
        'Approved days × PLN 55 are added to cash gross pay and estimated contribution/tax bases. Days are never inferred from travel rows.',
        '', None),
    'risk_days': (
        'Number of approved workdays eligible for the high-risk allowance.',
        'Enter the approved number of days, e.g. 4, or 0 if not applicable.',
        'Days × PLN 230 × risk factor. The eligibility and amount depend on employer policy.',
        '', None),
    'risk_factor': (
        'Multiplier for the proportion of the high-risk allowance payable.',
        'Enter the approved factor: 1.00 = 100%, 0.75 = 75%, 0.50 = 50%, or 0.25 = 25%.',
        'Multiplies PLN 230 per day and the number of high-risk days; not a statutory rate.',
        '', None),
    'other_gross': (
        'Extra gross payment not covered by the other settings.',
        'Enter the approved gross payment or correction, e.g. PLN 250, or 0 if none.',
        'Adds to gross pay and can affect PIT/social contributions.',
        '', None),
    'other_deductions': (
        'Other amounts deducted from the bank transfer, not entered elsewhere.',
        'Enter documented deductions from the payslip or 0 if none.',
        'Reduces estimated take-home pay without lowering the gross base salary.',
        'Permitted payroll deductions are regulated by the Polish Labour Code, Articles 87–91.', None),
}

HEADINGS = {
    'pl': ('Co to oznacza?', 'Co należy wpisać?', 'Jak wpływa na wynagrodzenie?', 'Podstawa prawna'),
    'en': ('What does this mean?', 'What should I enter?', 'How does this affect my pay?', 'Legal basis'),
}


def help_sections(key, language='pl'):
    """Return compact heading/body pairs; isolated for deterministic tests."""
    lang = 'en' if language == 'en' else 'pl'
    meaning, entry, effect, legal, _url = (HELP_EN if lang == 'en' else HELP_PL)[key]
    if key in ('auto_root', 'auto_import'):
        return [('', meaning)]
    labels = HEADINGS[lang]
    return [(head, body) for head, body in zip(labels, (meaning, entry, effect, legal)) if body]


def _window_height(sections):
    # Approximate height of actual wrapped paragraphs, with a bounded scrollable panel.
    lines = sum(max(1, math.ceil(len(body) / 75)) + (1 if heading else 0) for heading, body in sections)
    return min(600, max(260, 190 + (lines * 28) + 16 * len(sections)))


def open_parameter_help(parent, key, title, language='pl'):
    language = 'en' if language == 'en' else 'pl'
    sections = help_sections(key, language)
    url = (HELP_EN if language == 'en' else HELP_PL)[key][-1]
    from ui_assets import schedule_navy_titlebar
    popup = tk.Toplevel(parent)
    schedule_navy_titlebar(popup,background='#0b2234',foreground="#ffffff")
    popup.title(('Information — ' if language == 'en' else 'Informacje — ') + title)
    popup.configure(bg='#0b2234')
    width = min(670, max(500, popup.winfo_screenwidth() - 40))
    height = min(_window_height(sections), max(260, popup.winfo_screenheight() - 90))
    try:
        x = parent.winfo_rootx() + (parent.winfo_width() - width) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - height) // 2
    except tk.TclError:
        x, y = 0, 0
    x = max(0, min(x, popup.winfo_screenwidth() - width))
    y = max(0, min(y, popup.winfo_screenheight() - height))
    popup.geometry(f'{width}x{height}+{x}+{y}')
    popup.minsize(min(500, width), 220)
    popup.transient(parent)
    try:
        from ui_assets import set_window_icon
        set_window_icon(popup)
    except Exception:
        pass

    tk.Label(popup, text=title, bg='#0b2234', fg='#efbd60',
             font=('Segoe UI', 14, 'bold'), wraplength=615, justify='left').pack(
                 anchor='w', padx=18, pady=(15, 10))
    frame = tk.Frame(popup, bg='#0b2234')
    frame.pack(fill='both', expand=True, padx=18)
    txt = tk.Text(frame, wrap='word', bd=0, bg='#143047', fg='#f0f6fa',
                  font=('Segoe UI', 11), padx=14, pady=10, spacing2=3,
                  highlightthickness=0, relief='flat')
    scroll = tk.Scrollbar(frame, command=txt.yview)
    txt.configure(yscrollcommand=scroll.set)
    txt.pack(side='left', fill='both', expand=True)
    txt.tag_configure('heading', foreground='#efbd60',
                      font=('Segoe UI', 11, 'bold'), spacing1=8, spacing3=3)
    txt.tag_configure('body', foreground='#f0f6fa', spacing3=12)
    for heading, body in sections:
        if heading:
            txt.insert('end', heading + '\n', 'heading')
        txt.insert('end', body + '\n\n', 'body')
    txt.configure(state='disabled')

    def update_scrollbar():
        # Short technical help should not show a useless scrollbar.
        try:
            _start, end = txt.yview()
            if end < 0.999 and not scroll.winfo_manager():
                scroll.pack(side='right', fill='y', before=txt)
            elif end >= 0.999 and scroll.winfo_manager():
                scroll.pack_forget()
        except tk.TclError:
            pass

    popup.after_idle(update_scrollbar)
    txt.bind('<Configure>', lambda _event: popup.after_idle(update_scrollbar))
    buttons = tk.Frame(popup, bg='#0b2234')
    buttons.pack(fill='x', padx=18, pady=12)
    if url:
        tk.Button(buttons, text=('Official source' if language == 'en' else 'Otwórz oficjalne źródło'),
                  command=lambda: webbrowser.open(url), bg='#193a51', fg='white',
                  bd=0, padx=13, pady=8, cursor='hand2').pack(side='left')
    tk.Button(buttons, text=('Close' if language == 'en' else 'Zamknij'),
              command=popup.destroy, bg='#138567', fg='white', bd=0,
              padx=16, pady=8, cursor='hand2').pack(side='right')
    popup.bind('<Escape>', lambda _event: popup.destroy())
    popup.grab_set()
    popup.focus_set()
    return popup
