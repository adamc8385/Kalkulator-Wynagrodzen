"""Spójne, modalne komunikaty ACH. Zachowuje interfejs tkinter.messagebox."""
import tkinter as tk
import sys
from pathlib import Path
from PIL import Image,ImageTk
from tkinter import messagebox

NAVY='#071b2c'; PANEL='#0a2439'; GOLD='#f3b94e'; WHITE='#f4f6fa'; LINE='#39708c'
_original={name:getattr(messagebox,name) for name in ('showinfo','showwarning','showerror','askyesno','askokcancel','askretrycancel','askyesnocancel','askquestion')}
_installed=False

def _dialog(kind,title,message,**options):
    parent=options.get('parent')
    if parent is None:
        parent=tk._default_root
    if parent is None or not parent.winfo_exists():
        return _original[kind](title,message,**options)
    good_titles=('sukces','zapisano','pin zmieniony','adres zapisany','konto utworzone','odświeżono','kod wysłany')
    status=('success' if kind=='showinfo' and any(word in (title or '').lower() for word in good_titles)
            else {'showinfo':'info','showwarning':'warning','showerror':'error'}.get(kind,'question'))
    choices={'askyesno':[('Tak',True),('Nie',False)],'askokcancel':[('OK',True),('Anuluj',False)],'askretrycancel':[('Ponów',True),('Anuluj',False)],'askyesnocancel':[('Tak',True),('Nie',False),('Anuluj',None)],'askquestion':[('Tak','yes'),('Nie','no')]}.get(kind,[('OK','ok')])
    fallback=None if kind=='askyesnocancel' else ('no' if kind=='askquestion' else False if kind.startswith('ask') else 'ok')
    win=tk.Toplevel(parent)
    win.title(title or 'KW')
    win.configure(bg=GOLD)
    win.resizable(False,False)
    try:
        from ach_security import _navy_caption
        win.after(20,lambda:_navy_caption(win) if win.winfo_exists() else None)
    except (ImportError,AttributeError):pass
    try:
        from ui_assets import set_window_icon
        set_window_icon(win)
    except (OSError, ImportError, tk.TclError):
        pass
    result=[fallback]
    def finish(value):
        result[0]=value
        win.destroy()
    win.protocol('WM_DELETE_WINDOW',lambda:finish(fallback))
    outer=tk.Frame(win,bg=GOLD,padx=2,pady=2);outer.pack(fill='both',expand=True)
    inner=tk.Frame(outer,bg=NAVY,padx=22,pady=17);inner.pack(fill='both',expand=True)
    text=str(message or '')
    lines=text.splitlines()
    longest=max([len(line) for line in lines] or [0])
    width=560 if longest>65 or len(text)>260 else 470
    titlebar=tk.Frame(inner,bg=NAVY);titlebar.pack(fill='x')
    tk.Label(titlebar,text=title or 'KW',font=('Segoe UI',13,'bold'),fg=GOLD,bg=NAVY,anchor='w').pack(side='left',fill='x',expand=True)
    tk.Button(titlebar,text='×',font=('Segoe UI',16),fg=WHITE,bg=NAVY,activebackground=PANEL,activeforeground=GOLD,bd=0,command=lambda:finish(fallback),cursor='hand2').pack(side='right')
    tk.Frame(inner,bg=LINE,height=1).pack(fill='x',pady=(9,16))
    body=tk.Frame(inner,bg=NAVY);body.pack(fill='both',expand=True)
    # Pre-rendered antialiased medallions (80 px source, downscaled with LANCZOS).
    base=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
    status_path=base/f'kw_status_{status}.png'
    try:
        medallion=ImageTk.PhotoImage(Image.open(status_path).resize((55,55),Image.Resampling.LANCZOS),master=win)
        icon=tk.Label(body,image=medallion,bg=NAVY,bd=0,highlightthickness=0)
        icon.image=medallion
    except (OSError, ValueError, tk.TclError):
        icon=tk.Label(body,text={'error':'!','warning':'!','success':'✓'}.get(status,'i'),
                      bg=NAVY,fg=GOLD,font=('Segoe UI',25,'bold'),width=2)
    icon.pack(side='left',anchor='n',padx=(0,15),pady=(0,5))
    # Native Tk labels preserve multiline messages; no white system dialog surfaces.
    tk.Label(body,text=text,justify='left',anchor='nw',wraplength=width-140,font=('Segoe UI',10),fg=WHITE,bg=NAVY).pack(side='left',fill='both',expand=True)
    tk.Frame(inner,bg=LINE,height=1).pack(fill='x',pady=(17,12))
    footer=tk.Frame(inner,bg=NAVY);footer.pack(fill='x')
    for caption,value in choices:
        tk.Button(footer,text=caption,command=lambda v=value:finish(v),font=('Segoe UI',10,'bold'),fg='#071b2c',bg=GOLD,activebackground='#ffd27a',activeforeground=NAVY,relief='flat',bd=0,padx=22,pady=7,cursor='hand2').pack(side='right',padx=(9,0))
    win.update_idletasks()
    w=max(width,win.winfo_reqwidth()+12)
    h=win.winfo_reqheight()+6
    sw=win.winfo_screenwidth();sh=win.winfo_screenheight()
    try:
        x=parent.winfo_rootx()+(parent.winfo_width()-w)//2
        y=parent.winfo_rooty()+(parent.winfo_height()-h)//2
    except tk.TclError:x=(sw-w)//2;y=(sh-h)//2
    win.geometry(f'{w}x{h}+{max(0,min(x,sw-w))}+{max(0,min(y,sh-h))}')
    win.transient(parent)
    win.grab_set()
    win.bind('<Escape>',lambda e:finish(fallback))
    win.bind('<Return>',lambda e:finish(choices[0][1]))
    win.focus_force()
    parent.wait_window(win)
    return result[0]

def install():
    global _installed
    if _installed:return
    for kind in _original:
        setattr(messagebox,kind,lambda title=None,message=None,_kind=kind,**kw:_dialog(_kind,title,message,**kw))
    _installed=True
