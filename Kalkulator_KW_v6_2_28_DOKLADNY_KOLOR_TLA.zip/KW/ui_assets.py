"""High-DPI window icons and SVG-derived UI images for ACH / KW.

Runtime uses Pillow and pre-rendered transparent assets; no external SVG renderer.
The original editable vector masters are shipped in wektory_svg/.
"""
from pathlib import Path
import sys


def asset_path(name):
    return Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent)) / name


def enable_windows_hidpi(app_id='PL.KW.KalkulatorWynagrodzen'):
    """Opt out of Windows bitmap upscaling before tkinter creates any window.

    Per-monitor v2 is preferred, with system-aware fallbacks for older Windows.
    Windows will still decide the effective Tk scaling based on system DPI.
    """
    if sys.platform != 'win32':
        return
    try:
        import ctypes
        user32 = ctypes.windll.user32
        try:
            user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except (OSError, AttributeError):
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
            except (OSError, AttributeError):
                try:
                    user32.SetProcessDPIAware()
                except (OSError, AttributeError):
                    pass
        # Distinct IDs prevent a Python/PyInstaller icon being grouped in taskbar.
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except (AttributeError, ImportError, OSError):
        pass


def dpi_scale(root):
    """Tk scaling = pixels/point (96 DPI -> approx 1.333)."""
    try:
        ratio = min(3.0, max(1.0, float(root.tk.call('tk', 'scaling')) * 72.0 / 96.0))
        return 1.0 if ratio < 1.1 else ratio
    except (ValueError, AttributeError, TypeError):
        return 1.0


def image_photo(root, asset, width, height=None):
    """Scale from a 256/360px antialiased source, never a 24px bitmap."""
    from PIL import Image, ImageTk
    if height is None:
        height = width
    factor = dpi_scale(root)
    target = (max(1, round(width * factor)), max(1, round(height * factor)))
    key = (asset, target)
    # Images are Tcl-interpreter specific. Cache on the actual Tk root, not
    # globally (a global PhotoImage may outlive its master or cross windows).
    cache = getattr(root, '_payroll_photo_cache', None)
    if cache is None:
        cache = {}
        root._payroll_photo_cache = cache
    if key not in cache:
        path = asset_path(asset if asset.lower().endswith('.png') else f'{asset}.png')
        with Image.open(path) as source:
            im = source.convert('RGBA')
        cache[key] = ImageTk.PhotoImage(im.resize(target, Image.Resampling.LANCZOS), master=root)
    return cache[key]


def tinted_image_photo(root, asset, width, color):
    """Recolor a monochrome navigation glyph without altering its transparency.

    Cached per-Tk interpreter just like the original PhotoImage; dark mode
    continues to use the untouched source asset.
    """
    from PIL import Image, ImageTk
    factor=dpi_scale(root)
    size=max(1,round(width*factor))
    key=(asset,size,color)
    cache=getattr(root,'_payroll_tinted_photo_cache',None)
    if cache is None:
        cache={}
        root._payroll_tinted_photo_cache=cache
    if key not in cache:
        with Image.open(asset_path(asset if asset.lower().endswith('.png') else f'{asset}.png')) as source:
            original=source.convert('RGBA')
        tint=Image.new('RGBA', original.size, color)
        tint.putalpha(original.getchannel('A'))
        cache[key]=ImageTk.PhotoImage(tint.resize((size,size),Image.Resampling.LANCZOS),master=root)
    return cache[key]


def set_window_icon(window):
    """Give every Tk and Toplevel identical branded taskbar/titlebar icons."""
    from PIL import Image, ImageTk
    ico = asset_path('kw_icon.ico')
    png = asset_path('kw_icon.png')
    try:
        if sys.platform == 'win32' and ico.is_file():
            window.iconbitmap(str(ico))
    except Exception:
        pass
    try:
        if png.is_file():
            img = Image.open(png).convert('RGBA')
            photo = ImageTk.PhotoImage(img.resize((256, 256), Image.Resampling.LANCZOS), master=window)
            window.iconphoto(True, photo)
            window._kw_icon_photo = photo  # retain the image's Tcl lifetime
    except Exception:
        pass


def set_navy_titlebar(window, background='#081725', foreground='#f2f6f9'):
    """Request dark native Windows title bar, retaining system window buttons.

    DWM custom caption colours require supported Windows builds. On older
    systems Windows retains its own caption colour and native functionality.
    """
    if sys.platform != 'win32':
        return False
    try:
        import ctypes
        from ctypes import byref, c_int, c_uint32, sizeof
        window.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(window.winfo_id()) or window.winfo_id()
        dwm = ctypes.windll.dwmapi.DwmSetWindowAttribute
        dark = c_int(1)
        for attribute in (20, 19):
            if dwm(hwnd, attribute, byref(dark), sizeof(dark)) == 0:
                break
        def bgr(color):
            rgb = color.lstrip('#')
            red, green, blue = (int(rgb[i:i+2], 16) for i in (0, 2, 4))
            return c_uint32(red | (green << 8) | (blue << 16))
        caption = bgr(background)
        text = bgr(foreground)
        result = dwm(hwnd, 35, byref(caption), sizeof(caption))
        dwm(hwnd, 36, byref(text), sizeof(text))
        return result == 0
    except (OSError, AttributeError, ValueError, TypeError):
        return False


def schedule_navy_titlebar(window, background="#081725", foreground="#ffffff"):
    """Recolor the native Windows caption after the HWND exists. No custom chrome."""
    if sys.platform != "win32":
        return
    def apply():
        if window.winfo_exists():
            set_navy_titlebar(window, background=background, foreground=foreground)
    window.after(65, apply)
