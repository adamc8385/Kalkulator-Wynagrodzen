"""Offline PDF for a MONTHLY PAYROLL ESTIMATE; no payslip reconciliation.

Requires ReportLab (installed by both Windows build scripts). Uses Arial or
Segoe UI from the user's operating system; never bundles a third-party font.
"""
from __future__ import annotations

import datetime as dt
import os
from html import escape
from pathlib import Path


def _font_names():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    candidates = [
        ('C:/Windows/Fonts', 'arial.ttf', 'arialbd.ttf'),
        ('C:/Windows/Fonts', 'segoeui.ttf', 'segoeuib.ttf'),
        ('/usr/share/fonts/truetype/dejavu', 'DejaVuSans.ttf', 'DejaVuSans-Bold.ttf'),
    ]
    for directory, normal, bold in candidates:
        p = Path(directory)
        if (p / normal).is_file() and (p / bold).is_file():
            pdfmetrics.registerFont(TTFont('KWBody62', str(p / normal)))
            pdfmetrics.registerFont(TTFont('KWBody62Bold', str(p / bold)))
            pdfmetrics.registerFontFamily('KWBody62', normal='KWBody62', bold='KWBody62Bold')
            return 'KWBody62', 'KWBody62Bold', True
    return 'Helvetica', 'Helvetica-Bold', False


def export_month_pdf(output_path, period, rows, cfg, result, deductions, leave_report=None,
                     language='pl', detailed_sections=None, position=''):
    """Generate a self-contained forecast using data already calculated by calc.

    No data modification; caller chooses destination using file dialog.
    """
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

    normal, bold, unicode_font = _font_names()
    if not unicode_font:
        raise RuntimeError('Nie znaleziono czcionki Arial, Segoe UI ani DejaVu Sans potrzebnej do polskich znaków w PDF.')
    navy = colors.HexColor('#082438')
    gold = colors.HexColor('#C6923A')
    pale = colors.HexColor('#E8F0F4')
    muted = colors.HexColor('#526779')
    styles = {
        'title': ParagraphStyle('title62', fontName=bold, fontSize=19, leading=26,
                                textColor=navy, spaceAfter=8),
        'subtitle': ParagraphStyle('subtitle62', fontName=normal, fontSize=10,
                                   textColor=muted, spaceAfter=18),
        'head': ParagraphStyle('section62', fontName=bold, fontSize=11,
                               textColor=navy, spaceBefore=14, spaceAfter=7),
        'body': ParagraphStyle('body62', fontName=normal, fontSize=9, leading=14,
                               textColor=navy),
        'small': ParagraphStyle('small62', fontName=normal, fontSize=8, leading=12,
                                textColor=muted),
        'number': ParagraphStyle('num62', fontName=bold, fontSize=13, leading=17,
                                 textColor=navy, alignment=TA_RIGHT),
    }

    en = language == 'en'
    def tr(pl, eng): return eng if en else pl
    def price(number): return f'{number:,.2f} PLN'.replace(',', ' ').replace('.', ',')
    def pair(label, value): return [Paragraph(escape(label), styles['body']), Paragraph(escape(value), styles['body'])]
    def table(items, widths=(345, 140)):
        result_table = Table(items, colWidths=list(widths), hAlign='LEFT', repeatRows=0)
        result_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.white),
            ('LINEBELOW', (0, 0), (-1, -2), .3, pale),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        return result_table
    t, offshore_days, rate, extras, gross, social, health, taxable, pit, ppk, net = result
    doc = SimpleDocTemplate(str(output_path), pagesize=A4, rightMargin=54, leftMargin=54,
                            topMargin=52, bottomMargin=46,
                            title=tr('Prognoza wynagrodzenia', 'Salary estimate') + ' ' + period,
                            author=tr('Kalkulator wynagrodzeń v6.2.26', 'Payroll Calculator v6.2.26'))
    elements = []
    elements.append(Paragraph(tr('ROZLICZENIE MIESIĘCZNE — PROGNOZA', 'MONTHLY PAYROLL ESTIMATE') if detailed_sections else tr('PROGNOZA WYNAGRODZENIA', 'SALARY ESTIMATE'), styles['title']))
    elements.append(Paragraph(
        tr(f'Miesiąc rozliczeniowy: {period}  |  Wygenerowano: {dt.date.today():%d.%m.%Y}',
           f'Payroll month: {period}  |  Created: {dt.date.today():%Y-%m-%d}'), styles['subtitle']))
    if not detailed_sections:
        elements.append(Paragraph(tr('Godziny i składniki', 'Hours and payroll components'), styles['head']))
        hour_rows = [pair(tr('Pensja zasadnicza brutto', 'Fixed gross base salary'), price(cfg['salary'])),
                     pair(tr('Stawka godzinowa', 'Hourly rate'), price(rate))]
        for code, title_pl, title_en in (
            ('N','Godziny normalne','Regular hours'),
            ('A','Nadgodziny A (+50%)','Overtime A (+50%)'),
            ('B','Nadgodziny B (+100%)','Overtime B (+100%)'),
            ('PN','PN','PN hours'), ('P','Podróże P','Travel P'), ('T','Podróże T','Travel T')):
            hour_rows.append(pair(tr(title_pl, title_en), f"{t[code]:g} h"))
        from night_work import night_bonus_detail
        night = night_bonus_detail(rows)
        hour_rows.append(pair(tr('Dodatek C — wyrównanie UE','EU C allowance'),price(cfg.get('eu_c_allowance',0))))
        hour_rows.append(pair(tr('ZFŚS — świadczenie socjalne','ZFSS cash benefit'),price(cfg.get('zfss_cash',0))))
        hour_rows.append(pair(tr('Dodatek PN za pracę w nocy (20% minimum)', 'PN night-work allowance (20% of minimum)'), price(night['amount'])))
        hour_rows.append(pair(tr('Dni offshore', 'Offshore days'), str(offshore_days)))
        hour_rows.append(pair(tr('Dodatki brutto (łącznie z urlopem, jeśli dostępny)', 'Gross allowances (including leave, if available)'), price(extras)))
        elements.append(table(hour_rows))
        elements.append(Paragraph(tr('Przewidywane rozliczenie', 'Estimated payroll'), styles['head']))
        pay_rows = [pair(tr('Wynagrodzenie gotówkowe brutto', 'Gross cash pay'), price(gross)),
                    pair(tr('Składki społeczne pracownika', 'Employee social contributions'), price(social)),
                    pair(tr('Składka zdrowotna', 'Health contribution'), price(health)),
                    pair(tr('Podstawa PIT', 'PIT taxable base'), price(taxable)),
                    pair(tr('Zaliczka PIT', 'PIT withholding'), price(pit)),
                    pair('PPK', price(ppk)),
                    pair(tr('PPE dodatkowe', 'Additional PPE'), price(cfg.get('ppe_extra', 0))),
                    pair(tr('Inne potrącenia', 'Other deductions'), price(cfg.get('other_deductions', 0)))]
        elements.append(table(pay_rows))
    if detailed_sections:
        # Full breakdown alongside the standard forecast summary. Components
        # remain separate from benefits which do not increase cash transfer.
        for heading,values in detailed_sections:
            elements.append(Paragraph(escape(heading),styles['head']))
            elements.append(table([pair(label,(f'{value:,.2f}'.replace(',',' ').replace('.',',')+' '+unit))
                                   for label,value,unit in values]))
    summary = Table([[Paragraph(tr('ORIENTACYJNY PRZELEW NETTO', 'ESTIMATED NET BANK TRANSFER'), styles['head']),
                      Paragraph(price(net), styles['number'])]], colWidths=[300, 185])
    summary.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), pale),
                                 ('LINEABOVE', (0, 0), (-1, -1), 1.3, gold),
                                 ('BOTTOMPADDING', (0, 0), (-1, -1), 11),
                                 ('TOPPADDING', (0, 0), (-1, -1), 3),
                                 ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')]))
    elements.append(Spacer(1, 14))
    elements.append(summary)
    notes = [
        tr('Jest to orientacyjna prognoza, a nie pasek płacowy ani gwarancja wypłaty.',
           'This is an estimate, not an official payslip or guaranteed payment.'),
        tr('Daty wypłat, premie, przesunięcia między okresami oraz podstawa wynagrodzenia urlopowego mogą zmienić wynik.',
           'Payment dates, bonuses, prior-period adjustments and leave-pay basis can change the amount.'),
        tr('ZFŚS ujęto jako kwalifikujące się świadczenie gotówkowe; roczne zwolnienie PIT wyliczono tylko z zapisanych kwot. Świadczenie może być wypłacone osobnym przelewem.',
           'ZFSS treated as eligible cash benefit; annual PIT exemption counts only recorded amounts. This benefit may be paid separately.'),
    ]
    if not rows:
        notes.append(tr('Nie zaimportowano kart dla tego miesiąca — kwota nie została potwierdzona godzinami pracy.',
                        'No work cards for this month; the estimate has no supporting work hours.'))
    if leave_report:
        if leave_report.get('estimated'):
            notes.append(tr('Zmienna część wynagrodzenia urlopowego jest szacunkiem.',
                            'The variable part of leave pay is estimated.'))
        if leave_report.get('hours') and not leave_report.get('complete'):
            notes.append(tr('Niepełna podstawa urlopowa — zmienna część nie została doliczona.',
                            'Incomplete leave-pay basis; variable leave pay was excluded.'))
    if (cfg.get('_ytd_progress') or {}).get('missing_months'):
        notes.append(tr('Narastanie PIT/ZUS oparte jest na niepełnej historii.',
                        'PIT/social YTD is based on incomplete historical data.'))
    elements.append(Paragraph(tr('Ważne informacje', 'Important information'), styles['head']))
    for note in notes:
        elements.append(Paragraph('• ' + escape(note), styles['small']))
        elements.append(Spacer(1, 6))

    def footer(canvas, _document):
        canvas.saveState()
        width, height = A4
        canvas.setStrokeColor(gold)
        canvas.setLineWidth(.7)
        canvas.line(54, height - 43, width - 54, height - 43)
        canvas.setFont(normal, 8)
        canvas.setFillColor(muted)
        canvas.drawString(54, 35, 'KW / ACH  •  v6.2.26  •  ' + tr('szacunek', 'estimate'))
        canvas.drawRightString(width - 54, 35, str(_document.page))
        canvas.restoreState()

    doc.build(elements, onFirstPage=footer, onLaterPages=footer)
    return str(output_path)
