"""Annual-leave pay from work-card estimates with optional payslip corrections.

Art. 172 Labour Code and sections 7-9 of the vacation pay regulation:
the variable component uses earnings PAID in the reference months and actual
hours WORKED. Work cards alone cannot establish payment dates or which items
qualify, so computed values are explicitly marked as ESTIMATES, not verified.
"""
from collections import defaultdict
import datetime as dt
import math
from company_calendar import day_category
from payroll_rules import cent, overtime_components


def is_pl_holiday(day):
    year=day.year
    a=year%19;b=year//100;c=year%100;d=b//4;e=b%4;f=(b+8)//25
    g=(b-f+1)//3;h=(19*a+b-d-g+15)%30;i=c//4;k=c%4
    l=(32+2*e+2*i-h-k)%7;m=(a+11*h+22*l)//451
    n=(h+l-7*m+114)//31;j=(h+l-7*m+114)%31+1
    easter=dt.date(year,n,j)
    fixed={(1,1),(1,6),(5,1),(5,3),(8,15),(11,1),(11,11),(12,25),(12,26)}
    if year>=2025:fixed.add((12,24))
    return ((day.month,day.day) in fixed or
            day==easter+dt.timedelta(days=1) or
            day==easter+dt.timedelta(days=60))


def standard_hours(day):
    return 8.0 if day_category(day)=='workday' else 0.0


def leave_hours_by_day(rows):
    """Type 6: one vacation day is counted once across overlapping cards."""
    grouped=defaultdict(lambda: defaultdict(float))
    for row in rows:
        if row.get('work_type')!=6:continue
        day=str(row.get('date',''))
        try:dt.date.fromisoformat(day)
        except ValueError:continue
        source=row.get('file_id') or row.get('source_path') or row.get('file') or '__unknown__'
        grouped[day][source]+=max(0.0,float(row.get('N',0) or 0))
    out={}
    for date,by_source in grouped.items():
        hours=max(by_source.values()) if by_source else 0.0
        if hours<=0:hours=standard_hours(dt.date.fromisoformat(date))
        out[date]=hours
    return out


def prior_months(month_id, count=3):
    year,month=map(int,month_id.split('-'))
    months=[]
    for _ in range(count):
        month-=1
        if month==0:month=12;year-=1
        months.append(f'{year:04d}-{month:02d}')
    return months


def _holiday_spells(all_days):
    """Weekend/holiday-only gaps do not start a new leave reference period."""
    active={dt.date.fromisoformat(k) for k,v in all_days.items() if v>0}
    starts={};last=None;first=None
    for day in sorted(active):
        continuous=False
        if last is not None:
            intermediate=[last+dt.timedelta(days=i) for i in range(1,(day-last).days)]
            continuous=all(standard_hours(d)==0 for d in intermediate)
        if not continuous:first=day
        starts[day.isoformat()]=first.isoformat()
        last=day
    return starts


def estimate_monthly_variable_history(rows, accounting_month, config_for_month):
    """Estimate selected wage components and worked hours from active cards.

    This is NOT a ledger of payments. Until payslips confirm payout timing,
    overtime is provisionally attributed to its accounting month.
    Hours = N+A+B for performed work; PN is deliberately omitted because it
    may overlap those columns. Travel, paid days off and type-6 vacation are
    excluded. Variable gross includes basic overtime 100% (1700) PLUS A/B premiums
    (50%/100%); excludes travel, offshore, benefits and one-off bonuses.
    """
    monthly=defaultdict(list)
    for row in rows:
        try:
            d=dt.date.fromisoformat(str(row['date']))
        except (ValueError,KeyError,TypeError):
            continue
        period=accounting_month(d.isoformat())
        if not period:
            continue  # Never pretend that an unassigned ISO week has a pay month.
        monthly[period].append(row)
    out={}
    for period, entries in monthly.items():
        cfg=config_for_month(period)
        salary=float(cfg.get('salary') or 0)
        nominal=float(cfg.get('nominal') or 0)
        if not (salary>0 and nominal>0):
            continue
        # Only actual work, not time off. Night hours (PN) generally overlap.
        performed=[r for r in entries if r.get('work_type') not in (5,6)]
        n=sum(max(0.,float(r.get('N',0) or 0)) for r in performed)
        a=sum(max(0.,float(r.get('A',0) or 0)) for r in performed)
        b=sum(max(0.,float(r.get('B',0) or 0)) for r in performed)
        worked=round(n+a+b,4)
        rate=cent(salary/nominal)
        # Same 2-decimal rate/premium and A/B model as the main calculator.
        overtime=overtime_components(performed, lambda _date:rate)
        overtime_base=overtime["all_base"]
        premium_a=overtime["premium_a"]
        premium_b=overtime["premium_b"]
        amount=cent(overtime_base+premium_a+premium_b)
        out[period]={'paid_variable_gross':amount,'worked_hours':worked,
                     'source':'auto_estimate','hourly_rate':round(rate,4),
                     'normal_work_hours':round(n,4),'overtime_a_hours':round(a,4),
                     'overtime_b_hours':round(b,4),
                     'component_breakdown':{'overtime_base':round(overtime_base,2),
                         'overtime_a_premium':round(premium_a,2),
                         'overtime_b_premium':round(premium_b,2)},
                     'card_count':len({r.get('file_id') or r.get('file') for r in entries})}
    return out


def calculate_leave_pay(rows, all_rows, verified_history, auto_history=None):
    """Use corrected payslip values first, otherwise card-based estimates.

    Return `variable_amount` only if each required month has observations and
    a positive total worked-hour denominator. `fully_verified` is true only
    for all-payslip data; automatic amounts remain flagged as estimated.
    """
    selected=leave_hours_by_day(rows)
    global_days=leave_hours_by_day(all_rows)
    starts=_holiday_spells(global_days)
    groups=defaultdict(list)
    for day,hours in selected.items():
        if hours>0:
            groups[starts.get(day,day)[:7]].append((day,hours))
    source_history=dict(auto_history or {})
    for period, data in (verified_history or {}).items():
        if isinstance(data,dict) and 'paid_variable_gross' in data and 'worked_hours' in data:
            source_history[period]=dict(data,source='payslip')
    missing=set();computed=[]
    all_verified=True
    for basis_month, entries in sorted(groups.items()):
        needed=prior_months(basis_month,3)
        valid=[];used={}
        for period in needed:
            item=source_history.get(period)
            try:
                paid=float(item['paid_variable_gross'])
                worked=float(item['worked_hours'])
                ok=(math.isfinite(paid) and math.isfinite(worked) and
                    0<=paid<10_000_000 and 0<=worked<=744)
            except (TypeError,ValueError,KeyError):ok=False
            if not ok:
                missing.add(period);all_verified=False
            else:
                source=item.get('source','payslip')
                valid.append((paid,worked))
                used[period]=dict(item)
                if source!='payslip':all_verified=False
        hours=round(sum(h for _,h in entries),4)
        complete=len(valid)==3 and sum(h for _,h in valid)>0
        if len(valid)==3 and not complete:
            missing.update(needed)
            all_verified=False
        amount=round(sum(v for v,_ in valid)/sum(h for _,h in valid)*hours,2) if complete else None
        computed.append({'start_month':basis_month,'hours':hours,
                         'required_months':needed,'amount':amount,
                         'complete':complete,'verified':complete and all(
                             used.get(p,{}).get('source')=='payslip' for p in needed),
                         'period_values':used})
    complete=bool(groups) and not missing and all(x['complete'] for x in computed)
    fully_verified=complete and all(x['verified'] for x in computed)
    return {'hours':round(sum(selected.values()),4),
            'days':sum(h>0 for h in selected.values()),
            'daily_hours':selected,'basis_months':sorted(groups),
            'details':computed,'missing_months':sorted(missing),
            'fully_verified':fully_verified,'complete':complete,
            'estimated':complete and not fully_verified,
            'month_history':source_history,
            'variable_amount':round(sum(x['amount'] for x in computed),2) if complete else None}
