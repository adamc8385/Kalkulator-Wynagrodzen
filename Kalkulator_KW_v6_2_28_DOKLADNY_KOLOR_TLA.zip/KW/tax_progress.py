"""Annual PIT/social contribution opening balances, month by month.

Every interim value is a calculation, NOT proof of a payment. User-confirmed
payslip *closing* amounts are optional anchors and take precedence. Estimated
periods lacking work cards are explicitly identified as incomplete.
"""

from work_card_policy import supported_date

def opening_balances(db, target_period, raw_cfg_for_month,calc,accounting_month):
    year,month=map(int,target_period.split('-'))
    tax_total=social_total=0.
    excluded=set(db.get('excluded_files') or [])
    all_rows=[r for r in (db.get('rows') or []) if r.get('file_id') not in excluded and supported_date(r.get('date'))]
    anchors=db.get('payslip_balances') or {}
    estimated=[]; modeled=[]; missing=[]; missing_reasons={}; anchored=False
    for m in range(1,month):
        period=f'{year:04d}-{m:02d}'
        closing=anchors.get(period)
        if isinstance(closing,dict) and any(k in closing for k in ('tax','social')):
            # A payslip may confirm ONLY one of the two independent annual
            # bases. Never invent a missing PIT balance to enter a ZUS anchor.
            if 'tax' in closing:
                tax_total=max(0.,float(closing['tax']))
            if 'social' in closing:
                social_total=max(0.,float(closing['social']))
            anchored=True
            # Only a complete pair can erase uncertainty from earlier months.
            if 'tax' in closing and 'social' in closing:
                estimated=[];modeled=[];missing=[];missing_reasons={}
            continue
        active=[r for r in all_rows if accounting_month(str(r.get('date','')),db)==period]
        cfg=raw_cfg_for_month(period)
        if cfg.get('salary',0)<=0 or not cfg.get('nominal'):
            estimated.append(period)
            missing.append(period)
            missing_reasons[period] = ('missing_salary' if cfg.get('salary',0)<=0 else 'missing_nominal')
            continue
        cfg=dict(cfg)
        cfg['ytd_tax_base']=tax_total
        cfg['social_ytd']=social_total
        cfg['_leave_variable_pay']=0.0  # Leave-variable payment month not verifiable from cards.
        def rate_for_date(day):
            try:
                source_period=accounting_month(day,db) or day[:7]
                prior=raw_cfg_for_month(source_period)
                return float(prior['salary'])/float(prior['nominal']) if prior.get('nominal') else 0.
            except (ValueError,KeyError,TypeError):
                return 0.
        cfg['_rate_for_date']=rate_for_date
        try:
            _totals,_days,_rate,_extra,_gross,_social,_health,taxable,_pit,_ppk,_net=calc(active,cfg)
        except Exception as error:
            estimated.append(period)
            missing.append(period)
            missing_reasons[period] = 'calculation_failed: ' + type(error).__name__
            continue
        # Social cap is applied in calc to contributions; the cumulative
        # contribution BASE still tracks eligible gross (pre-cap).
        benefits=(float(cfg.get('edenred_benefit',0) or 0)+float(cfg.get('luxmed_benefit',0) or 0))*float(cfg.get('benefits_in_social',1))
        social_total+=_gross-float(cfg.get('zfss_cash',0) or 0)+benefits
        tax_total+=taxable
        modeled.append(period)
        if not active:
            estimated.append(period)
    return {
        'tax':max(0.,tax_total),
        'social':max(0.,social_total),
        'verified_anchor':anchored,
        'estimated_months':estimated,
        'missing_months':missing,
        'missing_reasons':missing_reasons,
        'modeled_months':modeled,
        'status':('incomplete' if missing else 'confirmed' if anchored and not modeled and not estimated else 'estimate'),
    }
