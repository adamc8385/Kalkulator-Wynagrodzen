"""Shared, non-destructive policy for supported work-card years."""
import datetime as dt
import re
from pathlib import Path

MIN_CARD_YEAR = 2024


def supported_date(value):
    try:
        return dt.date.fromisoformat(str(value)[:10]).year >= MIN_CARD_YEAR
    except (TypeError, ValueError):
        return False


def card_week_from_name(filename):
    """Match a KP week number, not arbitrary numbers in names/job IDs."""
    name = Path(str(filename)).stem
    match = re.search(r'(?i)(?<![a-z0-9])KP[ _-]*0*([1-9]|[1-4][0-9]|5[0-3])(?![0-9])', name)
    if not match:
        return None
    return int(match.group(1))


def year_from_parent(path):
    folder = Path(str(path)).parent.name
    return int(folder) if re.fullmatch(r'\d{4}', folder) else None


def unsupported_legacy_path(path, rows=()):
    """Never let a synchronization delete old cards intentionally excluded."""
    year = year_from_parent(path)
    return (year is not None and year < MIN_CARD_YEAR) or (
        bool(rows) and all(not supported_date(row.get('date')) for row in rows))


class UnsupportedCardYear(ValueError):
    """Workbook consists solely of cards dated before 2024."""
