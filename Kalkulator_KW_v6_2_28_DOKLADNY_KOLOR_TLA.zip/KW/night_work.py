"""Work-card night intervals and the statutory PN supplement.

PN is an overlapping classification: never include it in worked-hours sums.
For an ambiguous clock interval, refuse to infer a correction.
"""
from __future__ import annotations
import datetime as dt
import re
import unicodedata
from collections import defaultdict
from payroll_rules import cent
from company_calendar import scheduled_hours

# Statutory MONTHLY minimum (not the statutory hourly CONTRACTOR minimum).
MINIMUM_WAGE = {(2024, 1): 4242.0, (2024, 7): 4300.0,
                (2025, 1): 4666.0, (2026, 1): 4806.0}


def minimum_wage_on(day):
    if day.year not in (2024, 2025, 2026):
        return None
    choices = [(m, wage) for (year, m), wage in MINIMUM_WAGE.items()
               if year == day.year and m <= day.month]
    return max(choices)[1] if choices else None


def night_bonus_detail(rows):
    """PN by work date, rounded per-hour first; unavailable years unpriced."""
    total = 0.0
    unpriced = 0.0
    for row in rows:
        hours = float(row.get('PN', 0) or 0)
        if hours <= 0:
            continue
        try:
            day = dt.date.fromisoformat(str(row['date'])[:10])
        except (ValueError, KeyError, TypeError):
            unpriced += hours
            continue
        minimum = minimum_wage_on(day)
        nominal = scheduled_hours(day.year, day.month)
        if minimum is None or nominal <= 0:
            unpriced += hours
        else:
            total += cent(cent(.2 * minimum / nominal) * hours)
    return {'amount': cent(total), 'unpriced_hours': round(unpriced, 4)}


def _normalize(value):
    value = unicodedata.normalize('NFKD', str(value or ''))
    return ''.join(ch for ch in value if not unicodedata.combining(ch)).casefold().strip()


def time_column_roles(headers):
    """Only explicit WORK start/end headers authorize numeric Excel clocks."""
    roles = {}
    for col, label in headers.items():
        text = _normalize(label)
        if not any(k in text for k in ('godzin', 'pracy', 'work', 'time', 'rozpocz', 'zakonc', 'start', 'koniec')):
            continue
        if any(k in text for k in ('rozpocz', 'poczatek', 'od godz', 'godz od', 'start')):
            roles['start'] = col
        elif any(k in text for k in ('zakonc', 'koniec', 'do godz', 'godz do', 'finish', 'end')):
            roles['end'] = col
    return roles if set(roles) == {'start', 'end'} else {}


def parse_clock(value, allow_numeric=True):
    """Clock minutes; supports HH:MM, explicit time serial, ISO HH:MM:SS."""
    if value is None or value == '':
        return None
    if isinstance(value, dt.time):
        return value.hour*60 + value.minute if value.second == 0 else None
    s = str(value).strip().replace(',', '.')
    match = re.fullmatch(r'(\d{1,2}):(\d{2})(?::00)?', s)
    if match:
        h, m = int(match[1]), int(match[2])
        if (h == 24 and m == 0): return 1440
        return h*60+m if 0<=h<24 and 0<=m<60 else None
    if not allow_numeric:
        return None
    try: n = float(s)
    except ValueError: return None
    if not (0 <= n < 1):
        return None
    return int(round(n*1440)) % 1440


def source_clocks(vals, roles, time_styles=None):
    """Trust identified start/end headers, literal HH:MM, or clock-formatted D/E.

    Numeric Excel serials without a verified time style remain ambiguous and
    must never be mistaken for working hours.
    """
    if roles:
        a, b = vals.get(roles['start']), vals.get(roles['end'])
        if (a is None or a == '') and (b is None or b == ''):
            return None
        return {'work_start_raw': a, 'work_end_raw': b,
                'work_clock_source': 'headers'}
    a,b = vals.get('D'), vals.get('E')
    if (parse_clock(a,False) is not None and parse_clock(b,False) is not None):
        return {'work_start_raw':a,'work_end_raw':b,
                'work_clock_source':'literal'}
    # In the approved work-card layout, D/E are the start/end columns. The
    # styles.xml XF number formats confirm that numeric serials are clock
    # times rather than arbitrary decimal values in other Excel templates.
    styles = time_styles or {}
    if (styles.get('D') and styles.get('E')
            and parse_clock(a) is not None and parse_clock(b) is not None):
        return {'work_start_raw': a, 'work_end_raw': b,
                'work_clock_source': 'excel_time_style'}
    return None


def interval_minutes(row):
    """(start, end-unwrapped) or None; zero duration is ambiguous."""
    if not row.get('work_clock_source') and not ('work_start' in row and 'work_end' in row):
        return None
    start = parse_clock(row.get('work_start_raw', row.get('work_start')))
    end = parse_clock(row.get('work_end_raw', row.get('work_end')))
    if start is None or end is None or start == end:
        return None
    if end < start: end += 1440
    if not (0 < end-start <= 1440):
        return None
    return start, end


def classify_interval(start_min, end_min, previous_work_minutes=0):
    """Count each worked minute, including work beyond midnight, no PN double count."""
    totals = {'N':0, 'A':0, 'B':0, 'PN':0}
    for minute in range(start_min, end_min):
        clock = minute % 1440
        night = (clock >= 22*60 or clock < 6*60)
        elapsed = previous_work_minutes + minute-start_min
        key = 'N' if elapsed < 8*60 else ('B' if night else 'A')
        totals[key] += 1
        if night: totals['PN'] += 1
    return {key: value/60 for key,value in totals.items()}


def _positive(value):
    try:
        n=float(value or 0)
        return 0 < n <= 24
    except (ValueError, TypeError):
        return False


def expected_day_entries(rows):
    """Group explicit time intervals per work card and start date, 8 N across segments.

    If a row of work lacks trustworthy clocks, only classify its PN when possible;
    never infer an A/B allocation from partial-day information.
    """
    groups=defaultdict(list)
    for row in rows:
        if row.get('work_type') in (5,6):
            continue
        # A travel-only entry (2/10/11) must not be treated as a worked shift.
        if row.get('work_type') in (2, 10, 11) and any(_positive(row.get(k)) for k in ('P','T')):
            continue
        if not any(_positive(row.get(k)) for k in ('N','A','B','PN')) and interval_minutes(row) is None:
            continue
        groups[(row.get('file_id'),row.get('date'))].append(row)
    result={}
    for _key, items in groups.items():
        intervals=[(row,interval_minutes(row)) for row in items]
        if any(x is None for _,x in intervals):
            for row, clock in intervals:
                if clock is not None:
                    result[id(row)]={'PN':classify_interval(*clock)['PN']}
            continue
        # If one sub-entry crosses midnight and another is recorded after
        # midnight under the same date, its placement is ambiguous. Do not
        # guess the N/A/B split (PN remains independently verifiable).
        if len(intervals)>1 and any(end>1440 for _,(start,end) in intervals):
            for row,clock in intervals:
                result[id(row)]={'PN':classify_interval(*clock)['PN']}
            continue
        intervals.sort(key=lambda pair:pair[1][0])
        # Overlapping shifts in one day do not have an unambiguous sequence.
        if any(a[1][1]>b[1][0] for a,b in zip(intervals,intervals[1:])):
            for row,clock in intervals:
                result[id(row)]={'PN':classify_interval(*clock)['PN']}
            continue
        elapsed=0
        for row,(start,end) in intervals:
            result[id(row)]=classify_interval(start,end,elapsed)
            elapsed += end-start
    return result
