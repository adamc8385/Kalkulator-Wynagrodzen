"""Optional, non-destructive leave-balance widget on the payroll dashboard."""
from __future__ import annotations

import calendar
import datetime as dt
import tkinter as tk
from tkinter import messagebox

from leave_balance import balance_by_year, normalize_settings
from work_card_policy import MIN_CARD_YEAR
from ui_theme import register_popup as theme_popup
from dashboard_visual import metric_card, section_heading

NAVY = '#081725'
PANEL = '#10293c'
PANEL2 = '#193a51'
GOLD = '#d8b16b'
WHITE = '#f2f6f9'
MUTED = '#aec0cd'


def _format_days(number, language='pl'):
    s = f'{float(number):.3f}'.rstrip('0').rstrip('.')
    return s.replace('.', ',') if language != 'en' else s


def _reference_date(month_id):
    year, month = map(int, month_id.split('-'))
    last = dt.date(year, month, calendar.monthrange(year, month)[1])
    return min(last, dt.date.today())


def _settings_dialog(app, year, start_year, save_callback):
    english = app.language == 'en'
    stored = app.db.get('leave_balance_settings')
    normalized = normalize_settings(stored, start_year)
    popup = tk.Toplevel(app.root)
    theme_popup(popup,app,popup_surface='main')
    popup.title('Leave balance — settings' if english else 'Urlop — ustawienia bilansu')
    from ui_assets import schedule_navy_titlebar
    schedule_navy_titlebar(popup,background=NAVY,foreground="#ffffff")
    popup.configure(bg=NAVY)
    popup.geometry('630x480')
    popup.minsize(530, 440)
    popup.resizable(True, True)
    popup.transient(app.root)
    try:
        from ui_assets import set_window_icon
        set_window_icon(popup)
    except (OSError, tk.TclError, ImportError):
        pass

    tk.Label(popup, text=('ANNUAL LEAVE — SETTINGS' if english else 'URLOP WYPOCZYNKOWY — USTAWIENIA'),
             font=('Segoe UI', 16, 'bold'), bg=NAVY, fg=GOLD).pack(anchor='w', padx=22, pady=(18, 8))
    tk.Label(popup, text=('The balance is an estimate from work cards (type 6), not an employer record.' if english
                          else 'Bilans jest szacunkiem z kart pracy (typ 6), a nie oficjalną ewidencją pracodawcy.'),
             font=('Segoe UI', 10), bg=NAVY, fg=MUTED, wraplength=580,
             justify='left').pack(anchor='w', padx=22, pady=(0, 15))
    form = tk.Frame(popup, bg=PANEL, padx=19, pady=13)
    form.pack(fill='both', expand=True, padx=20, pady=(0, 12))
    form.columnconfigure(1, weight=1)

    def field(row, caption, value):
        shade='#142f43' if row%2==0 else '#1b394f'
        line=tk.Frame(form,bg=shade,padx=12,pady=7)
        line.grid(row=row,column=0,columnspan=2,sticky='ew',pady=3)
        line.columnconfigure(0,weight=1)
        tk.Label(line, text=caption, font=('Segoe UI', 10), bg=shade, fg=WHITE,
                 wraplength=300, justify='left').grid(row=0,column=0,sticky='w')
        var = tk.StringVar(value=str(value))
        entry = tk.Entry(line, textvariable=var, width=15, bg='#ffffff', fg='#172e40',
                         insertbackground='#172e40', relief='flat', font=('Segoe UI', 11))
        entry.grid(row=0,column=1,sticky='e',padx=(16,0),ipady=5)
        return var

    annual = field(0, 'Annual entitlement (days)' if english else 'Roczny wymiar urlopu (dni)', _format_days(normalized['annual_days'], 'en'))
    first = field(1, 'First tracked year (2024 or later)' if english else 'Pierwszy rozliczany rok (od 2024)', normalized['start_year'])
    opening = field(2, 'Carried days before the first year' if english else 'Zaległy urlop na początek pierwszego roku (dni)', _format_days(normalized['opening_carry_days'], 'en'))
    current = normalized['yearly_days'].get(str(year))
    override = field(3, (f'Entitlement override for {year} (blank = annual)' if english
                         else f'Korekta wymiaru na {year} r. (puste = wymiar roczny)'),
                     '' if current is None else _format_days(current, 'en'))
    tk.Label(form, text=('If some past cards are missing, set the first tracked year and carried balance '
                         'from employer records. Missing cards cannot be reconstructed automatically.' if english else
                         'Jeśli brakuje dawnych kart, ustaw rok początkowy i saldo zaległe według danych '
                         'pracodawcy. Program nie odtworzy automatycznie brakujących urlopów.'),
             font=('Segoe UI', 9), bg=PANEL, fg=MUTED, wraplength=540,
             justify='left').grid(row=4, column=0, columnspan=2, sticky='w', pady=(10, 2))

    footer = tk.Frame(popup, bg=NAVY)
    footer.pack(fill='x', padx=20, pady=(0, 18))

    def save_settings():
        try:
            chosen_first = int(first.get().strip())
            if first.get().strip() != str(chosen_first):
                raise ValueError('Rok początkowy musi być liczbą całkowitą.')
            if chosen_first > year:
                raise ValueError('Rok początkowy nie może być późniejszy niż wyświetlany rok.')
            values = {'start_year': chosen_first, 'annual_days': annual.get(),
                      'opening_carry_days': opening.get(),
                      'yearly_days': dict(normalized['yearly_days'])}
            if override.get().strip():
                values['yearly_days'][str(year)] = override.get()
            else:
                values['yearly_days'].pop(str(year), None)
            validated = normalize_settings(values, chosen_first)
        except (ValueError, TypeError) as exc:
            messagebox.showerror('Leave balance' if english else 'Bilans urlopu', str(exc), parent=popup)
            return
        app.db['leave_balance_settings'] = validated
        save_callback(app.db)
        popup.destroy()
        app.show('Pulpit')

    tk.Button(footer, text=('Save' if english else 'Zapisz'), command=save_settings,
              bg='#138567', fg=WHITE, relief='flat', padx=18, pady=9,
              font=('Segoe UI', 10, 'bold')).pack(side='right')
    tk.Button(footer, text=('Cancel' if english else 'Anuluj'), command=popup.destroy,
              bg=PANEL2, fg=WHITE, relief='flat', padx=15, pady=9,
              font=('Segoe UI', 10)).pack(side='right', padx=(0, 12))
    popup.bind('<Escape>', lambda _event: popup.destroy())
    popup.grab_set()


def _history_dialog(app, result):
    english = app.language == 'en'
    win = tk.Toplevel(app.root)
    theme_popup(win,app,popup_surface='main')
    from ui_assets import schedule_navy_titlebar
    schedule_navy_titlebar(win,background=NAVY,foreground="#ffffff")
    win.title('Annual leave — history' if english else 'Historia urlopu')
    win.configure(bg=NAVY)
    win.geometry('720x450')
    win.minsize(570, 350)
    win.transient(app.root)
    try:
        from ui_assets import set_window_icon
        set_window_icon(win)
    except (OSError, tk.TclError, ImportError):
        pass
    tk.Label(win, text='HISTORIA URLOPU' if not english else 'ANNUAL LEAVE HISTORY',
             font=('Segoe UI', 16, 'bold'), bg=NAVY, fg=GOLD).pack(anchor='w', padx=20, pady=(18, 12))
    wrap = tk.Frame(win, bg=PANEL)
    wrap.pack(fill='both', expand=True, padx=20)
    from tkinter import ttk
    columns = ('year', 'carry', 'annual', 'used', 'left')
    table = ttk.Treeview(wrap, columns=columns, show='headings',style='LeaveHistory.Treeview')
    headings = ('Year', 'Brought', 'Entitlement', 'Used', 'Remaining') if english else (
        'Rok', 'Zaległy', 'Przysługuje', 'Wykorzystano', 'Pozostało')
    for column, label in zip(columns, headings):
        table.heading(column, text=label)
        table.column(column, width=125 if column != 'year' else 80, anchor='center', stretch=True)
    light=app.theme_mode=='light'
    table.tag_configure('even',background='#eff5fa' if light else '#10293c',foreground='#193047' if light else WHITE)
    table.tag_configure('odd',background='#e2edf5' if light else '#193a51',foreground='#193047' if light else WHITE)
    for index,row in enumerate(reversed(result['years'])):
        table.insert('', 'end', tags=('even' if index%2==0 else 'odd',),
                     values=(row['year'], _format_days(row['carry_in_days'], app.language),
                             _format_days(row['entitlement_days'], app.language),
                             _format_days(row['used_days'], app.language),
                             _format_days(row['remaining_days'], app.language)))
    bar = ttk.Scrollbar(wrap, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=bar.set)
    table.pack(side='left', fill='both', expand=True)
    bar.pack(side='right', fill='y')
    tk.Label(win, text=('Unused leave is carried over; it is not automatically deleted at the September deadline.'
                        if english else 'Niewykorzystany urlop przechodzi na kolejny rok. Program nie usuwa go automatycznie po 30 września.'),
             font=('Segoe UI', 9), bg=NAVY, fg=MUTED, wraplength=680).pack(anchor='w', padx=20, pady=12)
    tk.Button(win, text='Close' if english else 'Zamknij', command=win.destroy,
              bg=PANEL2, fg=WHITE, relief='flat', padx=18, pady=8).pack(anchor='e', padx=20, pady=(0, 15))
    win.bind('<Escape>', lambda _event: win.destroy())
    win.grab_set()


def attach_leave_dashboard(app, parent, save_callback):
    """Add a leave box without changing salary/payroll functions."""
    try:
        year = int(app.month.get()[:4])
        as_of = _reference_date(app.month.get())
        result = balance_by_year(app.db.get('rows') or [],
                                 app.db.get('leave_balance_settings'),
                                 target_year=year, as_of=as_of,
                                 excluded_files=app.db.get('excluded_files') or [])
    except (ValueError, TypeError, OverflowError) as exc:
        frame = tk.Frame(parent, bg=PANEL, padx=15, pady=13)
        frame.pack(fill='x', pady=10)
        tk.Label(frame, text='URLOP WYPOCZYNKOWY — BŁĄD USTAWIEŃ', bg=PANEL, fg='#ffb28e').pack(anchor='w')
        tk.Label(frame, text=str(exc), bg=PANEL, fg=WHITE).pack(anchor='w')
        return

    lang = app.language
    english = lang == 'en'
    mode=getattr(app,'theme_mode','dark')
    is_light=(mode=='light')
    area_bg='#ffffff' if is_light else PANEL
    frame=tk.Frame(parent,bg=area_bg,padx=8 if is_light else 17,
                   pady=6 if is_light else 10)
    frame.pack(fill='x',pady=(10,5))
    title=(f'ANNUAL LEAVE — {year}' if english else f'URLOP WYPOCZYNKOWY — {year}')
    section_heading(frame,title,'umbrella',mode,app.root,app.ui_scale,
                    command=lambda:_settings_dialog(app,year,result['start_year'],save_callback),
                    button_text='Settings' if english else 'Ustawienia urlopu')
    if result['status'] == 'before_start':
        tk.Label(frame, text=('Leave records begin in ' if english else 'Ewidencja urlopu rozpoczyna się w roku ')
                 + str(result['start_year']), bg=PANEL, fg=MUTED).pack(anchor='w', pady=13)
        return

    data = result['current']
    tiles=tk.Frame(frame,bg=area_bg)
    tiles.pack(fill='x',pady=(7 if is_light else 8,4))
    labels=[('Annual entitlement','Przysługuje','entitlement_days','calendar'),
            ('Brought forward','Zaległy','carry_in_days','calendar_x'),
            ('Used','Wykorzystano','used_days','calendar_check'),
            ('Remaining','Pozostało','remaining_days','hourglass')]
    for en,pl,key,icon in labels:
        metric_card(tiles,en if english else pl,
                    _format_days(data[key],lang) + (' days' if english else ' dni'),
                    icon,mode,app.root,app.ui_scale,vacation=True)
    if data['overused_days']:
        text = (f'Leave usage exceeds available entitlement by {_format_days(data["overused_days"],lang)} days. '
                'Verify the opening balance and work cards.' if english else
                f'Wykorzystanie przekracza dostępną pulę o {_format_days(data["overused_days"],lang)} dni. '
                'Sprawdź saldo początkowe i karty pracy.')
        tk.Label(frame, text=text, bg=PANEL, fg='#ffb28e',
                 font=('Segoe UI', 10), justify='left', wraplength=1000).pack(anchor='w', pady=(4, 0))
    if result['skipped']:
        text = ('Leave type 6 on non-working days without hours was not deducted: '
                if english else 'Nie odliczono dni z kodem 6 przypadających na dni wolne bez wpisanych godzin: ')
        text += ', '.join(result['skipped'][:5])
        if len(result['skipped']) > 5:
            text += '…'
        tk.Label(frame, text=text, bg=PANEL, fg='#ffcb85',
                 font=('Segoe UI', 9), justify='left', wraplength=1000).pack(anchor='w', pady=(4, 0))
    # Compact dashboard: retain the History action, omit the explanatory
    # strip the user asked to remove. The underlying leave calculations remain.
    bottom=tk.Frame(frame,bg=area_bg)
    bottom.pack(fill='x',pady=(4,0))
    tk.Button(bottom,text='History' if english else 'Historia',
              command=lambda:_history_dialog(app,result),
              bg='#0e4c80' if is_light else PANEL2,
              fg='#fefefe' if is_light else WHITE,
              activebackground='#216998',relief='flat',bd=0,
              font=('Segoe UI',9,'bold'),padx=14,pady=7).pack(side='right',padx=(10,0))
