"""Pure dashboard summary formatter: hide zero-valued monthly items."""

def visible_monthly_summary(totals, travel_before, travel_deducted, travel_after,
                            offshore_days, leave_hours, settings, total_hours,
                            day_unit='dni', night_unit='nocy'):
    """Visible (label, formatted value) entries; do not mutate payroll data."""
    items=[('Godziny normalne N — kalendarz',totals.get('N',0),'h'),
           ('Nadgodziny A — dodatek 50%',totals.get('A',0),'h'),
           ('Nadgodziny B — dodatek 100%',totals.get('B',0),'h'),
           ('Godziny nocne PN',totals.get('PN',0),'h'),
           ('Czas podróży po odliczeniu',travel_after,'h'),
           ('Offshore',offshore_days,day_unit),
           ('Urlop (h)',leave_hours,'h'),
           ('Wspólna kabina — liczba nocy',settings.get('shared_room_nights',0),night_unit),
           ('Dodatek do diety — liczba dni',settings.get('domestic_diet_extra_days',0),day_unit),
           ('Podróż samochodem — liczba dodatków',settings.get('car_bonus_count',0),''),
           ('Dodatek za ryzyko — dni',settings.get('risk_days',0),day_unit),
           ('Dodatkowe wynagrodzenie brutto',settings.get('other_gross',0),'zł'),
           ('Wynagrodzenie urlopowe — część zmienna',settings.get('_leave_variable_pay',0),'zł'),
           ('Łączna liczba godzin',total_hours,'h')]
    visible=[]
    for label,number,unit in items:
        try:amount=float(number or 0)
        except (TypeError,ValueError):continue
        if amount<=0:continue
        value=(f'{amount:,.2f}'.replace(',',' ').replace('.',',') if unit=='zł'
               else f'{amount:g}')
        visible.append((label, f'{value} {unit}'.strip()))
    return visible
