"""Professional monthly payroll report — export-only, never mutates user data."""
from __future__ import annotations

from datetime import date
from tkinter import filedialog, messagebox


def payroll_sections(period, rows, cfg, result, deductions, position='', language='pl'):
    from kalkulator_wynagrodzenia import overtime_components, travel_breakdown, travel_bonus
    from night_work import night_bonus_detail
    totals, days, rate, extras, gross, social, health, taxable, pit, ppk, net = result
    over = overtime_components(rows, cfg.get('_rate_for_date') or (lambda _:rate))
    travel = travel_breakdown(rows)
    night = night_bonus_detail(rows)
    pl = language != 'en'
    def t(pl_label, en_label): return pl_label if pl else en_label
    def item(a, b, value, unit='zł'):return (t(a,b), float(value), unit)
    sections = [
        (t('I. INFORMACJE I CZAS PRACY','I. PERIOD AND WORK HOURS'), [
            item('Nominał N — kalendarz miesiąca','Nominal N — calendar month',totals['N'],'h'),
            item('Nadgodziny A','Overtime A',totals['A'],'h'),
            item('Nadgodziny B','Overtime B',totals['B'],'h'),
            item('Godziny nocne PN (nakładają się)','Night-work PN (overlapping)',totals['PN'],'h'),
            item('Podróże — przed odliczeniem','Travel hours before deduction',sum(v[0] for v in travel.values()),'h'),
            item('Podróże — odliczenie','Travel hours deducted',sum(v[1] for v in travel.values()),'h'),
            item('Podróże — płatne','Travel hours paid',sum(v[2] for v in travel.values()),'h'),
            item('Dni offshore','Offshore days',days,'dni' if pl else 'days'),
        ]),
        (t('II. WYNAGRODZENIE I DODATKI BRUTTO','II. GROSS PAY COMPONENTS'), [
            item('Wynagrodzenie zasadnicze','Base salary',cfg['salary']),
            item('Stawka godzinowa','Hourly base rate',rate),
            item('1700 — Wynagrodzenie za nadgodziny 100%','1700 — Overtime basic pay 100%',over['all_base']),
            item('1711 — Nadgodziny A — dodatek 50%','1711 — Overtime A premium 50%',over['premium_a']),
            item('1721 — Nadgodziny B — dodatek 100%','1721 — Overtime B premium 100%',over['premium_b']),
            item('Dodatek PN','PN night-work premium',night['amount']),
            item('Dodatek za podróż','Travel allowance',travel_bonus(rows,cfg)),
            item('Offshore','Offshore',days*cfg.get('offshore',0)),
            item('1746 — Dodatek do diety','1746 — Per diem supplement',cfg.get('domestic_diet_extra_days',0)*55),
            item('Podróż samochodem — zatwierdzona','Approved car-trip allowance',cfg.get('car_bonus_count',0)*400),
            item('Wspólna kabina','Shared cabin',cfg.get('shared_room_nights',0)*100),
            item('Dodatek za ryzyko','Risk allowance',cfg.get('risk_days',0)*230*cfg.get('risk_factor',1)),
            item('Inne dodatki brutto','Other gross allowances',cfg.get('other_gross',0)),
            item('Dodatek C — wyrównanie UE','EU C top-up',cfg.get('eu_c_allowance',0)),
            item('ZFŚS — świadczenie pieniężne','ZFSS cash benefit',cfg.get('zfss_cash',0)),
            item('Wynagrodzenie urlopowe — zmienne','Leave variable pay',cfg.get('_leave_variable_pay',0)),
            item('Dodatki brutto łącznie','Total gross extras',extras),
            item('RAZEM BRUTTO (GOTÓWKOWE)','TOTAL GROSS CASH PAY',gross),
        ]),
        (t('III. SKŁADKI I PODATEK','III. CONTRIBUTIONS AND INCOME TAX'), [
            item('Emerytalne pracownika 9,76%','Employee pension 9.76%',-deductions['emerytalna']),
            item('Rentowe pracownika 1,50%','Employee disability 1.50%',-deductions['rentowa']),
            item('Chorobowe pracownika 2,45%','Employee sickness 2.45%',-deductions['chorobowa']),
            item('Składka zdrowotna 9%','Health insurance 9%',-health),
            item('ZFŚS — zwolnione z PIT','ZFSS — PIT exempt',deductions.get('zfss_exempt',0)),
            item('ZFŚS — podlegające PIT','ZFSS — PIT taxable',deductions.get('zfss_taxable',0)),
            item('Podstawa opodatkowania PIT','PIT taxable base',taxable),
            item('Zaliczka na podatek PIT','Income tax advance',-pit),
            item('PPK pracownika','Employee PPK',-ppk),
            item('Dodatkowe PPE','Additional PPE',-cfg.get('ppe_extra',0)),
            item('Pozostałe potrącenia','Other deductions',-cfg.get('other_deductions',0)),
        ]),
        (t('IV. ŚWIADCZENIA POZAPŁACOWE (POZA PRZELEWEM)',
           'IV. NON-CASH BENEFITS (EXCLUDED FROM TRANSFER)'), [
            item('Edenred — oddzielna karta','Edenred — separate card',cfg.get('edenred_benefit',0)),
            item('LuxMed — świadczenie niepieniężne','LuxMed — noncash',cfg.get('luxmed_benefit',0)),
            item('PPE pracodawcy','Employer PPE',deductions['employer_ppe']),
            item('PPO pracodawcy','Employer PPO',deductions['employer_ppo']),
        ]),
        (t('V. PODSUMOWANIE','V. FINAL SUMMARY'), [
            item('Wynagrodzenie gotówkowe brutto','Gross cash pay',gross),
            item('PROGNOZA PRZELEWU NETTO','ESTIMATED NET TRANSFER',net),
        ]),
    ]
    return sections


def export_month_excel(path, period, sections, position='', language='pl'):
    """Format-preserving numeric XLSX snapshot, separate from source work cards."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.page import PageMargins

    wb=Workbook();ws=wb.active;ws.title='Rozliczenie' if language=='pl' else 'Payroll'
    ws.sheet_view.showGridLines=False
    ws.column_dimensions['A'].width=58
    ws.column_dimensions['B'].width=19
    ws.column_dimensions['C'].width=16
    ws.column_dimensions['D'].width=4
    navy='0A2133'; mid='173B55'; gold='E6B764'; light='EAF1F7'; muted='586D7C'; white='FFFFFF'
    ws.merge_cells('A1:C2');t=ws['A1'];t.value='ROZLICZENIE MIESIĘCZNE — PROGNOZA' if language=='pl' else 'MONTHLY PAYROLL ESTIMATE'
    t.font=Font(name='Aptos Display',size=18,bold=True,color=white)
    t.fill=PatternFill('solid',fgColor=navy);t.alignment=Alignment(vertical='center',indent=1)
    for row in ws['A1:C2']:
        for cell in row:cell.fill=PatternFill('solid',fgColor=navy)
    ws.row_dimensions[1].height=25;ws.row_dimensions[2].height=18
    meta=(('Miesiąc rozliczeniowy' if language=='pl' else 'Payroll month',period),
          ('Stanowisko' if language=='pl' else 'Position',position or '—'),
          ('Data raportu' if language=='pl' else 'Report date',date.today().isoformat()))
    for idx,(label,value) in enumerate(meta,start=3):
        ws.cell(idx,1,label);ws.cell(idx,2,value)
        ws.cell(idx,1).font=Font(name='Aptos',bold=True,color=mid)
    r=7
    for header,rows in sections:
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=3)
        for col in range(1,4):
            c=ws.cell(r,col);c.fill=PatternFill('solid',fgColor=mid)
        c=ws.cell(r,1);c.value=header;c.font=Font(name='Aptos',size=11,bold=True,color=gold);c.alignment=Alignment(indent=1)
        ws.row_dimensions[r].height=25
        r+=1
        for idx,(title,value,unit) in enumerate(rows):
            summary=title.upper()==title and len(title)>6
            ws.cell(r,1,title)
            cell=ws.cell(r,2,float(value));cell.number_format='#,##0.00;[Red]-#,##0.00;–'
            ws.cell(r,3,unit)
            for col in range(1,4):
                c=ws.cell(r,col)
                c.font=Font(name='Aptos',size=10,bold=summary,color=(mid if summary else '243B4D'))
                c.fill=PatternFill('solid',fgColor=('DCE8F2' if summary else 'FFFFFF' if idx%2 else light))
                c.alignment=Alignment(vertical='center',horizontal='right' if col==2 else 'left',indent=1 if col==1 else 0)
            ws.row_dimensions[r].height=21
            r+=1
        r+=1
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=3)
    foot=ws.cell(r,1,'SZACUNEK — nie jest oficjalnym paskiem płacowym. Nie obejmuje niepotwierdzonych korekt ani terminów wypłat.' if language=='pl' else 'ESTIMATE — not an official payslip. Actual payout dates and adjustments may differ.')
    foot.font=Font(name='Aptos',size=9,italic=True,color=muted)
    foot.alignment=Alignment(wrap_text=True);ws.row_dimensions[r].height=30
    ws.freeze_panes='A7'
    ws.print_options.horizontalCentered=True
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.orientation='portrait';ws.page_setup.paperSize=ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
    ws.print_area=f'A1:C{r}'
    wb.save(path)
    return str(path)


def export_month_report(app, fmt):
    """Save a complete monthly forecast to the selected destination."""
    from kalkulator_wynagrodzenia import calc, payroll_breakdown
    assert fmt in ('xlsx','pdf')
    period=app.month.get();rows=app.current()
    language=app.language
    output=filedialog.asksaveasfilename(
        parent=app.root,title=('Eksport rozliczenia' if language=='pl' else 'Export payroll report'),
        defaultextension='.'+fmt,initialfile=f'Rozliczenie_{period}.{fmt}',
        filetypes=[('Excel (.xlsx)','*.xlsx')] if fmt=='xlsx' else [('PDF (.pdf)','*.pdf')])
    if not output:return
    if not output.lower().endswith('.'+fmt):
        messagebox.showerror('Eksport','Nieprawidłowe rozszerzenie. Oczekiwano .'+fmt,parent=app.root)
        return
    try:
        cfg=app.cfg_for_month(period)
        leave=app.leave_report(rows) if any(r.get('leave_code') or r.get('work_type')==6 for r in rows) else {}
        cfg['_leave_variable_pay']=leave.get('variable_amount',0.0) if leave.get('complete') else 0.0
        result=calc(rows,cfg);deductions=payroll_breakdown(rows,cfg,result)
        position=app.db.get('position','')
        sections=payroll_sections(period,rows,cfg,result,deductions,position,language)
        if fmt=='xlsx':
            export_month_excel(output,period,sections,position,language)
        else:
            from forecast_pdf import export_month_pdf
            export_month_pdf(output,period,rows,cfg,result,deductions,leave_report=leave,
                             language=language,detailed_sections=sections,position=position)
    except Exception as exc:
        messagebox.showerror('Eksport',str(exc),parent=app.root)
        return
    messagebox.showinfo('Eksport','Zapisano raport: '+output if language=='pl' else 'Saved report: '+output,parent=app.root)


def export_month_report_dialog(app):
    """Pick Excel or PDF explicitly, then open the correct native save dialog."""
    import tkinter as tk
    from ui_assets import schedule_navy_titlebar
    chooser=tk.Toplevel(app.root)
    schedule_navy_titlebar(chooser,background='#081725',foreground="#ffffff")
    chooser.title('Eksport rozliczenia' if app.language=='pl' else 'Export payroll report')
    chooser.configure(bg='#10293c');chooser.geometry('430x185')
    chooser.resizable(False,False);chooser.transient(app.root)
    tk.Label(chooser,text='Wybierz format raportu:' if app.language=='pl' else 'Choose report format:',
             font=('Segoe UI',13,'bold'),bg='#10293c',fg='#E6B764').pack(padx=20,pady=(21,14))
    line=tk.Frame(chooser,bg='#10293c');line.pack(padx=18,pady=5)
    def choose(fmt):
        chooser.destroy()
        export_month_report(app,fmt)
    for fmt,label in (('xlsx','Excel (XLSX)'),('pdf','PDF')):
        tk.Button(line,text=label,command=lambda fmt=fmt:choose(fmt),bg='#193a51',fg='white',
                  relief='flat',bd=0,padx=19,pady=9,font=('Segoe UI',11,'bold')).pack(side='left',padx=8)
    tk.Button(chooser,text='Anuluj' if app.language=='pl' else 'Cancel',command=chooser.destroy,
              bg='#193a51',fg='white',relief='flat',padx=15).pack(pady=(11,0))
    chooser.grab_set()
