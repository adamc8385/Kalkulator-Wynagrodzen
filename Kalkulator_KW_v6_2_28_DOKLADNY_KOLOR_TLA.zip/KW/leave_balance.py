"""Informational leave-day ledger based on work-card type 6 (no payroll edits).

The oldest available leave is spent first. The report is explicitly an
estimate: work cards do not prove the legal entitlement, approved absence,
contract dates, or the employer's official leave balance.
"""
from __future__ import annotations

import datetime as dt
import math
from collections import defaultdict
from company_calendar import day_category
from work_card_policy import MIN_CARD_YEAR

DEFAULT_ANNUAL_DAYS = 26.0


def _number(value, name, maximum=366.0):
    try:
        number = float(str(value).strip().replace(',', '.'))
    except (ValueError, TypeError):
        raise ValueError(f'Nieprawidłowa wartość: {name}') from None
    if not math.isfinite(number) or not 0 <= number <= maximum:
        raise ValueError(f'{name}: wpisz liczbę od 0 do {maximum:g}.')
    return number


def normalize_settings(raw, earliest_year):
    """Return validated settings, leaving the stored input untouched."""
    settings = raw if isinstance(raw, dict) else {}
    start = settings.get('start_year', earliest_year)
    try:
        if isinstance(start, bool) or int(start) != float(start):
            raise ValueError
        start = int(start)
    except (ValueError, TypeError, OverflowError):
        raise ValueError('Nieprawidłowy rok rozpoczęcia ewidencji.') from None
    if not MIN_CARD_YEAR <= start <= 2100:
        raise ValueError('Ewidencja urlopu może rozpoczynać się od 2024 roku.')
    annual = _number(settings.get('annual_days', DEFAULT_ANNUAL_DAYS), 'Roczny wymiar urlopu')
    opening = _number(settings.get('opening_carry_days', 0), 'Urlop zaległy na początek', maximum=2000)
    overrides = settings.get('yearly_days') or {}
    if not isinstance(overrides, dict):
        raise ValueError('Nieprawidłowe korekty roczne urlopu.')
    years = {}
    for year, days in overrides.items():
        if not str(year).isdigit() or not MIN_CARD_YEAR <= int(year) <= 2100:
            raise ValueError('Nieprawidłowy rok w korektach urlopu.')
        years[str(int(year))] = _number(days, f'Wymiar urlopu {year}')
    return {'start_year': start, 'annual_days': annual,
            'opening_carry_days': opening, 'yearly_days': years}


def _use_hours_by_day(rows, excluded=()):
    """Sum within a card, never sum overlapping copies of the same day."""
    excluded = set(excluded or ())
    per_day = defaultdict(lambda: defaultdict(float))
    coded_days = set()
    for row in rows:
        if row.get('file_id') in excluded:
            continue
        if row.get('work_type') != 6:
            continue
        try:
            date = dt.date.fromisoformat(str(row.get('date', '')))
        except (ValueError, TypeError):
            continue
        if date.year < MIN_CARD_YEAR:
            continue
        source = row.get('file_id') or row.get('source_path') or row.get('file') or 'unknown'
        try:
            hours = float(row.get('N', 0) or 0)
        except (ValueError, TypeError):
            hours = 0
        if not math.isfinite(hours):
            continue
        coded_days.add(date)
        per_day[date][source] += max(0.0, hours)
    use = {}
    skipped = []
    for date in sorted(coded_days):
        values = per_day[date]
        explicit = max(values.values(), default=0.0)
        if explicit > 0:
            hours = min(explicit, 8.0)
        elif day_category(date) == 'workday':
            # The existing importer represents blank hours as 0. For a full
            # type-6 workday, use the 8-hour statutory equivalent.
            hours = 8.0
        else:
            hours = 0.0
            skipped.append(date.isoformat())
        if hours:
            use[date] = hours
    return use, skipped


def balance_by_year(rows, settings=None, *, target_year=None, as_of=None,
                    excluded_files=()):
    """Return a read-only annual leave ledger with carry-over between years.

    ``as_of`` bounds recorded usage, even if a target future year was selected.
    Balances carry over; nothing is silently forfeited on 30 September.
    """
    today = dt.date.today()
    if as_of is None:
        as_of = today
    if isinstance(as_of, str):
        as_of = dt.date.fromisoformat(as_of)
    if not isinstance(as_of, dt.date):
        raise TypeError('as_of must be a date')
    as_of = min(as_of, today)
    if target_year is None:
        target_year = as_of.year
    target_year = int(target_year)
    excluded = set(excluded_files or ())
    active_rows = [r for r in rows if r.get('file_id') not in excluded]
    years = []
    for row in active_rows:
        try:
            year = dt.date.fromisoformat(str(row.get('date', ''))).year
            if year >= MIN_CARD_YEAR:
                years.append(year)
        except (ValueError, TypeError):
            pass
    first_year = min(years) if years else max(MIN_CARD_YEAR, min(as_of.year, target_year))
    setting = normalize_settings(settings, first_year)
    start_year = setting['start_year']
    if target_year < start_year:
        return {'status': 'before_start', 'start_year': start_year, 'settings': setting,
                'years': [], 'current': None, 'skipped': []}
    if target_year > 2100:
        raise ValueError('Rok spoza obsługiwanego zakresu')
    usage, skipped = _use_hours_by_day(active_rows)
    by_year = defaultdict(float)
    for date, hours in usage.items():
        if date.year >= start_year and date <= as_of:
            by_year[date.year] += hours
    buckets = {start_year - 1: setting['opening_carry_days'] * 8}
    annual_reports = []
    for year in range(start_year, target_year + 1):
        carried = sum(v for origin, v in buckets.items() if origin < year)
        entitlement = setting['yearly_days'].get(str(year), setting['annual_days']) * 8
        buckets[year] = entitlement
        used = by_year.get(year, 0.0)
        outstanding = used
        used_old = 0.0
        for origin in sorted(buckets):
            if outstanding <= 0:
                break
            quantity = min(buckets[origin], outstanding)
            if origin < year:
                used_old += quantity
            buckets[origin] -= quantity
            outstanding -= quantity
        remaining = sum(buckets.values())
        annual_reports.append({
            'year': year, 'entitlement_days': round(entitlement / 8, 3),
            'carry_in_days': round(carried / 8, 3),
            'used_days': round(used / 8, 3),
            'used_carry_days': round(used_old / 8, 3),
            'remaining_days': round(remaining / 8, 3),
            'current_year_left_days': round(buckets[year] / 8, 3),
            'overused_days': round(outstanding / 8, 3),
            'future_projection': year > as_of.year,
        })
    return {'status': 'ok', 'start_year': start_year, 'settings': setting,
            'years': annual_reports, 'current': annual_reports[-1],
            'as_of': as_of.isoformat(), 'skipped': [d for d in skipped if d <= as_of.isoformat()],
            'active_card_years': sorted(set(years))}
