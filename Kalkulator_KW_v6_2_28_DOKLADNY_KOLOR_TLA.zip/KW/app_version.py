"""Single application-version source for the visible Windows caption."""
VERSION = "6.2.28"
LABEL = "v" + VERSION
