"""v6.2.27: focused A1 and release-UI contract regressions."""
import datetime as dt
import unittest

from a1_audit import a1_audit
from monthly_summary import visible_monthly_summary
from app_version import LABEL


def row(day, country='', work_type=None, n=0, t=0, job='', index=None):
    return dict(date=day, country=country,work_type=work_type,
                N=n, A=0, B=0, PN=0, P=0, T=t, job=job,
                row=(index or int(day[-2:])+10),file='Chrapkowski KP29.xlsx',file_id='test')


class TestJulyWeekendReturnPoland(unittest.TestCase):
    def test_real_screenshot_july_2026(self):
        cards=[row('2026-07-16','Włochy',1,n=12),
               row('2026-07-17','Polska',5,n=8,job='Dzień Wolny'),
               row('2026-07-18',index=29),row('2026-07-19',index=32),
               row('2026-07-20','Włochy',1,n=8)]
        result=a1_audit(cards,dt.date(2026,7,16),dt.date(2026,7,20))
        self.assertEqual(result['inferred'][dt.date(2026,7,18)],'Polska')
        self.assertEqual(result['inferred'][dt.date(2026,7,19)],'Polska')
        self.assertEqual(result['unresolved'],0)
        self.assertFalse(result['details'])
        self.assertEqual(result['poland'],3)
        self.assertEqual(result['foreign'],2)
        self.assertEqual(result['total'],5)

    def test_blank_weekend_after_poland_not_flagged(self):
        cards=[row('2026-07-17','Polska',5,n=8),row('2026-07-18'),row('2026-07-19')]
        result=a1_audit(cards,dt.date(2026,7,17),dt.date(2026,7,19))
        self.assertEqual(result['poland'],3)
        self.assertEqual(result['unresolved'],0)

    def test_weekend_with_work_country_missing_must_warn(self):
        cards=[row('2026-07-17','Polska',5,n=8),row('2026-07-18',work_type=1,n=8),row('2026-07-19')]
        result=a1_audit(cards,dt.date(2026,7,17),dt.date(2026,7,19))
        self.assertGreaterEqual(result['unresolved'],1)
        self.assertNotIn(dt.date(2026,7,18),result['inferred'])

    def test_weekend_with_travel_not_domestic(self):
        cards=[row('2026-07-17','Polska',5,n=8),row('2026-07-18',work_type=11,t=6),row('2026-07-19')]
        result=a1_audit(cards,dt.date(2026,7,17),dt.date(2026,7,19))
        self.assertNotIn(dt.date(2026,7,18),result['inferred'])
        self.assertGreaterEqual(result['unresolved'],1)

    def test_explicit_foreign_on_saturday_remains_foreign(self):
        cards=[row('2026-07-17','Polska',5,n=8),row('2026-07-18','Włochy',1,n=8),row('2026-07-19')]
        result=a1_audit(cards,dt.date(2026,7,17),dt.date(2026,7,19))
        self.assertGreaterEqual(result['foreign'],1)
        self.assertNotEqual(result['inferred'].get(dt.date(2026,7,18)),'Polska')

    def test_no_false_domestic_assumption_from_friday_foreign(self):
        cards=[row('2026-07-17','Włochy',1,n=8),row('2026-07-18'),row('2026-07-19')]
        result=a1_audit(cards,dt.date(2026,7,17),dt.date(2026,7,19))
        self.assertNotEqual(result['inferred'].get(dt.date(2026,7,18)),'Polska')

class TestSummaryAndRelease(unittest.TestCase):
    def test_only_paid_travel_in_dashboard(self):
        entries=dict(visible_monthly_summary(dict(N=160,A=74,B=50),12,8,4,0,0,{},296))
        self.assertEqual(entries['Czas podróży po odliczeniu'],'4 h')
        self.assertNotIn('Czas podróży przed odliczeniem',entries)
        self.assertNotIn('Czas podróży odliczony',entries)
        self.assertEqual(entries['Łączna liczba godzin'],'296 h')

    def test_version_single_source(self):
        self.assertEqual(LABEL, 'v6.2.28')

if __name__=='__main__':unittest.main()
