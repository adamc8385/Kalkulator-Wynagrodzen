"""Modeless simulator GUI: controls stay accessible as details grow."""
import tkinter as tk
import unittest
from forecast_ui import open_overtime_simulator
from kalkulator_wynagrodzenia import DEFAULT

class _Month:
    def get(self): return '2026-10'

class _App:
    def __init__(self, root):
        self.root=root
        self.language='pl'
        self.month=_Month()
        self.db=dict(DEFAULT)
    def cfg_for_month(self,*args):
        return dict(self.db,salary=15588.78,offshore=230.,nominal=176.,
                    social_ytd=273070.51,ytd_tax_base=243837.,_tax_year=2026)

def _all_children(win):
    for child in win.winfo_children():
        yield child
        yield from _all_children(child)

class SimulatorGui6218(unittest.TestCase):
    def test_simulator_scrollable_data_fixed_footer_modeless(self):
        root=tk.Tk()
        root.geometry('1150x850+0+0')
        try:
            win=open_overtime_simulator(_App(root))
            root.update()
            children=list(_all_children(win))
            buttons=[w for w in children if isinstance(w,tk.Button)]
            fields=[w for w in children if isinstance(w,tk.Entry)]
            canvases=[w for w in children if isinstance(w,tk.Canvas)]
            sb=[w for w in children if isinstance(w,tk.ttk.Scrollbar)]
            self.assertEqual(len(fields),9)
            self.assertEqual(len(canvases),1)
            self.assertEqual(len(sb),1)
            self.assertFalse(win.transient())
            self.assertTrue(all(win.resizable()))
            self.assertIsNone(win.grab_current())
            for field,val in zip(fields,('39,5','10','24,5','3','8','2','3')):
                field.delete(0,'end');field.insert(0,val)
            calculate=next(b for b in buttons if b.cget('text')=='Przelicz')
            close=next(b for b in buttons if b.cget('text')=='Zamknij')
            calculate.invoke()
            for _ in range(3):root.update()
            results=[w.cget('text') for w in children if isinstance(w,tk.Label)]
            self.assertTrue(any('Prognoza przelewu:' in v for v in results))
            self.assertTrue(any('Dodatek offshore' in v for v in results))
            for size in ('850x760+45+40','620x445+45+40'):
                win.geometry(size)
                for _ in range(3):root.update()
                self.assertTrue(calculate.winfo_ismapped())
                self.assertTrue(close.winfo_ismapped())
                self.assertLessEqual(close.winfo_rooty()+close.winfo_height(),
                                     win.winfo_rooty()+win.winfo_height()+1)
                self.assertLessEqual(calculate.winfo_rooty()+calculate.winfo_height(),
                                     win.winfo_rooty()+win.winfo_height()+1)
            self.assertTrue(sb[0].winfo_ismapped())
            canvases[0].yview_moveto(1.0)
            root.update()
            self.assertGreater(canvases[0].yview()[0],0.25)
            self.assertTrue(close.winfo_ismapped())
            win.destroy()
        finally:
            root.destroy()

if __name__=='__main__':unittest.main()
