"""v6.2.26: manual EU C/ZFSS monthly receipts, PIT exemption and ZUS separation."""
import copy
import tempfile
import unittest
from pathlib import Path
from special_payments import get_month, save_month, zfss_prior, zfss_tax_split, amount
from data_store import save_atomic, load_verified
from kalkulator_wynagrodzenia import calc, payroll_breakdown
from forecast_tools import hypothetical_month_result, yearly_projection
from tax_progress import opening_balances


def cfg(**extra):
    standard=dict(salary=10000.,nominal=160.,offshore=0.,travel_rate=.5,costs=250.,
          pit_relief=0.,social_limit=282600.,social_ytd=0.,ytd_tax_base=0.,
          _tax_year=2026,ppk=0.,ppe_extra=0.,other_deductions=0.,
          ppe_auto_enabled=0.,ppo_auto_enabled=0.,
          eu_c_allowance=0.,zfss_cash=0.,_zfss_prior_year=0.)
    standard.update(extra)
    return standard


class SpecialMonthlyTest(unittest.TestCase):
    def test_month_specific_not_inherited_and_no_data_loss(self):
        db={'rows':[{'date':'2026-11-05','N':8.}], 'monthly_settings_history':{'2026-11':{'salary':10000.}}}
        save_month(db,'2026-11',{'eu_c_allowance':1234.567,'zfss_cash':1500})
        self.assertEqual(get_month(db,'2026-11'),{'eu_c_allowance':1234.57,'zfss_cash':1500.})
        self.assertEqual(get_month(db,'2026-12'),{'eu_c_allowance':0,'zfss_cash':0})
        self.assertEqual(get_month(db,'2027-11'),{'eu_c_allowance':0,'zfss_cash':0})
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'dane.json'
            save_atomic(file,db)
            recovered,_=load_verified(file)
            self.assertEqual(get_month(recovered,'2026-11')['eu_c_allowance'],1234.57)
            self.assertEqual(recovered['rows'],db['rows'])
            self.assertEqual(recovered['monthly_settings_history'],db['monthly_settings_history'])
        save_month(db,'2026-11',{'eu_c_allowance':0,'zfss_cash':0})
        self.assertEqual(db['monthly_special_payments'],{})

    def test_annual_zfss_pit_exemption_splits(self):
        db={}
        save_month(db,'2026-01',{'eu_c_allowance':0,'zfss_cash':800})
        save_month(db,'2026-03',{'eu_c_allowance':0,'zfss_cash':500})
        self.assertEqual(zfss_prior(db,'2026-02'),800.)
        self.assertEqual(zfss_prior(db,'2026-03'),800.)
        self.assertEqual(zfss_tax_split(500,zfss_prior(db,'2026-03')),(200.,300.))
        self.assertEqual(zfss_prior(db,'2026-12'),1300.)
        self.assertEqual(zfss_prior(db,'2027-01'),0.)
        self.assertEqual(zfss_tax_split(2000,0),(1000.,1000.))
        self.assertEqual(zfss_tax_split(200,1300),(0.,200.))

    def test_invalid_values_rejected(self):
        db={}
        for invalid in ('NaN','inf','-1','1e100','abc',''):
            with self.subTest(value=invalid):
                with self.assertRaises(ValueError):save_month(db,'2026-11',{'eu_c_allowance':invalid,'zfss_cash':0})
        self.assertFalse(db.get('monthly_special_payments'))
        self.assertRaises(ValueError,lambda:get_month(db,'2026-13'))

    def test_zfss_exempt_no_social_health_ppk_or_tax(self):
        plain=calc([],cfg(ppk=2.,ppe_auto_enabled=1,ppo_auto_enabled=1))
        paid=calc([],cfg(zfss_cash=800.,ppk=2.,ppe_auto_enabled=1,ppo_auto_enabled=1))
        self.assertEqual(paid[4]-plain[4],800.)
        self.assertEqual(paid[5:10],plain[5:10])
        self.assertEqual(paid[10]-plain[10],800.)
        broke=payroll_breakdown([],cfg(zfss_cash=800.,ppk=2.,ppe_auto_enabled=1,ppo_auto_enabled=1),paid)
        basic=payroll_breakdown([],cfg(ppk=2.,ppe_auto_enabled=1,ppo_auto_enabled=1),plain)
        self.assertEqual(broke['social_base'],basic['social_base'])
        self.assertEqual(broke['employer_ppe'],basic['employer_ppe'])
        self.assertEqual(broke['employer_ppo'],basic['employer_ppo'])
        self.assertEqual((broke['zfss_exempt'],broke['zfss_taxable']),(800.,0.))

    def test_zfss_above_limit_adds_pit_not_contributions(self):
        orig=calc([],cfg())
        paid=calc([],cfg(zfss_cash=500.,_zfss_prior_year=800.))
        self.assertEqual(paid[5:7],orig[5:7])
        self.assertEqual(paid[7]-orig[7],300)
        self.assertEqual(paid[8]-orig[8],36)
        self.assertEqual(paid[10]-orig[10],464)

    def test_eu_c_ordinary_gross_tax_and_social(self):
        original=calc([],cfg())
        raised=calc([],cfg(eu_c_allowance=900.))
        self.assertEqual(raised[4]-original[4],900.)
        self.assertGreater(raised[5],original[5])
        self.assertGreater(raised[6],original[6])
        self.assertGreater(raised[7],original[7])
        self.assertGreater(raised[8],original[8])
        self.assertEqual(payroll_breakdown([],cfg(eu_c_allowance=900.))['social_base'],10900.)

    def test_double_threshold_second_tax_bracket(self):
        ordinary=calc([],cfg(ytd_tax_base=119500.,zfss_cash=0.))
        combined=calc([],cfg(ytd_tax_base=119500.,zfss_cash=1700.))
        self.assertEqual(combined[5:7],ordinary[5:7])
        self.assertGreater(combined[8],ordinary[8])
        self.assertEqual(combined[7]-ordinary[7],700)

    def test_sequential_ytd_does_not_add_zfss_to_zus_cap(self):
        db={'rows':[],'excluded_files':[], 'monthly_special_payments':{}}
        save_month(db,'2026-01',{'eu_c_allowance':500.,'zfss_cash':800.})
        save_month(db,'2026-02',{'eu_c_allowance':0.,'zfss_cash':500.})
        def config_month(p):
            return cfg(**get_month(db,p),_zfss_prior_year=zfss_prior(db,p))
        opening=opening_balances(db,'2026-03',config_month,calc,lambda day,db:day[:7])
        self.assertEqual(opening['social'],20500.)
        first=calc([],config_month('2026-01'))
        second=calc([],dict(config_month('2026-02'),social_ytd=10500.,ytd_tax_base=first[7]))
        self.assertEqual(opening['tax'],first[7]+second[7])
        result=yearly_projection(2026,db,lambda period,_skip_progress=False:config_month(period),calc,lambda day,db:day[:7],today=__import__('datetime').date(2026,11,1))
        self.assertEqual(result[0]['result'][4],11300.)
        self.assertEqual(result[1]['result'][4],10500.)

    def test_hypothetical_simulation_no_save_and_overrides(self):
        original=cfg(eu_c_allowance=500.,zfss_cash=700.)
        before=copy.deepcopy(original)
        scenario=hypothetical_month_result('2026-11',original,calc,0,0,0,eu_c_allowance=200,zfss_cash=1250)
        self.assertEqual(original,before)
        self.assertEqual(scenario['cfg']['eu_c_allowance'],200.)
        self.assertEqual(scenario['cfg']['zfss_cash'],1250.)
        self.assertEqual(scenario['result'][4],11450.)

if __name__=='__main__':unittest.main()
