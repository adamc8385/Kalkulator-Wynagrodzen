"""Retain native system controls and schedule styling after window creation."""
import unittest
from unittest.mock import patch
import ui_assets

class Dummy:
    def __init__(self):self.ran=[]
    def after(self,delay,fn):self.ran.append((delay,fn))
    def winfo_exists(self):return True

class NativeCaptionTests(unittest.TestCase):
    def test_non_windows_does_not_modify(self):
        d=Dummy()
        with patch.object(ui_assets.sys,'platform','linux'):
            ui_assets.schedule_navy_titlebar(d)
        self.assertEqual(d.ran,[])

    def test_windows_schedules_native_caption_only(self):
        d=Dummy()
        with patch.object(ui_assets.sys,'platform','win32'),patch.object(ui_assets,'set_navy_titlebar') as setter:
            ui_assets.schedule_navy_titlebar(d,background='#10293c',foreground='#ffffff')
            self.assertEqual(len(d.ran),1)
            self.assertEqual(d.ran[0][0],65)
            d.ran[0][1]()
            setter.assert_called_once_with(d,background='#10293c',foreground='#ffffff')

if __name__=='__main__':unittest.main()
