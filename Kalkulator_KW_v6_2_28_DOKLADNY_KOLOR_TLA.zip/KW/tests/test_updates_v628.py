"""Regression tests for dashboard, A1 and current-year card checking."""
import datetime as dt
import unittest
from a1_audit import a1_audit
from forecast_tools import validate_cards, yearly_projection
from pathlib import Path


def row(date, country='Polska', file_id='f'):
    return {'date':date,'country':country,'file_id':file_id,'file':'KP.xlsx',
            'row':12,'N':8,'A':0,'B':0,'PN':0,'P':0,'T':0,'work_type':5,
            'job':'Dzień wolny', 'sea_work_raw':'NIE'}


class Updates628(unittest.TestCase):
    def test_2026_only_even_with_2024_and_2027_imported(self):
        records=[row('2024-10-19',file_id='old'),row('2026-07-17',file_id='now'),row('2027-02-01',file_id='future')]
        db={'rows':records,'excluded_files':[]}
        a=validate_cards(db,lambda *_:'2026-07',year=2026)
        self.assertEqual(a['active_rows'],1)
        self.assertEqual(a['year'],2026)
        self.assertTrue(all(i['date'].startswith('2026') for i in a['issues']))
        b=validate_cards(db,lambda *_:'2027-02',year=2027)
        self.assertEqual(b['active_rows'],1)
        self.assertEqual(b['year'],2027)
        self.assertTrue(all(i['date'].startswith('2027') for i in b['issues']))
        self.assertEqual(len(db['rows']),3)

    def test_polish_weekend_after_friday_day_off(self):
        records=[row('2026-07-17','Polska')]
        audit=a1_audit(records,dt.date(2026,7,17),dt.date(2026,7,19))
        self.assertEqual(audit['inferred'][dt.date(2026,7,18)],'Polska')
        self.assertEqual(audit['inferred'][dt.date(2026,7,19)],'Polska')
        self.assertEqual(audit['poland'],3)
        self.assertEqual(audit['unresolved'],0)

    def test_explicit_foreign_destination_must_not_be_overwritten(self):
        records=[row('2026-07-17','Polska'),row('2026-07-19','Włochy')]
        audit=a1_audit(records,dt.date(2026,7,17),dt.date(2026,7,19))
        self.assertEqual(audit['foreign'],1)
        self.assertEqual(audit['unresolved'],1)

    def test_2027_auto_switch_by_clock(self):
        from unittest.mock import patch
        class FakeDate(dt.date):
            @classmethod
            def today(cls):return cls(2027,1,1)
        with patch('forecast_tools.dt.date',FakeDate):
            audit=validate_cards({'rows':[row('2026-12-31'),row('2027-01-01')]},lambda *_:'2026-12')
        self.assertEqual(audit['year'],2027)
        self.assertEqual(audit['active_rows'],1)

if __name__=='__main__':unittest.main()
