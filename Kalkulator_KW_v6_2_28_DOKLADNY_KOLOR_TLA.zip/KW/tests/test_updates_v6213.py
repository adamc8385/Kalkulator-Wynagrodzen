"""v6.2.13 — travel 06–20 and settings header regression."""
import datetime as dt
import hashlib
import tempfile
import unittest
from pathlib import Path

from kalkulator_wynagrodzenia import travel_breakdown, travel_bonus, DEFAULT
from card_sync import sync_cards, canonical, stable_id


def entry(day, start=None, end=None, travel=0, n=0, *, typ=2):
    item = {'date':day,'N':float(n),'A':0.,'B':0.,'PN':0.,'P':float(travel),'T':0.,
            'work_type':typ,'work_type_raw':str(typ),'sea_work_raw':'NIE'}
    if start is not None:
        item.update(work_clock_source='literal',work_start_raw=start,work_end_raw=end)
    return item


class Travel6213(unittest.TestCase):
    def assert_trip(self, rows, before, deducted, paid):
        values=list(travel_breakdown(rows).values())
        self.assertAlmostEqual(sum(v[0] for v in values),before)
        self.assertAlmostEqual(sum(v[1] for v in values),deducted)
        self.assertAlmostEqual(sum(v[2] for v in values),paid)

    def test_actual_october_2026_training_trip(self):
        rows = [entry('2026-10-28','05:00','10:00',5),
                entry('2026-10-28','10:00','16:00',n=6,typ=8),
                entry('2026-10-30','08:00','16:00',n=8,typ=8),
                entry('2026-10-30','16:00','21:00',5)]
        self.assert_trip(rows,10,8,2)
        self.assertEqual(travel_breakdown(rows)['2026-10-28'],(5.,4.,1.))
        self.assertEqual(travel_breakdown(rows)['2026-10-30'],(5.,4.,1.))
        cfg=dict(DEFAULT,salary=15588.78,nominal=176)
        self.assertEqual(travel_bonus(rows,cfg),88.58)

    def test_10_hours_inside_window_gives_2(self):
        self.assert_trip([entry('2026-10-27','07:00','17:00',10)],10,8,2)

    def test_full_05_to_21_gives_8(self):
        self.assert_trip([entry('2026-10-30','05:00','21:00',16)],16,8,8)

    def test_two_journeys_same_day_share_eight_hour_limit(self):
        r=[entry('2026-10-28','06:00','11:00',5),entry('2026-10-28','14:00','19:00',5)]
        self.assert_trip(r,10,8,2)

    def test_work_and_training_not_subtracted(self):
        r=[entry('2026-10-28','06:00','11:00',5),entry('2026-10-28','11:00','19:00',n=8,typ=8)]
        self.assert_trip(r,5,5,0)

    def test_weekend_is_100_percent_eligible(self):
        r=[entry('2026-10-31','08:00','18:00',10),entry('2026-11-01','12:00','17:00',5)]
        self.assert_trip(r,15,0,15)

    def test_company_free_friday_all_eligible(self):
        # WPL 2026: Good Friday, company-granted day off.
        self.assert_trip([entry('2026-04-03','08:00','18:00',10)],10,0,10)

    def test_overnight_sunday_to_monday_keeps_06_20_cap_per_day(self):
        self.assert_trip([entry('2026-11-01','23:00','07:00',8)],8,1,7)

    def test_non_travel_days_remain_present_for_daily_summary(self):
        rows=[entry('2026-10-28','08:00','16:00',n=8,typ=1),
              entry('2026-10-29','08:00','16:00',n=8,typ=1)]
        self.assertEqual(travel_breakdown(rows),{
            '2026-10-28':(0.,0.,0.),'2026-10-29':(0.,0.,0.)})

    def test_unknown_clocks_do_not_invent_paid_night_time(self):
        self.assert_trip([entry('2026-10-28',travel=5)],5,5,0)
        self.assert_trip([entry('2026-10-28',travel=10)],10,8,2)

    def test_bad_mismatching_clock_does_not_override_booked_hours(self):
        self.assert_trip([entry('2026-10-28','21:00','22:00',5)],5,5,0)

    def test_missing_travel_clocks_sync_refresh_only_once(self):
        with tempfile.TemporaryDirectory() as d:
            file = Path(d) / 'KP01.xlsx'
            file.write_bytes(b'unchanged workbook')
            key=canonical(file)
            digest=hashlib.sha256(file.read_bytes()).hexdigest()
            original=dict(entry('2026-10-28',travel=5),file_id=stable_id(file),
                          file=file.name,source_path=key)
            db={'rows':[original], 'source_index':{key:{'sha256':digest,'file_id':stable_id(file)}}}
            called=[]
            def read(_):
                called.append(True)
                return [entry('2026-10-28','05:00','10:00',5)]
            first=sync_cards(db,[file],read)
            self.assertTrue(first['dirty'])
            self.assertEqual(len(called),1)
            self.assertEqual(db['rows'][0]['work_clock_source'],'literal')
            self.assertEqual(travel_breakdown(db['rows'])['2026-10-28'],(5,4,1))
            second=sync_cards(db,[file],read)
            self.assertFalse(second['dirty'])
            self.assertEqual(len(called),1)

    def test_settings_header_uses_separate_grid_rows(self):
        source=(Path(__file__).resolve().parents[1]/'kalkulator_wynagrodzenia.py').read_text('utf-8')
        start=source.index(' def show_settings(self):')
        end=source.index('  self.vars={}',start)
        section=source[start:end]
        self.assertIn("info.grid(row=2,column=0,columnspan=3",section)
        self.assertIn("status.grid(row=3,column=0,columnspan=3",section)
        self.assertNotIn("status.grid(row=2,column=0,columnspan=3",section)

if __name__ == '__main__':
    unittest.main()
