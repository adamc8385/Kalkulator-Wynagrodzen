"""Regression coverage of employer calendars and inferred A1 residence, v6.2.6."""
import datetime as dt
import unittest
from a1_audit import a1_audit
from company_calendar import day_category, scheduled_hours, has_confirmed_company_schedule
from kalkulator_wynagrodzenia import default_calendar, calendar_for, accounting_month


def card(day,country='',kind=None,travel=0,normal=0,row=14):
    return {'date':day,'country':country,'work_type':kind,'P':float(travel),
            'N':float(normal),'T':0.,'A':0.,'B':0.,'PN':0.,
            'row':row,'file':f'{day}.xlsx','file_id':day+'-'+str(row)}

class TestCompanyCalendar(unittest.TestCase):
    def test_worked_week_schedule_from_supplied_documents(self):
        ranges24=[(1,4),(5,8),(9,13),(14,17),(18,21),(22,26),(27,30),
                  (31,35),(36,39),(40,43),(44,48),(49,52)]
        ranges25=[(1,4),(5,9),(10,13),(14,17),(18,22),(23,26),(27,30),
                  (31,35),(36,39),(40,43),(44,48),(49,52)]
        for year, ranges in ((2024,ranges24),(2025,ranges25)):
            cfg=default_calendar(year)
            self.assertEqual([cfg[str(i)] for i in range(1,13)],
                             [list(range(a,b+1)) for a,b in ranges])
            self.assertEqual(sorted(sum(cfg.values(),[])),list(range(1,53)))
        self.assertEqual(default_calendar(2026)['12'],list(range(49,54)))

    def test_overrides_are_not_overwritten(self):
        custom={'1':[1,2]}
        self.assertEqual(calendar_for({'calendars':{'2024':custom}},2024),custom)
        self.assertEqual(calendar_for({'calendars':{}},2025)['2'],list(range(5,10)))

    def test_isoweek_across_new_year(self):
        self.assertEqual(accounting_month('2024-12-30',{}),'2025-01')
        self.assertEqual(accounting_month('2025-12-31',{}),'2026-01')
        self.assertEqual(accounting_month('2024-12-29',{}),'2024-12')

    def test_off_days_2024_2025_and_2026_unchanged(self):
        for day in ('2024-03-29','2024-12-24','2025-04-18','2025-05-02','2025-11-10','2026-04-03','2026-12-31'):
            self.assertEqual(day_category(dt.date.fromisoformat(day)),'company',day)
        self.assertEqual(day_category(dt.date(2025,12,24)),'holiday')
        self.assertEqual(day_category(dt.date(2024,12,23)),'workday')
        for year in (2024,2025,2026):
            self.assertTrue(has_confirmed_company_schedule(year))
            self.assertGreater(sum(scheduled_hours(year,m) for m in range(1,13)),1800)

class TestA1Continuity(unittest.TestCase):
    def test_weekend_during_foreign_assignment(self):
        rows=[card('2026-10-09','Włochy',1,normal=8),card('2026-10-12','Włochy',1,normal=8)]
        report=a1_audit(rows,dt.date(2026,10,9),dt.date(2026,10,12))
        self.assertEqual(report['foreign'],4)
        self.assertEqual(report['poland'],0)
        self.assertEqual(report['inferred'][dt.date(2026,10,10)],'Włochy')
        self.assertEqual(report['inferred'][dt.date(2026,10,11)],'Włochy')
        self.assertEqual(report['unresolved'],0)

    def test_friday_return_then_home_weekend(self):
        rows=[card('2026-10-06','Włochy',1,normal=8),
              card('2026-10-08','Włochy',1,normal=8),
              card('2026-10-09','Włochy',11,travel=7),
              card('2026-10-12','Polska',1,normal=8)]
        report=a1_audit(rows,dt.date(2026,10,6),dt.date(2026,10,12))
        self.assertEqual(report['inferred'][dt.date(2026,10,10)],'Polska')
        self.assertEqual(report['inferred'][dt.date(2026,10,11)],'Polska')
        self.assertEqual(report['foreign'],4) # Tuesday, Wednesday (inferred), Thursday, Friday
        self.assertEqual(report['poland'],3)
        self.assertEqual(report['unresolved'],0)

    def test_departure_monday_after_home_weekend(self):
        rows=[card('2026-10-09','Polska',1,normal=8),card('2026-10-12','Włochy',11,travel=6)]
        report=a1_audit(rows,dt.date(2026,10,9),dt.date(2026,10,12))
        self.assertEqual(report['poland'],3)
        self.assertEqual(report['foreign'],1)
        self.assertEqual(report['inferred'][dt.date(2026,10,11)],'Polska')

    def test_unclear_border_does_not_guess(self):
        rows=[card('2026-10-09','Włochy',1,normal=8),card('2026-10-12','Polska',1,normal=8)]
        report=a1_audit(rows,dt.date(2026,10,9),dt.date(2026,10,12))
        self.assertEqual(report['unresolved'],2)
        self.assertEqual(report['poland'],1)
        self.assertEqual(report['foreign'],1)
        self.assertTrue(all(k not in report['inferred'] for k in (dt.date(2026,10,10),dt.date(2026,10,11))))
        self.assertTrue(report['details'])

    def test_two_travel_endpoints_are_not_proof_of_residence(self):
        rows=[card('2026-10-09','Włochy',11,travel=6),card('2026-10-12','Włochy',11,travel=7)]
        report=a1_audit(rows,dt.date(2026,10,9),dt.date(2026,10,12))
        self.assertEqual(report['unresolved'],2)

    def test_empty_weekend_without_assignment_does_not_warn(self):
        report=a1_audit([card('2026-10-10','',None)],dt.date(2026,10,10),dt.date(2026,10,11))
        self.assertEqual(report['missing'],{})
        self.assertEqual(report['poland'],2)
        self.assertEqual(report['details'],[])

    def test_leave_day_without_country_is_not_error(self):
        report=a1_audit([card('2026-10-09','',6,normal=8)],dt.date(2026,10,9),dt.date(2026,10,9))
        self.assertFalse(report['missing'])
        self.assertEqual(report['poland'],1)

    def test_empty_country_with_work_must_remain_review(self):
        report=a1_audit([card('2026-10-09','',1,normal=8)],dt.date(2026,10,9),dt.date(2026,10,9))
        self.assertEqual(report['unresolved'],1)
        self.assertEqual(report['poland'],0)
        self.assertTrue(report['details'])

    def test_blank_auxiliary_row_on_named_day_is_not_missing(self):
        rows=[card('2026-10-09','Włochy',1,normal=8),card('2026-10-09','',None,row=15)]
        report=a1_audit(rows,dt.date(2026,10,9),dt.date(2026,10,9))
        self.assertFalse(report['missing'])
        self.assertFalse(report['details'])
        self.assertEqual(report['foreign'],1)

    def test_continuity_over_new_year(self):
        rows=[card('2025-12-30','Włochy',1,normal=8),card('2026-01-02','Włochy',1,normal=8)]
        report=a1_audit(rows,dt.date(2026,1,1),dt.date(2026,1,2))
        self.assertEqual(report['inferred'][dt.date(2026,1,1)],'Włochy')
        self.assertEqual(report['foreign'],2)

    def test_excluded_foreign_card_does_not_influence(self):
        rows=[card('2026-10-09','Włochy',1,normal=8),card('2026-10-12','Włochy',1,normal=8)]
        report=a1_audit(rows,dt.date(2026,10,9),dt.date(2026,10,12),excluded_ids=(rows[0]['file_id'],))
        self.assertEqual(report['foreign'],1)
        self.assertEqual(report['poland'],3)

if __name__=='__main__': unittest.main()
