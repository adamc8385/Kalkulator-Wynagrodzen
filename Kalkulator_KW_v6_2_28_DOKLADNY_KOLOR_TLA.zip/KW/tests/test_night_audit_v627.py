"""v6.2.7 — PN overlaps actual work, exact corrections and source safety."""
import copy
import datetime as dt
import tempfile
import unittest
from pathlib import Path
from xml.sax.saxutils import escape
from zipfile import ZipFile

from forecast_tools import validate_cards
from night_work import (classify_interval, expected_day_entries, interval_minutes,
                        night_bonus_detail, parse_clock)
from kalkulator_wynagrodzenia import read_xlsx, calc, nominal_for_calendar_month


def make_card(path, day, *, start='18:00', end='06:00', n=8, a=0, b=4, pn=8,
              header=True, as_serial=False):
    date_serial=(day-dt.date(1899,12,30)).days
    vals={'C':date_serial,'D':start,'E':end,'G':n,'H':a,'I':b,'J':pn,
          'N':1,'O':'NIE','P':'Polska','Q':'Test installation'}
    def cell(col, val, row=14):
        if isinstance(val,str):return f'<c r="{col}{row}" t="inlineStr"><is><t>{escape(val)}</t></is></c>'
        return f'<c r="{col}{row}"><v>{val}</v></c>'
    headings=('<row r="13">'+cell('D','Godzina rozpoczęcia pracy',13)
              +cell('E','Godzina zakończenia pracy',13)+'</row>') if header else ''
    xml=('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
         '<sheetData>'+headings+'<row r="14">'+''.join(cell(col,val) for col,val in vals.items())
         +'</row></sheetData></worksheet>')
    with ZipFile(path,'w') as z:z.writestr('xl/worksheets/sheet1.xml',xml)


def base_row(**updates):
    row={'date':'2026-11-09','file_id':'a','file':'some_card.xlsx','row':14,
         'N':8.,'A':0.,'B':4.,'PN':8.,'P':0.,'T':0.,'work_type':1,
         'work_type_raw':'1','sea_work_raw':'NIE','job':'TEST','country':'Polska',
         'work_start_raw':'18:00','work_end_raw':'06:00','work_clock_source':'literal'}
    row.update(updates)
    return row


def report(*rows):
    return validate_cards({'rows':list(rows),'excluded_files':[]},lambda *_:'2026-11')


class NightHoursTest(unittest.TestCase):
    def test_example_clock_splits(self):
        examples=[('18:00','06:00',(8,0,4,8)),('19:00','07:00',(8,1,3,8)),
                  ('20:00','08:00',(8,2,2,8)),('22:00','06:00',(8,0,0,8)),
                  ('12:00','00:00',(8,2,2,2))]
        for start,end,want in examples:
            with self.subTest(start=start,end=end):
                first,last=parse_clock(start),parse_clock(end)
                if last<first:last+=1440
                got=classify_interval(first,last)
                self.assertEqual(tuple(got[k] for k in ('N','A','B','PN')),want)

    def test_bad_n_a_b_pn_distribution_is_not_audited_as_of_v6211(self):
        row=base_row(A=4.,B=0.,PN=4.)
        original=copy.deepcopy(row)
        messages='\n'.join(i['message'] for i in report(row)['issues'])
        for label in ('Kolumna A:', 'Kolumna B:', 'Kolumna PN:',
                      'Suma N+A+B:', 'podział N/A/B/PN'):
            self.assertNotIn(label,messages)
        self.assertEqual(row,original)

    def test_correct_card_has_no_clock_errors(self):
        messages='\n'.join(i['message'] for i in report(base_row())['issues'])
        self.assertNotIn('Kolumna PN',messages)
        self.assertNotIn('Kolumna N:',messages)

    def test_zero_hours_not_reclassified_from_clock(self):
        row=base_row(N=0.,A=0.,B=0.,PN=0.)
        messages='\n'.join(i['message'] for i in report(row)['issues'])
        self.assertNotIn('Kolumna N:',messages)
        # Other independent missing-work reports are intentionally retained.

    def test_night_more_than_n_a_b_not_reported_as_split_error(self):
        row=base_row(N=4.,A=0.,B=0.,PN=8.)
        row.pop('work_start_raw');row.pop('work_end_raw');row.pop('work_clock_source')
        messages='\n'.join(i['message'] for i in report(row)['issues'])
        self.assertNotIn('PN nie może przekraczać',messages)
        self.assertNotIn('Kolumna PN:',messages)

    def test_missing_clock_does_not_generate_pn_warning(self):
        row=base_row(A=4.,B=0.)
        for key in ('work_start_raw','work_end_raw','work_clock_source'):row.pop(key)
        messages='\n'.join(i['message'] for i in report(row)['issues'])
        self.assertNotIn('nie może wyliczyć prawidłowych wartości',messages)
        self.assertNotIn('Kolumna B:',messages)
        self.assertNotIn('PN podano bez',messages)

    def test_overnight_continuity_and_multiple_segment_normal_hours(self):
        one=base_row(N=4.,A=0.,B=0.,PN=0.,work_start_raw='08:00',work_end_raw='12:00')
        two=base_row(row=15,N=4.,A=0.,B=0.,PN=0.,work_start_raw='13:00',work_end_raw='17:00')
        self.assertEqual(expected_day_entries([one,two])[id(two)]['N'],4.)

    def test_work_type_travel_clock_does_not_reclassify(self):
        row=base_row(work_type=11,P=5.,N=4.)
        self.assertNotIn(id(row),expected_day_entries([row]))

    def test_invalid_hours_cannot_crash_checker(self):
        row=base_row(A='oops')
        result=report(row)
        self.assertTrue(result['errors']>=1)

    def test_header_labelled_excel_clock_is_imported(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'card.xlsx'
            make_card(path,dt.date(2026,11,9),start=.75,end=.25)
            row=read_xlsx(path)[0]
            self.assertEqual(row['work_clock_source'],'headers')
            self.assertEqual(interval_minutes(row),(1080,1800))

    def test_literal_clock_without_header_is_detected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'card.xlsx'
            make_card(path,dt.date(2026,11,9),header=False)
            row=read_xlsx(path)[0]
            self.assertEqual(interval_minutes(row),(1080,1800))

    def test_number_without_header_is_not_guessed_as_time(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'card.xlsx'
            make_card(path,dt.date(2026,11,9),header=False,start=.75,end=.25)
            row=read_xlsx(path)[0]
            self.assertIsNone(interval_minutes(row))

    def test_night_bonus_from_minimum_and_nominal(self):
        row=base_row(date='2026-04-08',PN=8.)
        # 4806 PLN / 160 h * 20% = 6.01 PLN per night hour (rounded)
        self.assertEqual(nominal_for_calendar_month(2026,4),160)  # calendar month with firm days off
        self.assertEqual(night_bonus_detail([row])['amount'],48.08)

    def test_unknown_future_minimum_not_fabricated(self):
        self.assertEqual(night_bonus_detail([base_row(date='2027-01-04')]),
                         {'amount':0.,'unpriced_hours':8.})

    def test_no_pn_no_increment_to_gross(self):
        from kalkulator_wynagrodzenia import DEFAULT
        cfg={**DEFAULT,'salary':15588.78,'nominal':160,'social_limit':282600.,'social_ytd':0.,'ytd_tax_base':0.,'_tax_year':2026}
        row=base_row(date='2026-04-08',PN=0)
        without=calc([row],cfg)
        with_pn=calc([dict(row,PN=8)],cfg)
        self.assertAlmostEqual(with_pn[4]-without[4],48.08,places=2)


if __name__=='__main__':unittest.main()
