"""Regression tests for cards >=2024 and the v6.2 card-validation update.

Uses a minimal XLSX fixture generated with the standard library, so tests do
not require openpyxl or alter any real user files.
"""
import copy
import datetime as dt
import tempfile
import unittest
from pathlib import Path
from xml.sax.saxutils import escape
from zipfile import ZipFile

from card_sync import sync_cards, scan_root
from forecast_tools import validate_cards
from kalkulator_wynagrodzenia import read_xlsx


def make_workbook(path, day, *, work_type=1, sea='TAK', job='Installation 123', hours=8):
    serial = (day.date() - dt.date(1899, 12, 30)).days
    values = {'C':serial, 'G':hours, 'N':work_type, 'O':sea,
              'P':'Polska', 'Q':job}
    cells=[]
    for col, val in values.items():
        if val is None:
            continue
        if isinstance(val,str):
            cells.append(f'<c r="{col}14" t="inlineStr"><is><t>{escape(val)}</t></is></c>')
        else:
            cells.append(f'<c r="{col}14"><v>{val}</v></c>')
    xml=('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
         '<sheetData><row r="14">'+''.join(cells)+'</row></sheetData></worksheet>')
    with ZipFile(path,'w') as z:
        z.writestr('xl/worksheets/sheet1.xml',xml)


class CardAudit(unittest.TestCase):
    def test_2021_silently_ignored_without_deleting_previous_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'KP10.xlsx'
            make_workbook(p,dt.datetime(2021,3,8))
            db={'rows':[{'file_id':'old','date':'2021-03-08','source_path':str(p),'file':p.name}],
                'files':{'old':p.name},'source_index':{},'excluded_files':[]}
            result=sync_cards(db,[p],read_xlsx)
            self.assertFalse(result['errors'])
            self.assertEqual(db['rows'][0]['date'],'2021-03-08')
            self.assertEqual(result['new'],0)

    def test_year_folders_skip_before_2024(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp)
            for y in (2021,2023,2024,2026):
                (base/str(y)).mkdir()
                make_workbook(base/str(y)/'KP40.xlsx',dt.datetime(y,9,30))
            paths,dirs,issues=scan_root(base)
            self.assertEqual({p.parent.name for p in paths},{'2024','2026'})
            self.assertFalse(issues)

    def test_validate_missing_fields_and_mismatched_week(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'KP11.xlsx'
            make_workbook(p,dt.datetime(2026,9,28),work_type=None,sea=None,job=None,hours=0)
            rows=read_xlsx(p)
            self.assertEqual(len(rows),1)
            for row in rows:row.update(file_id='test',file=p.name,source_path=str(p))
            db={'rows':rows,'excluded_files':[]}
            original=copy.deepcopy(db)
            out=validate_cards(db,lambda *_:'2026-09')
            descriptions='\n'.join(x['message'] for x in out['issues'])
            # Revision v6.2.5: empty weekdays between service assignments
            # can legitimately have zero hours, as FSE Annex 1 explains.
            self.assertIn('nazwa karty wskazuje KP11', descriptions)
            self.assertNotIn('Brak wpisanych godzin', descriptions)
            self.assertEqual(db,original)

            # An explicit work type proves an assignment, so missing hours
            # and metadata remain actionable validation failures.
            rows[0]['work_type'] = 1
            rows[0]['work_type_raw'] = '1'
            assigned = validate_cards(db,lambda *_:'2026-09')
            messages = '\n'.join(x['message'] for x in assigned['issues'])
            for required in ('Brak wpisanych godzin','Brak oznaczenia Praca w morzu',
                             'Brak nazwy instalacji'):
                self.assertIn(required,messages)

    def test_legacy_import_can_check_sea_field_from_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'KP40.xlsx'
            make_workbook(p,dt.datetime(2026,9,28),sea=None)
            rows=read_xlsx(p)
            for r in rows:
                r.update(file_id='old',file=p.name,source_path=str(p))
                r.pop('sea_work_raw',None)
            result=validate_cards({'rows':rows},lambda *_:'2026-09',read_source=read_xlsx)
            self.assertTrue(any('Brak oznaczenia Praca w morzu' in r['message']
                                for r in result['issues']))
            self.assertFalse(any('Nie można zweryfikować kolumny' in r['message']
                                 for r in result['issues']))

    def test_leave_day_can_be_zero_hours(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'KP40.xlsx'
            make_workbook(p,dt.datetime(2026,9,28),work_type=6,sea='NIE',job='',hours=0)
            rows=read_xlsx(p)
            rows[0].update(file_id='leave',file=p.name,source_path=str(p))
            out=validate_cards({'rows':rows},lambda *_:'2026-09')
            self.assertFalse(any('Brak wpisanych godzin' in item['message'] for item in out['issues']))

if __name__=='__main__':unittest.main()
