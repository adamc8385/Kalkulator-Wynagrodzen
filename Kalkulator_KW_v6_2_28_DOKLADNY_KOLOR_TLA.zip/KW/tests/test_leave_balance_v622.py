"""Balance-of-leave regression tests; run with unittest discover."""
import copy
import datetime as dt
import unittest

from leave_balance import balance_by_year, normalize_settings


def row(day, hours=0, file_id='card', kind=6):
    return {'date':day,'N':hours,'work_type':kind,'file_id':file_id}


class TestLeaveBalance(unittest.TestCase):
    def test_type6_deduplicated_and_carries(self):
        rows = [row('2024-04-08', 8, 'a'), row('2024-04-08', 8, 'b'),
                row('2024-04-09', 0, 'a'), row('2025-02-03', 8),
                row('2025-02-04', 4)]
        snapshot = copy.deepcopy(rows)
        result = balance_by_year(rows, {'start_year':2024, 'annual_days':26},
                                 target_year=2025, as_of=dt.date(2025,12,31))
        y24, y25 = result['years']
        self.assertEqual(y24['used_days'], 2)
        self.assertEqual(y24['remaining_days'], 24)
        self.assertEqual(y25['carry_in_days'], 24)
        self.assertEqual(y25['used_days'], 1.5)
        self.assertEqual(y25['remaining_days'], 48.5)
        self.assertEqual(y25['used_carry_days'], 1.5)
        self.assertEqual(rows, snapshot)

    def test_skip_company_off_and_weekend_when_no_hours(self):
        result = balance_by_year([row('2026-04-03',0),row('2026-04-04',0),
                                  row('2026-04-07',0)],
                                 {'start_year':2026}, target_year=2026,
                                 as_of=dt.date(2026,11,9))
        self.assertEqual(result['current']['used_days'],1)
        self.assertEqual(result['skipped'],['2026-04-03','2026-04-04'])

    def test_only_newest_year_when_no_older_cards(self):
        result = balance_by_year([row('2026-03-09',8)],target_year=2026,
                                 as_of=dt.date(2026,11,9))
        self.assertEqual(result['start_year'],2026)
        self.assertEqual(result['current']['remaining_days'],25)

    def test_initial_carry_and_override(self):
        options = {'annual_days':26, 'start_year':2025,
                   'opening_carry_days':4, 'yearly_days':{'2025':20}}
        result = balance_by_year([row('2025-03-05',8)],options,
                                 target_year=2026,as_of=dt.date(2026,11,9))
        self.assertEqual(result['years'][0]['remaining_days'],23)
        self.assertEqual(result['years'][1]['carry_in_days'],23)
        self.assertEqual(result['years'][1]['remaining_days'],49)

    def test_exclusions_and_other_codes(self):
        result = balance_by_year([row('2026-03-09',8, 'excluded'),
                                  row('2026-03-10',8, 'active'),
                                  row('2026-03-11',8, 'active',kind=5)],
                                 {'start_year':2026}, target_year=2026,
                                 as_of=dt.date(2026,11,9),
                                 excluded_files=['excluded'])
        self.assertEqual(result['current']['used_days'],1)

    def test_no_unjustified_carry_from_year_2024(self):
        result = balance_by_year([row('2026-03-09',8)],None,
                                 target_year=2026,as_of=dt.date(2026,11,9))
        self.assertEqual(result['current']['entitlement_days'],26)
        self.assertEqual(result['current']['carry_in_days'],0)

    def test_invalid_settings(self):
        for value in ('nan','inf','-1','xxx'):
            with self.assertRaises(ValueError):
                normalize_settings({'annual_days':value},2026)
        with self.assertRaises(ValueError):
            normalize_settings({'start_year':2023},2026)

    def test_no_future_leave_deducted(self):
        result = balance_by_year([row('2026-10-30',8),row('2026-12-28',8)],
                                 {'start_year':2026}, target_year=2027,
                                 as_of=dt.date(2026,11,9))
        self.assertEqual(result['years'][0]['used_days'],1)
        self.assertEqual(result['years'][1]['remaining_days'],51)
        self.assertTrue(result['years'][1]['future_projection'])


if __name__ == '__main__':
    unittest.main()
