"""6.2.23: sidebar light mode, restored dark mode, compact dashboard."""
import tkinter as tk
import unittest
from dashboard_visual import metric_card
from ui_assets import tinted_image_photo
from kalkulator_wynagrodzenia import App

class CompactDashboardTest(unittest.TestCase):
    def test_compact_cards_have_smaller_height_and_distinct_icon(self):
        root=tk.Tk()
        try:
            wrapper=tk.Frame(root);wrapper.pack()
            regular=metric_card(wrapper,'PENSJA PODSTAWOWA BRUTTO','15 588,78 zł','coins','light',root)
            vacation=metric_card(wrapper,'Przysługuje','26 dni','calendar','light',root,vacation=True)
            root.update_idletasks()
            self.assertLessEqual(regular.winfo_reqheight(),72)
            self.assertLessEqual(vacation.winfo_reqheight(),62)
            self.assertLess(regular.coords(regular.find_all()[1])[0],
                            regular.coords(regular.find_all()[-1])[0])
        finally:root.destroy()

    def test_nav_icons_tinted_for_light_and_original_for_dark(self):
        root=tk.Tk()
        try:
            original=tinted_image_photo(root,'nav_0',21,'#173f61')
            self.assertGreater(original.width(),0)
            self.assertIs(original,tinted_image_photo(root,'nav_0',21,'#173f61'))
        finally:root.destroy()

    def test_full_app_starts_dark_even_if_last_session_light(self):
        # Regression: KW v6.2.22 forgot to initialize self.theme_mode.
        import kalkulator_wynagrodzenia as payroll
        from unittest.mock import patch
        root=tk.Tk();root.withdraw()
        try:
            configuration=dict(payroll.DEFAULT, ui_theme='light')
            with patch.object(payroll,'load',return_value=configuration):
                app=payroll.App(root)
            root.update_idletasks()
            self.assertEqual(app.theme_mode,'dark')
            self.assertEqual(app.side.cget('bg'),'#092238')
        finally:root.destroy()

    def test_sidebar_colors_change_and_dark_restores(self):
        root=tk.Tk();root.withdraw()
        try:
            # Apply the actual method to a minimal fake app, keeping tests off
            # real user data and without triggering background startup actions.
            from unittest.mock import patch
            from ui_assets import image_photo
            class Sidebar:pass
            ui=Sidebar();ui.root=root;ui.theme_mode='light';ui.style=__import__('tkinter').ttk.Style(root);ui.page='Pulpit'
            ui.side=tk.Frame(root,bg='#092238');ui.side_canvas=tk.Canvas(ui.side,bg='#092238')
            ui.side_content=tk.Frame(ui.side_canvas,bg='#092238')
            ui.sidebar_title=tk.Label(ui.side_content,text='PANEL NAWIGACYJNY',bg='#092238',fg='#d8b16b')
            ui.nav_icons={'Pulpit':image_photo(root,'nav_0',21),'Rozliczenie':image_photo(root,'nav_3',21),
                          'logout':image_photo(root,'logout',22)}
            ui.nav_icons_light={'Pulpit':tinted_image_photo(root,'nav_0',21,'#173f61'),
                                'Rozliczenie':tinted_image_photo(root,'nav_3',21,'#173f61'),
                                'logout':tinted_image_photo(root,'logout',22,'#9b641c')}
            ui.nav_buttons={k:tk.Button(ui.side_content,text=k,bg='#193a51',fg='#f2f6f9',image=ui.nav_icons[k])
                            for k in ('Pulpit','Rozliczenie')}
            ui.logout_btn=tk.Button(ui.side_content,text='Wyloguj się',bg='#163447',fg='#d8b16b',image=ui.nav_icons['logout'])
            App._apply_interface_theme(ui)
            self.assertEqual(ui.side.cget('bg'),'#edf4fa')
            self.assertEqual(ui.nav_buttons['Rozliczenie'].cget('bg'),'#ffffff')
            self.assertEqual(ui.nav_buttons['Pulpit'].cget('bg'),'#f4c664')
            self.assertEqual(ui.logout_btn.cget('bg'),'#ffffff')
            ui.theme_mode='dark'
            App._apply_interface_theme(ui)
            self.assertEqual(ui.side.cget('bg'),'#092238')
            self.assertEqual(ui.nav_buttons['Rozliczenie'].cget('bg'),'#193a51')
        finally:root.destroy()

if __name__=='__main__':unittest.main()
