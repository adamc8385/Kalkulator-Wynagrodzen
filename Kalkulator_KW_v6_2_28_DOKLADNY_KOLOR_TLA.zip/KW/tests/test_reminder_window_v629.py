"""Window regression checks for the salary reminder and maximized startup."""
import datetime as dt
import tkinter as tk
import unittest
from unittest.mock import patch

from kalkulator_wynagrodzenia import App


class FakeDate(dt.date):
    @classmethod
    def today(cls):
        return cls(2026, 11, 10)


class WindowBehaviour629(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.geometry('900x650+100+100')
        self.root.update()
        self.app = App.__new__(App)
        self.app.root = self.root
        self.app.db = {'hide_reminder_forever': False}
        self.app.language = 'pl'
        self.app.month = tk.StringVar(master=self.root, value='2026-11')
        self.app.label = lambda parent, text, *args, **kwargs: tk.Label(parent, text=text)
        self.app.button = lambda parent, text, callback, *args: tk.Button(parent, text=text, command=callback)
        self.saved = []
        self.save_patcher = patch('kalkulator_wynagrodzenia.save', side_effect=lambda data: self.saved.append(data.copy()))
        self.date_patcher = patch('kalkulator_wynagrodzenia.dt.date', FakeDate)
        self.save_patcher.start()
        self.date_patcher.start()

    def tearDown(self):
        self.date_patcher.stop()
        self.save_patcher.stop()
        self.root.destroy()

    def popup(self):
        return getattr(self.app, '_monthly_reminder_popup', None)

    def test_reminder_survives_window_maximize_and_restore(self):
        self.app.show_monthly_payroll_reminder()
        self.root.update()
        original = self.popup()
        self.assertTrue(original.winfo_exists())
        self.root.geometry('1320x780+0+0')
        self.root.update()
        self.assertTrue(original.winfo_exists())
        self.root.geometry('1000x680+30+50')
        self.root.update()
        self.assertTrue(original.winfo_exists())
        self.assertFalse(self.app.db['hide_reminder_forever'])
        self.assertEqual(self.saved, [])
        # A title-bar/frame event addressed to root cannot close the popup.
        self.root.event_generate('<Button-1>', x=3, y=3)
        self.root.update()
        self.assertTrue(original.winfo_exists())

    def test_click_in_main_content_does_not_dismiss(self):
        tk.Label(self.root, text='work-card list').pack()
        self.app.show_monthly_payroll_reminder()
        self.root.update()
        popup = self.popup()
        label = next(w for w in self.root.winfo_children() if isinstance(w, tk.Label))
        label.event_generate('<Button-1>', x=2, y=2)
        self.root.update()
        self.assertIs(self.popup(),popup)
        self.assertTrue(popup.winfo_exists())
        self.assertFalse(self.app.db['hide_reminder_forever'])

    def test_explicit_hide_forever_persists(self):
        self.app.show_monthly_payroll_reminder()
        self.root.update()
        popup = self.popup()
        def descendants(widget):
            for child in widget.winfo_children():
                yield child
                yield from descendants(child)
        checkbox = next(w for w in descendants(popup)
                        if isinstance(w, tk.Checkbutton) and 'nie pokazuj' in w.cget('text'))
        checkbox.invoke()
        self.root.update()
        self.assertIs(self.popup(),popup)
        self.assertTrue(popup.winfo_exists())
        self.assertTrue(self.app.db['hide_reminder_forever'])
        self.assertEqual(len(self.saved), 1)
        # Turning the opt-out off before closing must be possible.
        checkbox.invoke()
        self.root.update()
        self.assertFalse(self.app.db['hide_reminder_forever'])
        self.assertTrue(popup.winfo_exists())
        checkbox.invoke()
        self.root.update()
        self.assertTrue(self.app.db['hide_reminder_forever'])
        self.assertTrue(popup.winfo_exists())
        # Only close button / X dismisses the current reminder.
        buttons = []
        def visit(widget):
            for child in widget.winfo_children():
                if isinstance(child,tk.Button): buttons.append(child)
                visit(child)
        visit(popup)
        close = next(b for b in buttons if b.cget('text')=='Zamknij')
        close.invoke()
        self.root.update()
        self.assertIsNone(self.popup())
        self.app.show_monthly_payroll_reminder()
        self.assertIsNone(self.popup())

    def test_maximize_uses_native_zoom_not_fullscreen(self):
        class FakeRoot:
            def __init__(self):
                self.states = []
            def winfo_exists(self):
                return True
            def state(self, new):
                self.states.append(new)
        fake = FakeRoot()
        self.app.root = fake
        self.app._maximize_main_window()
        self.assertEqual(fake.states, ['zoomed'])


if __name__ == '__main__':
    unittest.main()
