"""v6.2.3 — working-day checks respect calendar and entire date, not template rows."""
import copy
import datetime as dt
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from forecast_tools import validate_cards
from kalkulator_wynagrodzenia import read_xlsx


def entry(date, row=14, *, hours=0, kind=None, sea='', job=''):
    return {'date': date, 'row': row, 'file_id': 'test', 'file': 'karta.xlsx',
            'source_path': '', 'N': hours, 'A': 0., 'B': 0., 'PN': 0.,
            'P': 0., 'T': 0., 'work_type': kind,
            'work_type_raw': str(kind) if kind is not None else '',
            'sea_work_raw': sea, 'job': job, 'country': ''}


def check(rows):
    db = {'rows': rows, 'excluded_files': []}
    original = copy.deepcopy(db)
    result = validate_cards(db, lambda date, db: date[:7])
    assert db == original, 'Validator must never modify saved work cards'
    return result


def missing_messages(out):
    return [i for i in out['issues'] if 'Brak wpisanych godzin' in i['message']]


class WorkdayCalendarValidation(unittest.TestCase):
    def test_blank_saturday_and_sunday_are_normal_free_days(self):
        for day in ('2026-09-26', '2026-09-27'):
            with self.subTest(day=day):
                out = check([entry(day)])
                self.assertEqual(out['errors'], 0)
                self.assertFalse(missing_messages(out))
                self.assertFalse(any('Brak wpisanego typu pracy' in x['message'] for x in out['issues']))
                self.assertFalse(any('Brak nazwy instalacji' in x['message'] for x in out['issues']))
                self.assertFalse(any('Brak oznaczenia Praca w morzu' in x['message'] for x in out['issues']))

    def test_weekend_without_hours_is_off_even_if_type_was_entered(self):
        # A default work type without hours is not proof of actual weekend work.
        out = check([entry('2026-09-26', kind=1)])
        self.assertFalse(missing_messages(out))
        self.assertEqual(out['errors'], 0)

    def test_official_and_company_holidays_can_have_no_hours(self):
        for day in ('2026-05-01', '2026-04-03', '2026-12-31', '2025-12-24'):
            with self.subTest(day=day):
                out = check([entry(day)])
                self.assertFalse(missing_messages(out))
                self.assertEqual(out['errors'], 0)

    def test_scheduled_weekday_with_no_hours_is_one_error(self):
        out = check([entry('2026-09-29', kind=1, job='Job'), entry('2026-09-29', row=15)])
        errors = missing_messages(out)
        self.assertEqual(len(errors), 1)
        self.assertEqual(errors[0]['level'], 'BŁĄD')
        self.assertEqual(errors[0]['row'], 14)

    def test_later_row_with_work_prevents_false_missing_day(self):
        out = check([entry('2026-09-29'),
                     entry('2026-09-29', row=15, hours=8, kind=1,
                           sea='NIE', job='Engine A')])
        self.assertFalse(missing_messages(out))
        self.assertFalse(any('Brak wpisanego typu pracy' in x['message'] for x in out['issues']))

    def test_paid_day_off_and_leave_are_not_missing_work(self):
        for kind in (5, 6):
            with self.subTest(kind=kind):
                out = check([entry('2026-09-29', kind=kind)])
                self.assertFalse(missing_messages(out))
                self.assertFalse(any('Brak nazwy instalacji' in x['message'] for x in out['issues']))

    def test_weekend_with_actual_hours_still_validates_required_fields(self):
        out = check([entry('2026-09-26', hours=8)])
        self.assertFalse(missing_messages(out))
        self.assertTrue(any('Brak wpisanego typu pracy' in x['message'] for x in out['issues']))
        self.assertTrue(any('Brak nazwy instalacji' in x['message'] for x in out['issues']))

    def test_invalid_explicit_sea_mark_is_still_detected_on_free_day(self):
        out = check([entry('2026-09-27', sea='MAYBE')])
        self.assertTrue(any('Nieprawidłowe oznaczenie Praca w morzu' in i['message']
                            for i in out['issues']))

    def test_2024_workday_at_home_without_assignment_is_not_an_error(self):
        out = check([entry('2024-04-02')])
        self.assertEqual(len(missing_messages(out)), 0)

    def test_imported_date_only_weekday_is_checked(self):
        with TemporaryDirectory() as tmp:
            path = Path(tmp) / 'KP40.xlsx'
            serial = (dt.date(2026, 9, 28) - dt.date(1899, 12, 30)).days
            xml = ('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                   f'<sheetData><row r="14"><c r="C14"><v>{serial}</v></c></row>'
                   '</sheetData></worksheet>')
            with ZipFile(path, 'w') as z:
                z.writestr('xl/worksheets/sheet1.xml', xml)
            rows = read_xlsx(path)
            self.assertEqual(len(rows), 1)
            self.assertEqual(len(missing_messages(check(rows))), 0)


if __name__ == '__main__':
    unittest.main()
