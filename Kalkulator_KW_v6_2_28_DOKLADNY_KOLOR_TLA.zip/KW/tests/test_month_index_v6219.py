"""The month index must be behavior-identical to the original list filter."""
import unittest
from kalkulator_wynagrodzenia import App, accounting_month, supported_date
from month_index import build

class IndexTests(unittest.TestCase):
    def test_month_membership_and_no_duplicate(self):
        db={'calendars':{},'excluded_files':['ban'], 'rows':[
            {'date':'2026-09-28','file_id':'a','A':2},
            {'date':'2026-11-01','file_id':'a','A':3},
            {'date':'2026-10-28','file_id':'ban','A':99},
            {'date':'2026-10-31','file_id':'b','A':1},
            {'date':'2023-02-02','file_id':'a','A':1},
        ]}
        index=build(db['rows'],db['excluded_files'],supported_date,accounting_month,db)
        for month in ['2026-09','2026-10','2026-11']:
            previous=[row for row in db['rows']
                      if supported_date(row.get('date'))
                      and accounting_month(row['date'],db)==month
                      and row.get('file_id') not in db['excluded_files']]
            self.assertEqual(index.get(month,[]),previous)
        self.assertEqual(len(index['2026-10']),3)

    def test_saved_calendar_and_exclusions_rebuild_index(self):
        class Month:
            def get(self):return '2026-10'
        app=App.__new__(App)
        app.month=Month()
        app.db={'calendars':{},'excluded_files':[],
                'rows':[{'date':'2026-09-28','file_id':'a'}]}
        self.assertEqual(len(app.current()),1)
        app.db['calendars']={'2026':{'9':[40]}}
        self.assertEqual(len(app.current()),0)
        app.db['calendars']={}
        app.db['excluded_files'].append('a')
        self.assertEqual(len(app.current()),0)

if __name__=='__main__': unittest.main()
