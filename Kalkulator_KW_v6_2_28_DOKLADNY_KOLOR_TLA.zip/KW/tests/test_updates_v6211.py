"""User-approved behavior in v6.2.11: persistent reminder, no N/A/B/PN split audit."""
import datetime as dt
import tkinter as tk
import unittest
from unittest.mock import patch, Mock
from forecast_tools import validate_cards
from forecast_ui import open_card_check
from kalkulator_wynagrodzenia import App, calc, DEFAULT

class FixedDate(dt.date):
    @classmethod
    def today(cls):return cls(2026,11,10)


def visit(widget):
    yield widget
    for child in widget.winfo_children():
        yield from visit(child)


class PersistentReminder6211(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.geometry('900x650+0+0');self.root.update()
        self.app=App.__new__(App);self.app.root=self.root
        self.app.db={'hide_reminder_forever':False};self.app.language='pl'
        self.app.month=tk.StringVar(master=self.root,value='2026-11')
        self.app.label=lambda parent,text,*a,**kw:tk.Label(parent,text=text)
        self.app.button=lambda parent,text,cb,*a:tk.Button(parent,text=text,command=cb)
        self.app._auto_import_for_year=Mock()
        self.app.show=Mock()
        self.saved=[]
        self.save_patch=patch('kalkulator_wynagrodzenia.save',side_effect=lambda value:self.saved.append(dict(value)))
        self.date_patch=patch('kalkulator_wynagrodzenia.dt.date',FixedDate)
        self.save_patch.start();self.date_patch.start()
    def tearDown(self):
        self.date_patch.stop();self.save_patch.stop();self.root.destroy()
    def popup(self):
        return self.app._monthly_reminder_popup
    def open(self):
        self.app.show_monthly_payroll_reminder();self.root.update()
        return self.popup()
    def button(self,popup,part):
        return next(w for w in visit(popup) if isinstance(w,tk.Button) and w.cget('text')==part)

    def test_background_resize_and_escape_never_close(self):
        bg=tk.Label(self.root,text='tło');bg.pack()
        p=self.open()
        bg.event_generate('<Button-1>',x=1,y=1)
        self.root.event_generate('<Button-1>',x=2,y=2)
        self.root.geometry('1100x700+0+0')
        p.event_generate('<Escape>')
        self.root.update()
        self.assertTrue(p.winfo_exists())
        self.assertIs(self.popup(),p)
        self.assertEqual(self.saved,[])
        self.button(p,'Zamknij').invoke();self.root.update()
        self.assertIsNone(self.popup())

    def test_opt_out_does_not_close_and_reversible(self):
        p=self.open()
        checkbox=next(w for w in visit(p) if isinstance(w,tk.Checkbutton) and 'nie pokazuj' in w.cget('text'))
        checkbox.invoke();self.root.update()
        self.assertTrue(self.app.db['hide_reminder_forever'])
        self.assertTrue(p.winfo_exists())
        checkbox.invoke();self.root.update()
        self.assertFalse(self.app.db['hide_reminder_forever'])
        self.assertTrue(p.winfo_exists())
        self.assertEqual(len(self.saved),2)
        self.button(p,'Zamknij').invoke();self.root.update()
        self.assertIsNone(self.popup())

    def test_review_action_navigates_without_dismissing(self):
        p=self.open()
        self.button(p,'Sprawdź rozliczenie').invoke()
        self.root.update()
        self.assertEqual(self.app.month.get(),'2026-10')
        self.app._auto_import_for_year.assert_called_once_with(silent=True)
        self.app.show.assert_called_once_with('Rozliczenie')
        self.assertTrue(p.winfo_exists())
        self.button(p,'Zamknij').invoke()
        self.root.update()
        self.assertIsNone(self.popup())

    def test_header_x_is_explicit_close(self):
        p=self.open()
        self.button(p,'✕').invoke();self.root.update()
        self.assertIsNone(self.popup())


class SplitAuditDisabled6211(unittest.TestCase):
    def card(self,**changes):
        c={'date':'2026-11-09','file':'card.xlsx','file_id':'one','row':14,
           'N':4.,'A':4.,'B':0.,'PN':8.,'P':0.,'T':0.,'work_type':1,
           'work_type_raw':'1','sea_work_raw':'NIE','job':'Instalacja',
           'work_start_raw':'18:00','work_end_raw':'06:00','work_clock_source':'literal'}
        c.update(changes)
        return c

    def test_wrong_split_is_not_reported_and_no_legacy_count(self):
        cards=[self.card(),self.card(row=15,N=2.,A=0.,B=0.,PN=8.,
                   work_start_raw=None,work_end_raw=None)]
        def no_source(_):raise AssertionError('Nie należy ponownie otwierać Excela tylko dla PN')
        out=validate_cards({'rows':cards},lambda *_:'2026-11',read_source=no_source,year=2026)
        self.assertEqual(out['unchecked_clock_rows'],0)
        texts=' '.join(i['message'] for i in out['issues'])
        for forbidden in ('Kolumna PN:', 'Kolumna A:', 'Kolumna B:',
                          'Suma N+A+B:', 'PN podano bez', 'PN nie może przekraczać',
                          'powinno być 8 h', 'podział N/A/B/PN'):
            self.assertNotIn(forbidden,texts)

    def test_other_validation_is_not_disabled(self):
        row=self.card(work_type_raw='99',work_type=None)
        result=validate_cards({'rows':[row]},lambda *_:'2026-11',year=2026)
        self.assertTrue(any('Niepoprawny typ pracy' in i['message'] for i in result['issues']))

    def test_salary_calculation_unaffected_by_audit(self):
        row=self.card(date='2026-04-08')
        cfg={**DEFAULT,'salary':15588.78,'nominal':160,'social_limit':282600.,
             'social_ytd':0.,'ytd_tax_base':0.,'_tax_year':2026}
        before=calc([row],cfg)
        validate_cards({'rows':[row]},lambda *_:'2026-04',year=2026)
        after=calc([row],cfg)
        self.assertEqual(before,after)
        self.assertEqual(row['PN'],8.)

    def test_check_window_never_mentions_pn_coverage(self):
        root=tk.Tk();root.geometry('800x600+0+0');root.update()
        class Stub:pass
        app=Stub();app.root=root;app.db={};app.language='pl'
        sample={'year':2026,'active_rows':1,'errors':0,'warnings':0,
                'unchecked_clock_rows':999,'issues':[]}
        try:
            with patch('forecast_ui.validate_cards',return_value=sample):
                window=open_card_check(app)
            labels=[w.cget('text') for w in visit(window) if isinstance(w,tk.Label)]
            self.assertFalse(any('N/A/B/PN' in label for label in labels))
            window.destroy()
        finally:root.destroy()

if __name__=='__main__':unittest.main()
