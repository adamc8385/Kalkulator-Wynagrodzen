"""Presentation-only regression tests for v6.2.22 dashboard artwork."""
import unittest
import tkinter as tk
from dashboard_visual import _vector_icon,metric_card,section_heading
from ui_theme import apply_tree

class ArtworkTests(unittest.TestCase):
    def test_dedicated_icons_render_at_expected_size(self):
        for name in ('coins','wallet','clock','double_clock','calendar','calendar_x',
                     'calendar_check','hourglass','umbrella','chart'):
            image=_vector_icon(name,48,'#d8b16b')
            self.assertEqual(image.size,(48,48))
            self.assertIsNotNone(image.getbbox(),name)

    def test_light_card_separate_artwork_left_of_value(self):
        root=tk.Tk();root.geometry("1000x500")
        try:
            frame=tk.Frame(root);frame.pack()
            card=metric_card(frame,'PROGNOZA PRZELEWU','12 300,00 zł',
                             'wallet','light',root)
            root.update_idletasks()
            self.assertTrue(card._metric_icon)
            icons=card.find_all()
            self.assertGreaterEqual(len(icons),4)
            self.assertTrue(card._metric_background)
            self.assertLess(card.coords(icons[1])[0],card.coords(icons[-1])[0])
        finally:root.destroy()

    def test_dark_card_uses_original_navy_palette(self):
        root=tk.Tk();root.geometry("1000x500")
        try:
            frame=tk.Frame(root);frame.pack()
            card=metric_card(frame,'NADGODZINY A','31 h','clock','dark',root)
            root.update_idletasks()
            self.assertTrue(card._metric_background)
            self.assertEqual(card.cget('bg'),'#081725')
        finally:root.destroy()

    def test_section_heading_keeps_caption_and_action(self):
        root=tk.Tk();root.geometry("1000x500")
        try:
            frame=tk.Frame(root);frame.pack()
            section=section_heading(frame,'URLOP WYPOCZYNKOWY — 2026',
                                  'umbrella','light',root,command=lambda:None,
                                  button_text='Ustawienia urlopu')
            root.update_idletasks()
            buttons=[x for x in section.winfo_children() if isinstance(x,tk.Button)]
            self.assertEqual([x.cget('text') for x in buttons],['Ustawienia urlopu'])
        finally:root.destroy()
