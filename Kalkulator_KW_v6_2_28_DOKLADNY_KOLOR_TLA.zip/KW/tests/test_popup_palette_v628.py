"""Verify v6.2.28 uses the *exact* dashboard PANEL RGB in dark dialogs.

Pure visual regressions; does not write user data or alter payroll calculations.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
import unittest

from app_version import LABEL
from forecast_ui import _popup
from kalkulator_wynagrodzenia import App, PANEL
from leave_balance_ui import _history_dialog, _settings_dialog
from ui_theme import DARK_MAIN_SURFACE, DARK_POPUP, apply_tree, apply_style

EXPECTED = '#10293c'


class _FakeApp:
    language = 'pl'
    theme_mode = 'dark'
    ui_scale = 1.0
    label = App.label
    button = App.button
    reconcile_payslip_balances = App.reconcile_payslip_balances

    def __init__(self, root):
        self.root = root
        self.month = tk.StringVar(root, value='2026-11')
        self.db = {'payslip_balances': {}}

    def tr(self, text):
        return str(text)


class ExactNavyTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.geometry('1300x900+0+0')
        self.root.update_idletasks()
        self.app = _FakeApp(self.root)

    def tearDown(self):
        self.root.destroy()

    @staticmethod
    def descendants(win):
        for child in win.winfo_children():
            yield child
            yield from ExactNavyTests.descendants(child)

    def test_single_palette_reference_exact_rgb(self):
        self.assertEqual(EXPECTED, PANEL)
        self.assertEqual(DARK_MAIN_SURFACE, PANEL)
        self.assertEqual(DARK_POPUP, PANEL)
        self.assertEqual(LABEL, 'v6.2.28')

    def test_month_picker_base_and_all_twelve_tiles_unchanged(self):
        parent = tk.Frame(self.root)
        parent.pack()
        App.pick_month(self.app, parent)
        win = next(w for w in self.root.winfo_children() if isinstance(w, tk.Toplevel))
        try:
            win._refresh_payroll_theme()
            self.assertEqual(win.cget('bg'), EXPECTED)
            grid = next(w for w in win.winfo_children() if isinstance(w,tk.Frame) and len(w.winfo_children())==12)
            self.assertEqual(grid.cget('bg'), EXPECTED)
            squares = grid.winfo_children()
            self.assertEqual(len(squares), 12)
            for number, square in enumerate(squares, 1):
                chosen = number == 11
                self.assertEqual(square.cget('bg'),'#e9b54f' if chosen else '#55768e')
                self.assertEqual(square.winfo_children()[0].cget('bg'),
                                 '#b9dff5' if chosen else '#193a51')
        finally:
            win.destroy()

    def test_leave_settings_main_bg_and_alternating_fields(self):
        _settings_dialog(self.app,2026,2024,lambda x: None)
        win = next(w for w in self.root.winfo_children() if isinstance(w,tk.Toplevel))
        try:
            win._refresh_payroll_theme()
            self.assertEqual(win.cget('bg'), EXPECTED)
            bands=[w for w in self.descendants(win) if isinstance(w,tk.Frame)
                   and w.cget('bg') in ('#142f43','#1b394f')]
            self.assertEqual(len(bands),4)
            self.assertEqual([w.cget('bg') for w in bands],['#142f43','#1b394f']*2)
            self.assertTrue(all(any(isinstance(x,tk.Entry) and x.cget('bg')=='#ffffff'
                                    for x in band.winfo_children()) for band in bands))
        finally:
            win.destroy()

    def test_leave_history_main_bg_and_blank_tree_area(self):
        style=ttk.Style(self.root)
        if 'clam' in style.theme_names():style.theme_use('clam')
        apply_style(style,'dark')
        result={'years':[{'year':2026,'carry_in_days':0,'entitlement_days':26,
                         'used_days':17,'remaining_days':9}]}
        _history_dialog(self.app,result)
        win = next(w for w in self.root.winfo_children() if isinstance(w,tk.Toplevel))
        try:
            win._refresh_payroll_theme()
            self.assertEqual(win.cget('bg'),EXPECTED)
            tree=next(w for w in self.descendants(win) if isinstance(w,ttk.Treeview))
            self.assertEqual(style.lookup('LeaveHistory.Treeview','fieldbackground'),EXPECTED)
            self.assertEqual(style.lookup('LeaveHistory.Treeview','background'),EXPECTED)
        finally:
            win.destroy()

    def test_year_popup_and_reconciliation_bands(self):
        win=_popup(self.app,'Rok — prognoza','850x600')
        try:
            win._refresh_payroll_theme()
            self.assertEqual(win.cget('bg'),EXPECTED)
        finally:
            win.destroy()
        self.app.reconcile_payslip_balances()
        win=next(w for w in self.root.winfo_children() if isinstance(w,tk.Toplevel))
        try:
            win._refresh_payroll_theme()
            self.assertEqual(win.cget('bg'),EXPECTED)
            bands=[w for w in win.winfo_children() if isinstance(w,tk.Frame)
                   and w.cget('bg') in ('#142f43','#1b394f')]
            self.assertEqual([x.cget('bg') for x in bands],['#142f43','#1b394f'])
            self.assertEqual(len(bands),2)
            for band in bands:
                entries=[x for x in band.winfo_children() if isinstance(x,tk.Entry)]
                self.assertEqual(len(entries),1)
                self.assertEqual(entries[0].cget('bg'),'#ffffff')
        finally:
            win.destroy()

    def test_theme_switch_recovers_exact_bg(self):
        win=tk.Toplevel(self.root)
        win.configure(bg='#081725')
        label=tk.Label(win,bg='#081725',fg='#f2f6f9',text='Sim')
        label.pack()
        band=tk.Frame(win,bg='#193a51')
        band.pack()
        try:
            apply_tree(win,'dark',popup=True)
            self.assertEqual(win.cget('bg'),EXPECTED)
            self.assertEqual(label.cget('bg'),EXPECTED)
            self.assertEqual(band.cget('bg'),'#193a51')
            apply_tree(win,'light',popup=True)
            apply_tree(win,'dark',popup=True)
            self.assertEqual(win.cget('bg'),EXPECTED)
            self.assertEqual(band.cget('bg'),'#193a51')
        finally:
            win.destroy()


if __name__=='__main__':
    unittest.main()
