"""v6.2.5: EU travel code and work-free weekdays without false positives."""
import copy
import datetime as dt
import unittest
from unittest import mock
import tkinter as tk

from eu_travel_policy import eligible_country, travel_type_issue
from forecast_tools import validate_cards
from forecast_ui import _popup


def row(day='2026-10-12', *, kind=11, country='Włochy', p=8.0, t=0.0,
        hours=0.0, job='Ship A', n=0.0, a=0.0, row_no=14):
    return dict(date=day, file_id='test', file='A KP42.xlsx', source_path='', row=row_no,
                work_type=kind, work_type_raw=str(kind) if kind is not None else '',
                sea_work_raw='NIE', country=country, job=job,
                N=n+hours, A=a, B=0., PN=0., P=p, T=t)


def validate(rows):
    db={'rows': rows, 'excluded_files': []}
    orig=copy.deepcopy(db)
    result=validate_cards(db,lambda date, db: date[:7])
    assert db==orig
    return result


class EUTravelRules(unittest.TestCase):
    def test_five_named_countries_and_translations(self):
        countries=['Dania','Finlandia','Francja','Holandia','Włochy',
                   'Denmark','Finland','France','Netherlands','Italy','NL','IT']
        for country in countries:
            with self.subTest(country=country):
                self.assertIsNotNone(eligible_country(country))
                self.assertIsNone(travel_type_issue(row(country=country),dt.date(2026,10,12)))
        for country in ('Polska','Niemcy','Hiszpania','Włochy/Polska',''):
            self.assertIsNone(eligible_country(country))

    def test_wrong_type_with_explicit_travel_and_country_flagged(self):
        out=validate([row(kind=2)])
        self.assertTrue(any('wymagany jest typ 11' in i['message'] and i['level']=='BŁĄD'
                            for i in out['issues']))

    def test_missing_type_has_single_specific_issue(self):
        out=validate([row(kind=None)])
        self.assertEqual(len([i for i in out['issues'] if 'typ pracy' in i['message'].lower()]),1)

    def test_earlier_year_is_only_advisory(self):
        issue=travel_type_issue(row(kind=2,day='2024-10-14'),dt.date(2024,10,14))
        self.assertEqual(issue[0],'UWAGA')

    def test_no_travel_does_not_demand_type_11(self):
        out=validate([row(kind=1,p=0,t=0,n=8)])
        self.assertFalse(any('wymagany jest typ 11' in i['message'] for i in out['issues']))

    def test_offshore_code_10_is_distinct(self):
        self.assertIsNone(travel_type_issue(row(kind=10),dt.date(2026,10,12)))

    def test_free_day_between_assignments_is_not_error(self):
        out=validate([row(day='2026-10-12',kind=None,p=0,t=0,job='',country='Włochy')])
        self.assertFalse(any('Brak wpisanych godzin' in i['message'] for i in out['issues']))
        self.assertFalse(any('Brak wpisanego typu pracy' in i['message'] for i in out['issues']))

    def test_work_assigned_but_no_hours_is_error(self):
        out=validate([row(kind=1,p=0,t=0,job='Job',country='Polska')])
        self.assertEqual(len([i for i in out['issues'] if 'Brak wpisanych godzin' in i['message']]),1)

    def test_repeating_eight_hour_rows_not_13h_continuous_warning(self):
        out=validate([row(kind=1, p=0,n=8,country='Polska',row_no=14),
                      row(kind=1, p=0,n=8,country='Polska',row_no=15)])
        self.assertFalse(any('13 h' in i['message'] for i in out['issues']))

    def test_single_row_14_hours_has_advisory(self):
        out=validate([row(kind=1,p=0,n=8,a=6,country='Polska')])
        self.assertTrue(any('13 h' in i['message'] and i['level']=='UWAGA' for i in out['issues']))

    def test_travel_with_unknown_country_does_not_guess(self):
        out=validate([row(kind=2,country='Italy / Poland')])
        self.assertFalse(any('wymagany jest typ 11' in i['message'] for i in out['issues']))


class WindowSmoke(unittest.TestCase):
    def test_check_window_is_modeless_for_native_minimize(self):
        root=tk.Tk()
        root.withdraw()
        class App: pass
        app=App();app.root=root
        try:
            win=_popup(app, 'Kontrola kart pracy', '985x610',maximize=True)
            self.assertIsNone(win.grab_current())
            self.assertEqual(win.resizable(),(1,1))
            self.assertEqual(win.overrideredirect(),None if win.overrideredirect() is None else False)
            win.destroy()
            modal=_popup(app,'Another','750x500',maximize=False)
            self.assertIsNotNone(modal.grab_current())
            modal.destroy()
        finally:
            root.destroy()

if __name__=='__main__':
    unittest.main()
