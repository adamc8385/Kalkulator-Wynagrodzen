"""Regressions for v6.2.18 simulator fields and conditional summary."""
import copy
import unittest
from kalkulator_wynagrodzenia import DEFAULT, calc, nominal_for_calendar_month
from forecast_tools import hypothetical_month_result
from monthly_summary import visible_monthly_summary
from night_work import night_bonus_detail

class Enhancements6218(unittest.TestCase):
    def setUp(self):
        self.cfg=dict(DEFAULT,salary=15588.78,nominal=nominal_for_calendar_month(2026,10),
                      _tax_year=2026,social_ytd=273070.51,
                      ytd_tax_base=243837.,offshore=230.)

    def scenario(self,**kw):
        return hypothetical_month_result('2026-10',self.cfg,calc,39.5,10,24.5,**kw)

    def test_offshore_three_days_230(self):
        a=self.scenario()
        b=self.scenario(offshore_days=3)
        self.assertEqual(b['result'][1],3)
        self.assertEqual(round(b['result'][4]-a['result'][4],2),690.)
        self.assertGreater(b['result'][10],a['result'][10])

    def test_pn_is_overlapping_bonus_not_extra_hours(self):
        old=self.scenario()
        night=self.scenario(night_hours=8)
        self.assertEqual(night['result'][0]['N'],old['result'][0]['N'])
        self.assertEqual(night['result'][0]['A'],old['result'][0]['A'])
        self.assertEqual(night['result'][0]['B'],old['result'][0]['B'])
        self.assertEqual(night['result'][0]['PN'],8)
        expected=night_bonus_detail(night['rows'])['amount']
        self.assertGreater(expected,0)
        self.assertAlmostEqual(night['result'][4]-old['result'][4],expected,places=2)

    def test_cabin_and_diet_gross(self):
        a=self.scenario()
        b=self.scenario(shared_room_nights=2,diet_days=3)
        self.assertEqual(b['cfg']['shared_room_nights'],2)
        self.assertEqual(b['cfg']['domestic_diet_extra_days'],3)
        self.assertAlmostEqual(b['result'][4]-a['result'][4],365.,places=2)

    def test_combined_has_matching_main_calc(self):
        s=self.scenario(offshore_days=3,night_hours=8,shared_room_nights=2,diet_days=3)
        self.assertEqual(s['result'],calc(s['rows'],s['cfg']))
        self.assertEqual(s['result'][0]['N'],176)
        self.assertAlmostEqual(s['result'][3],s['result'][4]-self.cfg['salary'],places=2)
        self.assertEqual(s['result'][1],3)

    def test_no_saved_user_data_changes(self):
        before=copy.deepcopy(self.cfg)
        self.scenario(offshore_days=3,night_hours=4,shared_room_nights=2,diet_days=3)
        self.assertEqual(before,self.cfg)

    def test_reject_invalid_day_night_counts(self):
        for kw in ({'offshore_days':1.5},{'shared_room_nights':-1},
                   {'diet_days':32},{'night_hours':float('nan')},
                   {'offshore_days':float('inf')}):
            with self.subTest(kw=kw),self.assertRaises(ValueError):self.scenario(**kw)

    def test_summary_hides_zero_additions_and_displays_active(self):
        basics=dict(N=176,A=35,B=0,PN=0)
        settings=dict(shared_room_nights=0,domestic_diet_extra_days=0)
        summary=dict(visible_monthly_summary(basics,0,0,0,0,0,settings,211))
        self.assertIn('Godziny normalne N — kalendarz',summary)
        self.assertIn('Nadgodziny A — dodatek 50%',summary)
        for name in ('Nadgodziny B — dodatek 100%','Godziny nocne PN',
                     'Urlop (h)','Offshore','Czas podróży po odliczeniu',
                     'Dodatek do diety — liczba dni','Wspólna kabina — liczba nocy'):
            self.assertNotIn(name,summary)
        basics.update(B=1,PN=2)
        settings.update(shared_room_nights=1,domestic_diet_extra_days=2)
        summary=dict(visible_monthly_summary(basics,2,0,2,1,8,settings,220))
        self.assertEqual(summary['Nadgodziny B — dodatek 100%'],'1 h')
        self.assertEqual(summary['Offshore'],'1 dni')
        self.assertEqual(summary['Wspólna kabina — liczba nocy'],'1 nocy')
        self.assertEqual(summary['Dodatek do diety — liczba dni'],'2 dni')
        self.assertEqual(summary['Urlop (h)'],'8 h')
        self.assertIn('Godziny nocne PN',summary)

    def test_offshore_default_is_230(self):
        self.assertEqual(DEFAULT['offshore'],230.)

if __name__=='__main__':unittest.main()
