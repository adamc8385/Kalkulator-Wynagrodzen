"""UI-only regression tests for v6.2.25; no payroll formulas are modified."""
import tkinter as tk
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from PIL import Image
from dashboard_visual import _vector_icon
from forecast_ui import open_overtime_simulator
from kalkulator_wynagrodzenia import App, DEFAULT
from pathlib import Path


class UiPolishV625Tests(unittest.TestCase):
    def test_icon_moon_and_plane_antialiased(self):
        for icon in ('moon', 'plane'):
            artwork = _vector_icon(icon, 32, '#f5bf48')
            self.assertEqual(artwork.size, (32, 32))
            self.assertGreater(artwork.getchannel('A').getbbox()[2], 12)
            self.assertGreater(artwork.getchannel('A').getbbox()[3], 12)

    def test_light_banner_present_dark_unchanged(self):
        folder = Path(__file__).resolve().parents[1]
        a = Image.open(folder/'marine_header.jpg')
        b = Image.open(folder/'marine_header_light.jpg')
        self.assertGreater(a.width, 1800)
        self.assertGreater(b.width, 1800)
        self.assertNotEqual(a.getpixel((500,100)), b.getpixel((500,100)))

    def test_theme_choice_only_in_current_session(self):
        class Bare:
            theme_mode = 'dark'
            db = {'ui_theme':'dark'}
            page = 'Pulpit'
            def _apply_interface_theme(self): pass
            def draw_banner(self): pass
            def show(self, page): self.last_page = page
        app = Bare()
        with patch('kalkulator_wynagrodzenia.save') as save:
            App.set_interface_theme(app, 'light')
        self.assertEqual(app.theme_mode, 'light')
        self.assertEqual(app.db['ui_theme'], 'dark')
        save.assert_not_called()

    def test_month_buttons_separated_by_border_frames(self):
        root = tk.Tk()
        try:
            root.geometry('1000x700+0+0')
            parent = tk.Frame(root)
            parent.pack()
            root.update()
            class Bare:
                language='pl'
                theme_mode='dark'
                def tr(self, message):return message
            app=Bare()
            app.root=root
            app.month=tk.StringVar(root,value='2026-11')
            App.pick_month(app,parent)
            popup=next(w for w in root.winfo_children() if isinstance(w,tk.Toplevel))
            root.update()
            grid=next(w for w in popup.winfo_children() if isinstance(w,tk.Frame) and len(w.winfo_children())==12)
            cards=grid.winfo_children()
            self.assertEqual(len(cards),12)
            self.assertTrue(all(len(w.winfo_children())==1 and isinstance(w.winfo_children()[0],tk.Button) for w in cards))
            self.assertTrue(all(w.cget('bg').startswith('#') for w in cards))
        finally:
            root.destroy()

    def test_simulator_rows_wrap_label_and_entry(self):
        class Month:
            def get(self):return '2026-11'
        class MockApp:
            language='pl'
            theme_mode='dark'
            month=Month()
            db=dict(DEFAULT)
            def __init__(self,root):self.root=root
            def cfg_for_month(self,*args):return dict(self.db,salary=15588.78,offshore=230.,nominal=160.,social_ytd=200000.,ytd_tax_base=200000.,_tax_year=2026)
        root=tk.Tk()
        try:
            win=open_overtime_simulator(MockApp(root))
            root.update()
            def children(widget):
                for child in widget.winfo_children():
                    yield child
                    yield from children(child)
            stripes=[w for w in children(win) if isinstance(w,tk.Frame) and w.cget('bg') in ('#142f43','#1b394f')]
            self.assertEqual(len(stripes),9)
            for stripe in stripes:
                self.assertEqual(len([w for w in stripe.winfo_children() if isinstance(w,tk.Entry)]),1)
                self.assertEqual(len([w for w in stripe.winfo_children() if isinstance(w,tk.Label)]),1)
            win.destroy()
        finally:
            root.destroy()


if __name__=='__main__':unittest.main()
