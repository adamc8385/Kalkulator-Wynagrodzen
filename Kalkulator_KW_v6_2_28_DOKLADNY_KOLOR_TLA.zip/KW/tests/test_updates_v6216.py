"""Critical v6.2.16 regressions: calendar-only N; A/B hours from payroll ISO weeks (model revised v6.2.17)."""
import unittest
from kalkulator_wynagrodzenia import (DEFAULT, App, calc, accounting_month,
    nominal_for_calendar_month)
from forecast_tools import hypothetical_month_result, simulation_result
from payroll_export import payroll_sections
from payroll_rules import overtime_components
from leave_pay import estimate_monthly_variable_history

def card(date, n=0, a=0, b=0):
    return dict(date=date, N=n, A=a, B=b, PN=0., P=0., T=0.,
                work_type=1, file_id='test-source')

def config():
    return dict(DEFAULT, salary=15588.78, nominal=nominal_for_calendar_month(2026,10),
                social_limit=282600., social_ytd=0., ytd_tax_base=0., _tax_year=2026,
                ppe_auto_enabled=0, ppo_auto_enabled=0, benefits_in_social=0,
                edenred_benefit=0, luxmed_benefit=0, ppe_extra=0, other_deductions=0,
                costs=0, pit_relief=0)

class CalendarAndOvertime6216(unittest.TestCase):
    def test_n_is_calendar_nominal_ignores_source_n_and_missing_cards(self):
        cfg=config()
        self.assertEqual(calc([],cfg)[0]['N'],176)
        self.assertEqual(calc([card('2026-10-02',n=182)],cfg)[0]['N'],176)
        self.assertEqual(calc([card('2026-10-02',n=0)],cfg)[0]['N'],176)
        self.assertEqual(calc([card('2026-10-02',n=400)],cfg)[0]['N'],176)
        self.assertEqual(calc([card('2026-10-02',n=400)],cfg)[4],cfg['salary'])

    def test_a_and_b_use_calendar_rate_base_plus_premiums(self):
        cfg=config()
        rows=[card('2026-09-28', n=182, a=31, b=11)]
        result=calc(rows,cfg)
        self.assertEqual(result[2],88.57)
        self.assertEqual(result[0]['A'],31)
        self.assertEqual(result[0]['B'],11)
        self.assertEqual(result[0]['N'],176)
        self.assertEqual(result[3],6067.20)
        self.assertEqual(result[4],21655.98)
        self.assertEqual(overtime_components(rows,lambda _:result[2])['all_base'],3719.94)
        self.assertEqual(overtime_components(rows,lambda _:result[2])['premium_a'],1372.99)
        self.assertEqual(overtime_components(rows,lambda _:result[2])['premium_b'],974.27)

    def test_company_weeks_shift_a_b_but_not_nominal(self):
        class Month:
            def get(self):return '2026-10'
        app=App.__new__(App)
        app.month=Month()
        app.db=dict(DEFAULT,rows=[card('2026-09-27',n=9,a=999),
                                  card('2026-09-28',n=9,a=1),
                                  card('2026-10-14',n=170,a=2,b=3),
                                  card('2026-11-01',n=9,b=4),
                                  card('2026-11-02',n=9,b=999)],excluded_files=[])
        rows=app.current()
        self.assertEqual(len(rows),3)
        self.assertEqual(calc(rows,config())[0]['N'],176)
        self.assertEqual(calc(rows,config())[0]['A'],3)
        self.assertEqual(calc(rows,config())[0]['B'],7)
        app.db['calendars']={'2026':{'10':[41]}}
        self.assertEqual(len(app.current()),0)
        self.assertEqual(nominal_for_calendar_month(2026,10,app.db),176)

    def test_payroll_report_has_n_calendar_and_payslip_overtime_base(self):
        cfg=config()
        rows=[card('2026-10-14', n=182, a=31, b=11)]
        result=calc(rows,cfg)
        from kalkulator_wynagrodzenia import payroll_breakdown
        sections=payroll_sections('2026-10',rows,cfg,result,payroll_breakdown(rows,cfg,result))
        first=dict((name,value) for name,value,unit in sections[0][1])
        self.assertEqual(first['Nominał N — kalendarz miesiąca'],176)
        second=dict((name,value) for name,value,unit in sections[1][1])
        self.assertEqual(second['1700 — Wynagrodzenie za nadgodziny 100%'],3719.94)
        self.assertEqual(second['1711 — Nadgodziny A — dodatek 50%'],1372.99)
        self.assertEqual(second['1721 — Nadgodziny B — dodatek 100%'],974.27)

    def test_scenario_ignores_card_n_and_uses_a_b(self):
        cfg=config()
        scenario=hypothetical_month_result('2026-10',cfg,calc,31,11,0)
        self.assertEqual(scenario['result'][0]['N'],176)
        self.assertEqual(scenario['result'][3],6067.20)
        self.assertEqual(simulation_result([card('2026-10-14',n=182)],cfg,calc,1,0,date='2026-10-14')['difference_gross'],132.86)

    def test_estimated_leave_variable_consistent_with_full_overtime(self):
        rows=[card('2026-10-14',n=182,a=31,b=11)]
        info=estimate_monthly_variable_history(rows,lambda _: '2026-10',lambda _:config())
        self.assertEqual(info['2026-10']['paid_variable_gross'],6067.20)
        self.assertEqual(info['2026-10']['component_breakdown']['overtime_base'],3719.94)
        self.assertEqual(info['2026-10']['normal_work_hours'],182)  # actual performed hours only; not payroll nominal

if __name__=='__main__': unittest.main()
