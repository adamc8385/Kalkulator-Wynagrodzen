"""Run from the ACH/KW folder: python -m unittest discover -s tests -v."""
import copy
import datetime as dt
import math
import unittest

from forecast_tools import simulation_result, yearly_projection, validate_cards
from kalkulator_wynagrodzenia import calc, accounting_month, DEFAULT, nominal_for_calendar_month


def cfg(year,month):
    base = dict(DEFAULT)
    base.update(salary=15588.78, offshore=220, nominal=nominal_for_calendar_month(year,month),
                social_limit=282600, ytd_tax_base=0, social_ytd=0, costs=300,
                _tax_year=year, _leave_variable_pay=0.0)
    return base


class TestScenario(unittest.TestCase):
    def setUp(self):
        self.rows = [{'date':'2026-09-15','N':8.0,'A':3.0,'B':1.0,
                      'PN':0.0,'P':0.0,'T':0.0,'work_type':1,'file_id':'f1'}]
        self.cfg = cfg(2026,9)

    def test_calculations_unchanged_with_zero_extra(self):
        before = calc(self.rows, self.cfg)
        result = simulation_result(self.rows,self.cfg,calc,0,0,date='2026-09-15')
        self.assertEqual(result['base'],before)
        self.assertEqual(result['new'],before)
        self.assertEqual(result['difference_net'],0.0)

    def test_new_hours_are_never_saved(self):
        rows_before = copy.deepcopy(self.rows)
        cfg_before = copy.deepcopy(self.cfg)
        out = simulation_result(self.rows,self.cfg,calc,10,5,date='2026-09-15')
        self.assertEqual(self.rows,rows_before)
        self.assertEqual(self.cfg,cfg_before)
        self.assertEqual(out['new'][0]['A'],13)
        self.assertEqual(out['new'][0]['B'],6)
        self.assertGreater(out['difference_gross'],0)

    def test_scenario_bounds(self):
        for a,b in ((float('nan'),0),(float('inf'),0),(-1,2),(201,1),(200,200)):
            with self.assertRaises(ValueError):
                simulation_result(self.rows,self.cfg,calc,a,b,date='2026-09-15')

    def test_yearly_excludes_one_offs_in_unrecorded_future(self):
        db = {'rows': [],'excluded_files': [],'payslip_balances': {}}
        def config_for(period,_skip_progress=True):
            y,m=map(int,period.split('-'))
            values=cfg(y,m)
            values.update(car_bonus_count=3, shared_room_nights=4,
                          risk_days=2, other_gross=1000,
                          ppe_employer_override=0, ppo_employer_override=0)
            return values
        out=yearly_projection(2026,db,config_for,calc,accounting_month,
                              today=dt.date(2026,11,8))
        self.assertEqual(len(out),12)
        self.assertEqual(out[-1]['status'],'Przyszły — baza')
        self.assertEqual(out[-1]['result'][4],15588.78)
        # Current/past months retain unverified inputs and are clearly labelled.
        self.assertEqual(out[0]['status'],'Bez kart — baza')
        self.assertEqual(out[0]['result'][4],15588.78+3*400+4*100+2*230+1000)
        self.assertEqual(db,{'rows': [],'excluded_files': [],'payslip_balances': {}})

    def test_card_warnings_do_not_mutate(self):
        db={'rows':[dict(self.rows[0],row=14,file='sample.xlsx'),
                    dict(self.rows[0],row=14,file='sample.xlsx')],
            'excluded_files': []}
        before=copy.deepcopy(db)
        report=validate_cards(db,accounting_month)
        self.assertEqual(db,before)
        self.assertEqual(report['active_rows'],2)
        self.assertGreater(report['errors']+report['warnings'],0)

    def test_excluded_card_not_analyzed(self):
        db={'rows':[dict(self.rows[0],row=14,file='sample.xlsx')],
            'excluded_files':['f1']}
        report=validate_cards(db,accounting_month)
        self.assertEqual(report['active_rows'],0)


if __name__=='__main__':
    unittest.main()
