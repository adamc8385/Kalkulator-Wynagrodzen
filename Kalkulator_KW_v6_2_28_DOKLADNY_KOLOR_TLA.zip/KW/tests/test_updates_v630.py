"""Integration coverage for v6.2.10: Excel time formats, A1 type 2, UI."""
import datetime as dt
import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch
from xml.sax.saxutils import escape
from zipfile import ZipFile
from tkinter import ttk

from a1_audit import a1_audit
from forecast_tools import validate_cards
from forecast_ui import open_card_check
from kalkulator_wynagrodzenia import read_xlsx
from night_work import expected_day_entries, interval_minutes, source_clocks


def xlsx_card(path, *, time_fmt='hh:mm', style=True, builtin=False):
    day=(dt.date(2026,1,6)-dt.date(1899,12,30)).days
    times=[('2026-01-06', day, 12/24, 0.,8,2,2,2,14),
           ('2026-01-07', day+1, 12/24,18/24,6,0,0,0,17),
           ('2026-01-07', None,18/24,0.,2,2,2,2,18),
           ('2026-01-08', day+2,11/24,18/24,7,0,0,0,20),
           ('2026-01-08', None,18/24,23/24,1,3,1,1,21)]
    def cell(k,v,row):
        if v is None:return ''
        if isinstance(v,str):return f'<c r="{k}{row}" t="inlineStr"><is><t>{escape(v)}</t></is></c>'
        sf=' s="1"' if (style and k in ('D','E')) else ''
        return f'<c r="{k}{row}"{sf}><v>{v}</v></c>'
    rs=[]
    for _date,serial, start,end,n,a,b,pn,num in times:
        vals={'C':serial,'D':start,'E':end,'G':n,'H':a,'I':b,'J':pn,
              'N':1,'O':'NIE','P':'Polska','Q':'Praca na statku'}
        rs.append(f'<row r="{num}">'+''.join(cell(k,v,num) for k,v in vals.items())+'</row>')
    xml='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+''.join(rs)+'</sheetData></worksheet>'
    with ZipFile(path,'w') as f:
        f.writestr('xl/worksheets/sheet1.xml',xml)
        fmt_id=20 if builtin else 164
        formats=(f'<numFmts count="1"><numFmt numFmtId="164" formatCode="{time_fmt}"/></numFmts>' if not builtin else '')
        st=(f'<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">{formats}'
            f'<cellXfs count="2"><xf numFmtId="0"/><xf numFmtId="{fmt_id}"/></cellXfs></styleSheet>')
        f.writestr('xl/styles.xml',st)


def row(day,country='',kind=None,travel=0, normal=0, idx=14):
    return {'date':day,'country':country,'work_type':kind,'P':float(travel),
            'T':0.,'N':float(normal),'A':0.,'B':0.,'PN':0.,'row':idx,
            'file':'card.xlsx','file_id':day+'_'+str(idx)}


class ExcelClockParsing630(unittest.TestCase):
    def test_custom_style_numeric_serials_and_overnight(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'Chrapkowski KP02.xlsx'
            xlsx_card(path)
            rows=read_xlsx(path)
            self.assertEqual(len(rows),5)
            self.assertTrue(all(r['work_clock_source']=='excel_time_style' for r in rows))
            self.assertEqual(interval_minutes(rows[0]),(720,1440))
            self.assertEqual(interval_minutes(rows[2]),(1080,1440))
            for r in rows:
                r.update(file_id='a',file='Chrapkowski KP02.xlsx',source_path=str(path))
            report=validate_cards({'rows':rows,'excluded_files':[]},lambda *_: '2026-01',
                                  read_source=read_xlsx,year=2026)
            self.assertEqual(report['unchecked_clock_rows'],0)
            messages=' | '.join(i['message'] for i in report['issues'])
            self.assertNotIn('PN podano bez',messages)
            self.assertNotIn('Kolumna PN:',messages)
            self.assertNotIn('Kolumna N:',messages)
            self.assertNotIn('Kolumna A:',messages)
            self.assertNotIn('Kolumna B:',messages)

    def test_builtin_time_format_supported(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'card.xlsx';xlsx_card(path,builtin=True)
            self.assertEqual(read_xlsx(path)[0]['work_clock_source'],'excel_time_style')

    def test_no_clock_style_numeric_is_not_guessed(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'card.xlsx';xlsx_card(path,style=False)
            self.assertIsNone(interval_minutes(read_xlsx(path)[0]))

    def test_non_clock_format_does_not_authorize_numeric(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'card.xlsx';xlsx_card(path,time_fmt='#,##0.00')
            self.assertIsNone(interval_minutes(read_xlsx(path)[0]))

    def test_wrong_pn_split_not_flagged_after_user_disabled_it(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'card.xlsx';xlsx_card(path)
            rows=read_xlsx(path)
            rows[0]['PN']=1.
            for r in rows:r.update(file_id='a',file='Chrapkowski KP02.xlsx')
            result=validate_cards({'rows':rows,'excluded_files':[]},lambda *_:'2026-01',year=2026)
            self.assertFalse(any('Kolumna PN:' in x['message'] for x in result['issues']))
            self.assertFalse(any('PN podano bez' in x['message'] for x in result['issues']))

    def test_time_role_unverified_numeric_is_ambiguous(self):
        self.assertIsNone(source_clocks({'D':'0.5','E':'0'}, {}, {'D':True,'E':False}))

    def test_travel_type_two_is_not_a_shift(self):
        r={'file_id':1,'date':'2026-01-07','work_type':2,'N':0.,'A':0.,'B':0.,'PN':0.,
           'P':3.,'T':0.,'work_start_raw':'16:00','work_end_raw':'20:00',
           'work_clock_source':'literal'}
        self.assertNotIn(id(r),expected_day_entries([r]))


class A1TravelTwo630(unittest.TestCase):
    def test_explicit_return_after_type_two_on_friday(self):
        cards=[row('2026-10-07','USA',1,normal=8),row('2026-10-08','USA',1,normal=8),
               row('2026-10-09','USA',2),row('2026-10-12','Polska',5)]
        result=a1_audit(cards,dt.date(2026,10,7),dt.date(2026,10,12))
        self.assertEqual(result['inferred'][dt.date(2026,10,10)],'Polska')
        self.assertEqual(result['inferred'][dt.date(2026,10,11)],'Polska')

    def test_type_two_foreign_destination_after_polish_weekend(self):
        cards=[row('2026-10-09','Polska',5),row('2026-10-12','USA',2)]
        result=a1_audit(cards,dt.date(2026,10,9),dt.date(2026,10,12))
        self.assertEqual(result['inferred'][dt.date(2026,10,10)],'Polska')
        self.assertEqual(result['inferred'][dt.date(2026,10,11)],'Polska')

    def test_type_two_without_destination_does_not_imply_poland(self):
        cards=[row('2026-10-09','USA',2),row('2026-10-12','',None)]
        result=a1_audit(cards,dt.date(2026,10,9),dt.date(2026,10,12))
        self.assertNotIn(dt.date(2026,10,10),result['inferred'])
        self.assertNotIn(dt.date(2026,10,11),result['inferred'])

    def test_two_travel_endpoints_country_still_ambiguous(self):
        cards=[row('2026-10-09','USA',2),row('2026-10-12','USA',2)]
        result=a1_audit(cards,dt.date(2026,10,9),dt.date(2026,10,12))
        self.assertEqual(result['unresolved'],2)


class Window630(unittest.TestCase):
    def test_validation_window_has_real_horizontal_scroll_and_centered_headers(self):
        root=tk.Tk();root.geometry('1080x740+0+0');root.update()
        class App: pass
        app=App();app.root=root;app.db={};app.language='pl'
        long_issue='Opis problemu '*40
        dummy={'year':2026,'active_rows':1,'errors':0,'warnings':1,
               'unchecked_clock_rows':0,
               'issues':[{'level':'UWAGA','date':'2026-01-06','file':'test.xlsx','row':14,
                          'message':long_issue,'source_path':''}]}
        try:
            with patch('forecast_ui.validate_cards',return_value=dummy):
                w=open_card_check(app)
            w.update()
            tree=next(widget for widget in w.winfo_children()
                      for widget in widget.winfo_children() if isinstance(widget,ttk.Treeview))
            horiz=[c for c in tree.master.winfo_children()
                   if isinstance(c,ttk.Scrollbar) and str(c.cget('orient'))=='horizontal']
            self.assertEqual(len(horiz),1)
            self.assertTrue(str(tree.cget('xscrollcommand')))
            self.assertLess(tree.xview()[1],1.)
            tree.xview_moveto(1.)
            w.update()
            self.assertGreater(tree.xview()[0],0.)
            for col in ('level','date','file','row','description'):
                self.assertEqual(str(tree.heading(col,'anchor')),'center')
            self.assertEqual(tree.heading('row','text'),'Wiersz Excel')
        finally:
            root.destroy()

    def test_payroll_reminder_schedules_dark_native_caption(self):
        import datetime as _dt
        from kalkulator_wynagrodzenia import App
        root=tk.Tk();root.geometry('900x650+0+0');root.update()
        class StubDate(_dt.date):
            @classmethod
            def today(cls):return cls(2026,11,10)
        app=App.__new__(App);app.root=root;app.db={'hide_reminder_forever':False}
        app.language='pl';app.month=tk.StringVar(master=root,value='2026-11')
        app.label=lambda parent,text,*args,**kw:tk.Label(parent,text=text)
        app.button=lambda parent,text,cb,*args:tk.Button(parent,text=text,command=cb)
        try:
            with patch('kalkulator_wynagrodzenia.dt.date',StubDate),patch('ui_assets.set_navy_titlebar') as bar:
                app.show_monthly_payroll_reminder();root.update()
                bar.assert_called_once()
                self.assertEqual(bar.call_args.kwargs['background'],'#081725')
                self.assertEqual(bar.call_args.kwargs['foreground'],'#f2f6f9')
        finally:root.destroy()


if __name__=='__main__':unittest.main()
