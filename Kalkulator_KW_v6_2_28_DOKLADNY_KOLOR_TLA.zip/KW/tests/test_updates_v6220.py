"""Visual and accounting regressions in 6.2.20."""
import datetime as dt
import unittest
import tkinter as tk
from unittest.mock import patch
from a1_audit import a1_audit
from ui_theme import apply_tree, register_popup
from kalkulator_wynagrodzenia import nominal_for_calendar_month


def card(day,kind=5, country='', **kwargs):
    row=dict(date=day,work_type=kind,country=country,N=0,A=0,B=0,PN=0,P=0,T=0,
             job='',file='test.xlsx',file_id=day,row=10)
    row.update(kwargs)
    return row

class WeekendRegression(unittest.TestCase):
    def test_blank_country_source_rows_on_2026_polish_free_weekend(self):
        rows=[card('2026-07-17',5,'Polska'),card('2026-07-18',1),card('2026-07-19',1)]
        r=a1_audit(rows,dt.date(2026,7,17),dt.date(2026,7,19))
        self.assertEqual(r['missing'],{})
        self.assertEqual(r['poland'],3)
        self.assertEqual(r['inferred'][dt.date(2026,7,18)],'Polska')
        self.assertEqual(r['inferred'][dt.date(2026,7,19)],'Polska')

    def test_worked_weekend_no_country_still_requires_review(self):
        r=a1_audit([card('2026-07-18',1,N=8)],dt.date(2026,7,18),dt.date(2026,7,18))
        self.assertIn(dt.date(2026,7,18),r['missing'])

    def test_foreign_weekend_is_not_poland(self):
        rows=[card('2026-07-17',1,'Włochy',N=8),card('2026-07-18',1),card('2026-07-19',1),
              card('2026-07-20',1,'Włochy',N=8)]
        r=a1_audit(rows,dt.date(2026,7,17),dt.date(2026,7,20))
        self.assertEqual(r['foreign'],4)
        self.assertEqual(r['poland'],0)

class ThemeRegression(unittest.TestCase):
    def test_light_dark_reversible_preserves_white_entries(self):
        root=tk.Tk();root.withdraw()
        try:
            frame=tk.Frame(root,bg='#081725');frame.pack()
            label=tk.Label(frame,text='Test',bg='#10293c',fg='#f2f6f9');label.pack()
            field=tk.Entry(frame,bg='#ffffff',fg='#172e40');field.pack()
            apply_tree(root,'light')
            self.assertEqual(label.cget('bg'),'#ffffff')
            self.assertEqual(field.cget('bg'),'#ffffff')
            self.assertEqual(field.cget('fg'),'#172e40')
            apply_tree(root,'dark')
            self.assertEqual(label.cget('bg'),'#10293c')
        finally:root.destroy()

    def test_popup_unified_surface_and_button_maintains_contrast(self):
        root=tk.Tk();root.withdraw()
        class App:pass
        app=App();app.root=root;app.theme_mode='dark'
        popup=tk.Toplevel(root)
        try:
            popup.configure(bg='#081725')
            frame=tk.Frame(popup,bg='#10293c');frame.pack()
            button=tk.Button(frame,text='Zamknij',bg='#193a51',fg='#f2f6f9');button.pack()
            apply_tree(popup,'dark',popup=True)
            self.assertEqual(popup.cget('bg'),'#10293c')
            self.assertEqual(frame.cget('bg'),'#10293c')
            self.assertNotEqual(button.cget('bg'),popup.cget('bg'))
            self.assertEqual(button.cget('fg'),'#f2f6f9')
        finally:popup.destroy();root.destroy()

    def test_calendar_nominal_unaffected(self):
        self.assertEqual(nominal_for_calendar_month(2026,10,{}),176)

if __name__=='__main__':unittest.main()
