"""Unverified old defaults are not silently used as confirmed monthly YTD balances."""
import unittest
from tax_progress import opening_balances
from payroll_rules import cent
from kalkulator_wynagrodzenia import nominal_for_calendar_month

class PartialPayslipBalance6217(unittest.TestCase):
    def test_only_social_anchor_does_not_make_up_pit(self):
        db={'rows':[],'excluded_files':[], 'payslip_balances':{
            '2026-09':{'social':273070.50}}}
        r=opening_balances(db,'2026-10',lambda _month:{'salary':0,'nominal':0},
                           lambda rows,cfg:None,lambda date,db:None)
        self.assertEqual(r['social'],273070.50)
        self.assertEqual(r['tax'],0.0)
        self.assertTrue(r['missing_months'])
    def test_only_tax_anchor_does_not_make_up_social(self):
        db={'rows':[], 'payslip_balances':{'2026-09':{'tax':238031.00}}}
        r=opening_balances(db,'2026-10',lambda _month:{'salary':0,'nominal':0},
                           lambda rows,cfg:None,lambda date,db:None)
        self.assertEqual(r['social'],0.0)
        self.assertEqual(r['tax'],238031.00)
    def test_both_balances_reconcile_without_history(self):
        db={'rows':[], 'payslip_balances':{'2026-09':{'social':273070.50,'tax':238031.00}}}
        r=opening_balances(db,'2026-10',lambda _month:{'salary':0,'nominal':0},
                           lambda rows,cfg:None,lambda date,db:None)
        self.assertEqual(r['social'],273070.50)
        self.assertEqual(r['tax'],238031.00)
        self.assertEqual(r['missing_months'],[])

if __name__=='__main__':unittest.main()
