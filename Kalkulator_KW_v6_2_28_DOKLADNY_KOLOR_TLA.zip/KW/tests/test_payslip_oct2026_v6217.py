"""Regression: October 2026 payslip's gross-pay and ZUS structure.

The synthetic rows reproduce the supplied *totals*, not the user's actual
work cards. Therefore they verify accounting arithmetic but not whether the
source cards contain 39.5 A or 24.5 eligible travel hours.
"""
import unittest
from kalkulator_wynagrodzenia import DEFAULT, calc, payroll_breakdown, nominal_for_calendar_month,travel_bonus
from payroll_rules import overtime_components
from payroll_export import payroll_sections
from leave_pay import estimate_monthly_variable_history


def row(day, **data):
    record={'date':day,'N':0,'A':0,'B':0,'P':0,'T':0,'PN':0,
            'work_type':1,'file_id':'synthetic-test'}
    record.update(data)
    return record


def october_cfg():
    return dict(DEFAULT, salary=15588.78, offshore=230., edenred_benefit=150., luxmed_benefit=547.90, benefits_in_social=1, ppe_auto_enabled=1, ppo_auto_enabled=1, ppe_extra=150., costs=300., pit_relief=300.,
                nominal=nominal_for_calendar_month(2026,10),
                social_limit=282600.0,
                # INFERRED from October 2026 pension contribution 930.08 PLN;
                # never silently copy this value into user's real database.
                social_ytd=273070.50, ytd_tax_base=238031.,
                domestic_diet_extra_days=3, _tax_year=2026)


class OctoberPayslip6217(unittest.TestCase):
    def test_october_confirmed_hours_and_pay_components(self):
        cfg=october_cfg()
        rows=[row('2026-10-05',N=182,A=39.5,B=10),
              row('2026-10-03',T=12.),row('2026-10-04',T=12.5)]
        rows.extend(row(d,work_type=9) for d in
                    ('2026-10-12','2026-10-13','2026-10-14'))
        over=overtime_components(rows,lambda _day:88.57)
        self.assertEqual(cfg['nominal'],176)
        self.assertEqual(over['all_base'],4384.22)  # code 1700
        self.assertEqual(over['premium_a'],1749.46)  # code 1711
        self.assertEqual(over['premium_b'],885.70)  # code 1721
        self.assertEqual(travel_bonus(rows,cfg),1085.11)
        result=calc(rows,cfg)
        self.assertEqual(result[0]['N'],176)  # NEVER use 182 from cards
        self.assertEqual(result[4],24548.27)  # EXACT cash gross from payslip
        details=payroll_breakdown(rows,cfg,result)
        self.assertEqual(details['emerytalna'],930.08)
        self.assertEqual(details['rentowa'],142.94)
        self.assertEqual(details['chorobowa'],618.53)
        self.assertEqual(details['zdrowotna'],2119.92)
        # Difference 1 PLN PIT vs supplied payslip remains unexplained.
        self.assertEqual(result[8],7464)
        self.assertEqual(result[10],13122.80)
        section=payroll_sections('2026-10',rows,cfg,result,details)
        pay={name:amount for name,amount,_unit in section[1][1]}
        self.assertEqual(pay['1700 — Wynagrodzenie za nadgodziny 100%'],4384.22)
        self.assertEqual(pay['1711 — Nadgodziny A — dodatek 50%'],1749.46)
        self.assertEqual(pay['1721 — Nadgodziny B — dodatek 100%'],885.70)
        self.assertEqual(pay['1746 — Dodatek do diety'],165.)

    def test_no_automatic_diet_invented_from_offshore_or_cards(self):
        cfg=october_cfg(); cfg['domestic_diet_extra_days']=0
        rows=[row('2026-10-05',A=1),row('2026-10-12',work_type=9)]
        first=calc(rows,cfg)[4]
        cfg['domestic_diet_extra_days']=3
        self.assertEqual(calc(rows,cfg)[4]-first,165.)

    def test_leave_history_uses_base_and_premiums(self):
        rows=[row('2026-10-14',N=200,A=39.5,B=10)]
        history=estimate_monthly_variable_history(rows,lambda _: '2026-10',lambda _:october_cfg())
        self.assertEqual(history['2026-10']['paid_variable_gross'],7019.38)
        self.assertEqual(history['2026-10']['component_breakdown']['overtime_base'],4384.22)

    def test_prior_anchors_are_required_for_exact_pension(self):
        cfg=october_cfg(); rows=[row('2026-10-05',A=39.5,B=10)]
        cfg['social_ytd']=266640.34  # obsolete prior estimate
        old=payroll_breakdown(rows,cfg)
        cfg['social_ytd']=273070.50  # inferred from real Oct slip
        new=payroll_breakdown(rows,cfg)
        self.assertNotEqual(old['emerytalna'],new['emerytalna'])


if __name__=='__main__': unittest.main()
