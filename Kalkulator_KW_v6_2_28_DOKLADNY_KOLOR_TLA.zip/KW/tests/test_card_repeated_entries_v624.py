"""Regression: repeating legitimate work attributes is not a validation warning."""
import copy
import unittest
from forecast_tools import validate_cards


def row(line, *, date='2026-09-28', hour=8, work_type=1,
        name='Chrapkowski KP40.xlsx', install='Installation A'):
    return {'file_id': 'same-file', 'source_path': '', 'file': name,
            'date': date, 'row': line, 'N': hour, 'A': 0., 'B': 0.,
            'PN': 0., 'P': 0., 'T': 0., 'work_type': work_type,
            'work_type_raw': str(work_type), 'sea_work_raw': 'NIE',
            'job': install, 'country': 'Polska'}


class RepeatingWorkIsNotADuplicate(unittest.TestCase):
    def validate(self, rows):
        db = {'rows': rows, 'excluded_files': []}
        original = copy.deepcopy(db)
        result = validate_cards(db, lambda day, _db: day[:7])
        self.assertEqual(db, original, 'Validator must be read-only')
        return result

    def test_same_day_same_hours_same_installation_are_permitted(self):
        result = self.validate([row(14), row(15)])
        self.assertEqual(result['errors'], 0)
        self.assertEqual(result['warnings'], 0)
        self.assertFalse(any('duplikat' in item['message'].lower()
                             for item in result['issues']))

    def test_repetition_over_multiple_days_is_permitted(self):
        result = self.validate([row(14, date='2026-09-28'),
                                row(15, date='2026-09-29')])
        self.assertEqual(result['errors'], 0)
        self.assertEqual(result['warnings'], 0)

    def test_real_incorrect_week_is_still_reported(self):
        result = self.validate([row(14, name='Chrapkowski KP11.xlsx')])
        self.assertTrue(any('nazwa karty wskazuje KP11' in i['message']
                            for i in result['issues']))

    def test_missing_hours_workday_still_reported(self):
        result = self.validate([row(14, hour=0)])
        self.assertTrue(any('Brak wpisanych godzin' in i['message']
                            for i in result['issues']))


if __name__ == '__main__':
    unittest.main()
