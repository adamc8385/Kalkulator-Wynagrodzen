"""v6.2.12 regression: standalone simulation, fixed travel premium, report export."""
import copy
import tempfile
import unittest
from pathlib import Path

from kalkulator_wynagrodzenia import DEFAULT, App, calc, payroll_breakdown, nominal_for_calendar_month
from forecast_tools import hypothetical_month_result
from payroll_export import export_month_excel, payroll_sections


class Changes6212(unittest.TestCase):
    def setUp(self):
        self.cfg = dict(DEFAULT)
        self.cfg['salary']=15588.78
        self.cfg.update(nominal=nominal_for_calendar_month(2026, 10),
                        social_ytd=0., ytd_tax_base=0., _tax_year=2026)

    def test_full_independent_scenario(self):
        value = hypothetical_month_result('2026-10', self.cfg, calc, 40, 20, 10)
        self.assertEqual(value['result'][0]['N'], 176)
        self.assertEqual(value['result'][0]['A'], 40)
        self.assertEqual(value['result'][0]['B'], 20)
        self.assertEqual(value['result'][0]['T'], 10)
        self.assertEqual(value['a'], 40)
        self.assertGreater(value['result'][10], 0)

    def test_no_mutation(self):
        original = copy.deepcopy(self.cfg)
        hypothetical_month_result('2026-10', self.cfg, calc, 10, 5, 3)
        self.assertEqual(self.cfg, original)

    def test_zero_overtime_travel(self):
        case = hypothetical_month_result('2026-10', self.cfg, calc, 0, 0, 0)
        self.assertEqual(case['result'][0]['T'], 0)
        self.assertAlmostEqual(case['result'][4], self.cfg['salary'])

    def test_travel_is_paid_not_deducted(self):
        from kalkulator_wynagrodzenia import travel_breakdown, travel_bonus
        case = hypothetical_month_result('2026-10', self.cfg, calc, 40, 20, 10)
        self.assertEqual(sum(v[2] for v in travel_breakdown(case['rows']).values()), 10)
        self.assertEqual(travel_bonus(case['rows'], case['cfg']), 442.90)  # hourly 50% rounded to 0.01 before multiplying

    def test_bad_scenario_values(self):
        for x in (-1, 501, float('nan'), float('inf')):
            with self.assertRaises(ValueError):
                hypothetical_month_result('2026-10', self.cfg, calc, x, 10, 10)

    def test_travel_rate_migrated_in_effective_2026_config(self):
        class Month:
            def get(self): return '2026-10'
        app=App.__new__(App)
        app.db=dict(self.cfg,travel_rate=0.0,monthly_settings_history={})
        app.month=Month()
        app._month_cfg_cache={}
        app._month_cfg_revision=0
        effective=app.cfg_for_month('2026-10',_skip_progress=True)
        self.assertEqual(effective['travel_rate'],0.5)
        self.assertEqual(app.db['travel_rate'],0.)

    def test_history_rate_unchanged_for_2024(self):
        class Month:
            def get(self):return '2024-10'
        app=App.__new__(App)
        app.db=dict(self.cfg,travel_rate=0.0,monthly_settings_history={})
        app.month=Month()
        app._month_cfg_cache={};app._month_cfg_revision=0
        self.assertEqual(app.cfg_for_month('2024-10',_skip_progress=True)['travel_rate'],0.0)

    def test_excel_report_contains_summary_and_qualified_numbers(self):
        from openpyxl import load_workbook
        case=hypothetical_month_result('2026-10',self.cfg,calc,40,20,10)
        deductions=payroll_breakdown(case['rows'],case['cfg'],case['result'])
        sections=payroll_sections('2026-10',case['rows'],case['cfg'],case['result'],deductions,'Engineer')
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/'test.xlsx'
            export_month_excel(file,'2026-10',sections,'Engineer')
            wb=load_workbook(file,data_only=False)
            values=[cell.value for row in wb.active for cell in row]
            self.assertIn('PROGNOZA PRZELEWU NETTO',values)
            self.assertIn('IV. ŚWIADCZENIA POZAPŁACOWE (POZA PRZELEWEM)',values)
            self.assertTrue(any(isinstance(v,float) and v==case['result'][10] for v in values))

    def test_pdf_report_generates(self):
        from forecast_pdf import export_month_pdf
        case=hypothetical_month_result('2026-10',self.cfg,calc,40,20,10)
        d=payroll_breakdown(case['rows'],case['cfg'],case['result'])
        sections=payroll_sections('2026-10',case['rows'],case['cfg'],case['result'],d)
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'test.pdf'
            export_month_pdf(file,'2026-10',case['rows'],case['cfg'],case['result'],d,
                             detailed_sections=sections)
            self.assertTrue(file.read_bytes().startswith(b'%PDF-'))

    def test_removed_check_duplicate_but_validation_tool_remains(self):
        from pathlib import Path
        src=(Path(__file__).resolve().parents[1]/'forecast_ui.py').read_text('utf-8')
        actions=src[src.index('def attach_preview_tools'):src.index('def attach_card_validation')]
        self.assertNotIn("'Sprawdź karty'",actions)
        self.assertIn('open_card_check(app)',src[src.index('def attach_card_validation'):])

    def test_settings_horizontal_scroll_logic_present(self):
        from pathlib import Path
        src=(Path(__file__).resolve().parents[1]/'kalkulator_wynagrodzenia.py').read_text('utf-8')
        settings=src[src.index(' def show_settings'):src.index("  self.label(content,'USTAWIENIA WYNAGRODZENIA'")]
        self.assertIn("orient='horizontal',command=cv.xview",settings)
        self.assertIn('cv.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)',settings)

if __name__=='__main__': unittest.main()
