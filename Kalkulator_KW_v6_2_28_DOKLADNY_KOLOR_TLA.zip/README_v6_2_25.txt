KALKULATOR WYNAGRODZEN — v6.2.25

Zakres zmian: tylko prezentacja / interfejs ACH i KW:
- osobne banery trybu jasnego ze statkiem (ACH i KW ze swoimi znakami), oryginalny ciemny bez zmian,
- przy każdym uruchomieniu start w motywie ciemnym, mozliwosc przelaczenia na jasny w sesji,
- kratki rozdzielajace miesiace w wyborze miesiaca,
- oddzielne paski wierszy symulatora z polami po prawej,
- opoznione ponowne pomiary paska przewijania po zmianie zakladki (takze cache hit),
- ostry sierp ksiezyca i zloty samolot w podsumowaniu.

Zasady plac, PIT/ZUS, kalendarz firmowy, wpisy Excel nie zmienione.
Pakiety zawieraja kod, grafike i skrypty budowania EXE, nie gotowe EXE.
