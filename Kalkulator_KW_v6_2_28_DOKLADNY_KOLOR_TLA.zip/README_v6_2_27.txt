Kalkulator Wynagrodzeń ACH / KW v6.2.27

Kompletne foldery ACH i KW ze źródłami, grafikami, testami oraz skryptami
budowania EXE na komputerze Windows. Gotowe EXE nie są dołączone.

Wersja naprawia A1 dla pustego weekendu 18–19.07.2026 po polskim
piątku 17.07.2026, zawiera numer wersji na pasku Windows i poprawki
kolorystyki okien. Podsumowanie miesiąca pokazuje jeden wiersz podróży.

Budowanie pojedynczego EXE: ACH lub KW / ZBUDUJ_JEDEN_EXE.bat.
Przed zmianą wersji zabezpiecz lokalne dane użytkownika (dane.json).
