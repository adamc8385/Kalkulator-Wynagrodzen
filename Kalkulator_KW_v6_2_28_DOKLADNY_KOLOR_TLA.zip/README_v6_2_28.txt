Kalkulator Wynagrodzeń ACH / KW v6.2.28

W obu edycjach tła wskazanych okien dialogowych mają dokładnie kolor
#10293c (RGB 16,41,60), zgodny z istniejącym panelem głównym aplikacji.
Zmiana dotyczy: Historii urlopu (także pustego obszaru tabeli),
Ustawień bilansu urlopu, Wyboru miesiąca, Symulatora wynagrodzenia,
Rocznej prognozy wynagrodzeń oraz uzgadniania PIT/ZUS z paskiem.

Kratki miesięcy zachowane 1:1, osobne pasy w Symulatorze i uzgadnianiu
PIT/ZUS wyróżnione odcieniami z palety programu.
Rozliczenia, karty pracy, A1, dodatek C i ZFŚS bez zmian algorytmu.

Pełne archiwa zawierają źródła, zasoby graficzne, testy i skrypty budowania
na Windows. Gotowego pliku EXE nie dołączono.

Aby zbudować jeden samodzielny EXE, uruchom w folderze ACH lub KW:
ZBUDUJ_JEDEN_EXE.bat

Przed podmianą wersji zachowaj prywatną kopię lokalnego dane.json.
