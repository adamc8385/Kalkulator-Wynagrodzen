Kalkulator Wynagrodzeń ACH / KW v6.2.24

Archiwum zawiera kompletne pliki dwóch edycji programu: ACH oraz KW, a także zasoby graficzne, testy i skrypty do uruchomienia i budowania EXE.
NIE jest to gotowy EXE. Rozpakuj paczkę i użyj odpowiedniego skryptu BAT w folderze ACH lub KW.
Zmiany: bardziej kompaktowy Pulpit i Urlop; czytelniejsze ikony; poprawiony kalendarz w trybie jasnym; ciemny motyw zachowany.
Nie zmieniono sposobu naliczania wynagrodzeń.
