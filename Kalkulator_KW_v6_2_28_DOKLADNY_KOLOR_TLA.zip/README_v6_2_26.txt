KALKULATOR WYNAGRODZEŃ ACH / KW — v6.2.26

NAJWAŻNIEJSZE:
- Dodatek C i ZFŚS można wpisać w Ustawieniach po wybraniu miesiąca WYPŁATY.
- ZAPISZ USTAWIENIA zapisuje obie kwoty oddzielnie dla tego miesiąca.
- W Symulatorze są pola C i ZFŚS: Przelicz niczego nie zapisuje;
  osobny przycisk Zapisz C i ZFŚS zapisuje ręczne kwoty dla miesiąca.
- Dla danego miesiąca wartości zostają po restarcie, nie przechodzą na kolejne miesiące.
- Historia i eksport miesięcznych rozliczeń pokazują C i ZFŚS.
- Dodatek C brutto: zwykły składnik PIT, ZUS i zdrowotnej.
- ZFŚS: wyłącznie kwalifikujące się świadczenie pieniężne w całości finansowane
  z funduszu, przyznane według kryteriów socjalnych. 1000 PLN zwolnienia PIT
  w roku, nadwyżka podlega PIT (oraz progresji), ale nie ZUS i zdrowotnej.
  Zwolnienie roczne bazuje TYLKO na kwotach wprowadzonych w kalkulatorze;
  brak wcześniejszych wypłat może zaniżać prognozowany PIT.
- ZFŚS może być wypłacony osobnym przelewem; wynik obejmuje łączne pieniądze.
- Dane są LOCALNE, zapisane do dane.json; brak jakiejkolwiek chmury.
- Przed aktualizacją zachowaj kopię danych i porównaj rozliczenia z paskiem.

Pliki ZIP zawierają kod źródłowy, komplet grafik i skrypty budowania na Windows.
NIE zawierają gotowego EXE. Gotowy Windows EXE trzeba zbudować za pomocą
ZBUDUJ_JEDEN_EXE.bat lub ZBUDUJ_ACH_EXE.bat / ZBUDUJ_KW_EXE.bat.
Wersja GUI przetestowana na Linux/Xvfb, nie na Windows.
