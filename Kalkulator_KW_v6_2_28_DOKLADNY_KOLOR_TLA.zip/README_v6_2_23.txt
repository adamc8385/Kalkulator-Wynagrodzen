Kalkulator Wynagrodzeń ACH/KW v6.2.23 — korekta widoku Pulpit.
Przygotowane są dwie niezależne edycje, ACH i KW, oraz katalog WSPOLNY_RDZEN.
Wersja dostarcza źródła i skrypty budowania EXE; gotowe EXE nie są dołączone.
Zakres: jasny panel nawigacyjny w motywie jasnym, mniejsze kafelki w obu motywach.
Obliczenia i przechowywane dane nie były zmieniane.
