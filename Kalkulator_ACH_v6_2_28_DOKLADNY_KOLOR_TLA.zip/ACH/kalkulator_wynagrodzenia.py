"""Kalkulator Wynagrodzenia — lokalna aplikacja do kart pracy XLSX."""
from test_profile import prepare_isolated_profile
prepare_isolated_profile("ACH")
import ach_dialogs
ach_dialogs.install()
import calendar, copy, csv, datetime as dt, hashlib, json, math, os, posixpath, queue, re, sys, threading, zipfile
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from xml.etree import ElementTree as ET
from collections import defaultdict
from a1_audit import a1_audit
from app_version import LABEL as APP_VERSION_LABEL
from card_sync import scan_root, sync_cards
from sync_issues import show_sync_report, normalize_issues
from leave_pay import leave_hours_by_day, calculate_leave_pay, prior_months, estimate_monthly_variable_history
from leave_balance_ui import attach_leave_dashboard
from settings_history import PAYROLL_FIELDS, seed_baseline, active_month_version, save_month_version
from special_payments import FIELDS as SPECIAL_FIELDS, get_month as get_special_month, save_month as save_special_month, zfss_prior, zfss_tax_split
from zus_limits import annual_limit, source_for_year, fetch_official_limits, update_verified_cache, MissingAnnualLimit
from pathlib import Path
from work_card_policy import MIN_CARD_YEAR, supported_date, UnsupportedCardYear
from company_calendar import scheduled_hours, payroll_week_nominal, day_category, day_description, has_confirmed_company_schedule
from payroll_rules import cent, zloty, overtime_components, pension_employer_estimate, marginal_tax, bracket_name
from night_work import night_bonus_detail, source_clocks, time_column_roles
from tax_progress import opening_balances
from data_store import load_verified, save_atomic, DataIntegrityError
from PIL import Image, ImageTk, ImageDraw
from tkinter import font as tkfont
from ui_assets import image_photo, tinted_image_photo, dpi_scale
from ui_assets import schedule_navy_titlebar
from ui_theme import apply_tree as apply_ui_theme, apply_style as apply_ui_style, register_popup as theme_popup, update_caption
from month_index import build as build_month_index
from performance_log import initialize as init_performance_log, measure as performance_measure, monotonic as perf_monotonic, record_error as perf_record_error
from forecast_ui import attach_preview_tools, attach_card_validation
from dashboard_visual import metric_card, section_heading, icon_image

HOME=Path(os.environ['KW_DATA_DIR']).expanduser() if os.environ.get('KW_DATA_DIR','').strip() else Path.home()/'.kalkulator_wynagrodzenia'; DB=HOME/'dane.json'
NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
DEFAULT={'salary':15588.78,'offshore':230.,'travel_rate':0.5,'nominal':176,'auto_nominal':1.,'costs':300.,'pit_relief':300.,'pit_rate':12.,'ytd_tax_base':238031.,'social_ytd':266640.34,'social_limit':282600.,'social_limits_cache':{},'social_caps_last_checked':'','ppk':0.,'rows':[],'files':{},'folder':'','auto_root':'','auto_import':1,'language':'pl','calendars':{},'salary_history':{},'leave_variable_history':{},'monthly_settings_history':{},'monthly_special_payments':{},'hide_reminder_forever':False,'hide_sync_issues_forever':False,'last_sync_issues':[],'position':'Service Engineer','excluded_files':[],'ppe_extra':150.,'car_bonus_count':0,'shared_room_nights':0,'domestic_diet_extra_days':0,'risk_days':0,'risk_factor':1.,'other_gross':0.,'other_deductions':0.,'travel_mode':'P+T','offshore_manual_days':-1,'edenred_benefit':150.,'luxmed_benefit':547.90,'ppe_employer_reference':996.88,'ppo_employer_reference':142.41,'benefits_in_social':1.,'employer_pension_taxable':1.,'ppe_auto_enabled':1.,'ppo_auto_enabled':1.,'ppe_employer_override':0.,'ppo_employer_override':0.,'payslip_balances':{},'ui_theme':'dark'}
DATA_REVISION=0
def load():
 try:
  saved,recovered=load_verified(DB)
  if saved is None:saved={}
  if recovered:
   messagebox.showwarning('Odzyskano dane / Data recovered',
     ('Plik dane.json był uszkodzony. Wczytano poprawną kopię dane.json.bak. '
      'Przed kolejną aktualizacją sprawdź dane i zachowaj kopię obu plików.'),parent=None)
  # Migrate only values known to be defaults in v2.0; retain user custom values.
  if saved.get('costs')==250.:saved['costs']=300.
  # Migrate the old effectively-unlimited default to the 2026 statutory cap.
  if float(saved.get('social_limit',282600) or 0)>500000:saved['social_limit']=282600.
  merged={**DEFAULT,**saved}
  for row in merged.get('rows',[]):
   if 'work_type' not in row:
    row['needs_type_refresh']=True
    row['sea_work']=bool(row.get('offshore',False))
    row['work_type']=None
    row['offshore']=False
    row['offshore_travel']=False
    row['paid_day_off_hours']=0.
  seed_baseline(merged)
  # Never fabricate prior-month YTD contribution/tax anchors. In older
  # profiles, preserve user-recorded balances for manual reconciliation.
  merged.setdefault('payslip_balances',{})
  # Legacy manual settings are ignored permanently; the displayed month owns the nominal.
  merged['auto_nominal']=1.
  merged['nominal']=nominal_for_calendar_month(dt.date.today().year,dt.date.today().month,merged)
  return merged
 except DataIntegrityError as error:
  messagebox.showerror('Błąd bazy danych / Data integrity error',str(error))
  raise
 except (OSError,ValueError) as error:
  # Invalid data must not be silently replaced by empty defaults.
  if DB.exists():
   messagebox.showerror('Błąd bazy danych / Data integrity error',str(error))
   raise
  defaults=dict(DEFAULT)
  defaults['payslip_balances']={}
  seed_baseline(defaults)
  defaults['auto_nominal']=1.
  defaults['nominal']=nominal_for_calendar_month(dt.date.today().year,dt.date.today().month,defaults)
  return defaults
def save(d):
 global DATA_REVISION
 save_atomic(DB,d)
 DATA_REVISION+=1
def money(v): return f'{v:,.2f} zł'.replace(',',' ').replace('.',',')
POSITIONS=['Service Engineer','Senior Service Engineer','Superintendent','Senior Superintendent']
MONTHS=['Styczeń','Luty','Marzec','Kwiecień','Maj','Czerwiec','Lipiec','Sierpień','Wrzesień','Październik','Listopad','Grudzień']
# Firm-confirmed ISO payroll periods: overtime calendars 2024 and 2025,
# plus the previously approved 2026 calendar. Never replace user overrides.
WEEKS_2024=[(1,4),(5,8),(9,13),(14,17),(18,21),(22,26),(27,30),(31,35),(36,39),(40,43),(44,48),(49,52)]
WEEKS_2025=[(1,4),(5,9),(10,13),(14,17),(18,22),(23,26),(27,30),(31,35),(36,39),(40,43),(44,48),(49,52)]
WEEKS_2026=[(1,5),(6,9),(10,13),(14,17),(18,22),(23,26),(27,30),(31,35),(36,39),(40,44),(45,48),(49,53)]
def default_calendar(year):
 company_weeks={2024:WEEKS_2024,2025:WEEKS_2025,2026:WEEKS_2026}.get(year)
 if company_weeks:return {str(i+1):list(range(a,b+1)) for i,(a,b) in enumerate(company_weeks)}
 return {str(i+1):[] for i in range(12)}
def calendar_for(db,year):
 return db.get('calendars',{}).get(str(year),default_calendar(year))
def easter_sunday(year):
 """Gregorian Easter; needed for Polish movable public holidays."""
 a=year%19;b=year//100;c=year%100;d=b//4;e=b%4;f=(b+8)//25
 g=(b-f+1)//3;h=(19*a+b-d-g+15)%30;i=c//4;k=c%4
 l=(32+2*e+2*i-h-k)%7;m=(a+11*h+22*l)//451
 month=(h+l-7*m+114)//31;day=(h+l-7*m+114)%31+1
 return dt.date(year,month,day)

def nominal_for_calendar_month(year,month,db=None):
 """Monthly normal-hours denominator: calendar dates 1st through last day.

 Company ISO payroll weeks are ONLY used to assign work-card entries,
 including overtime, to a settlement month via accounting_month().
 The company's confirmed days off and statutory holidays are respected
 by scheduled_hours(). Saved ISO week overrides cannot change the nominal.
 """
 return scheduled_hours(int(year),int(month))


def accounting_month(date,db):
 d=dt.date.fromisoformat(date);y,w,_=d.isocalendar()
 for m,weeks in calendar_for(db,y).items():
  if w in weeks:return f'{y}-{int(m):02d}'
 return None

def _workbook_sheets(z):
 """List worksheet paths in Excel workbook order, allowing renamed worksheets."""
 names=set(z.namelist())
 paths=[]
 if 'xl/workbook.xml' in names and 'xl/_rels/workbook.xml.rels' in names:
  rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
  by_id={e.attrib.get('Id'):e.attrib.get('Target') for e in rels
         if e.attrib.get('Type','').endswith('/worksheet') and
         e.attrib.get('TargetMode')!='External'}
  book=ET.fromstring(z.read('xl/workbook.xml'))
  rid_ns='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
  sheets=[]
  for elem in book.iter(NS+'sheet'):
   target=by_id.get(elem.attrib.get(rid_ns))
   if not target:continue
   target=target.replace('\\','/')
   if target.startswith('/'):resolved=target.lstrip('/')
   elif target.startswith('xl/'):resolved=target
   else:resolved=posixpath.normpath(posixpath.join('xl',target))
   if resolved in names and resolved.lower().endswith('.xml'):
    sheets.append((elem.attrib.get('name',''),resolved))
  # Prefer the explicitly named work-card sheet, without reordering other tabs.
  paths.extend(p for n,p in sheets if ('karta' in n.casefold() and 'prac' in n.casefold()) or 'work card' in n.casefold())
  paths.extend(p for n,p in sheets if p not in paths)
 if 'xl/worksheets/sheet1.xml' in names and 'xl/worksheets/sheet1.xml' not in paths:
  paths.insert(0,'xl/worksheets/sheet1.xml')
 paths.extend(p for p in sorted(names) if p.startswith('xl/worksheets/') and
              p.endswith('.xml') and p not in paths)
 return paths


def _excel_clock_styles(z):
 """Return XF indices explicitly displaying clock hours and minutes.

 Numeric serials (e.g. 0.75 for 18:00) may only be interpreted as clocks
 when the workbook declares a clock format. Unformatted numeric cells are
 deliberately excluded to avoid misleading corrections.
 """
 try:
  root=ET.fromstring(z.read('xl/styles.xml'))
 except (KeyError, ET.ParseError):
  return set()
 custom={}
 fmt_root=root.find(NS+'numFmts')
 if fmt_root is not None:
  for fmt in fmt_root.findall(NS+'numFmt'):
   try:custom[int(fmt.attrib['numFmtId'])]=fmt.attrib.get('formatCode','')
   except (KeyError,ValueError):pass
 # Built-in Excel clock / date-time formats (mm:ss alone is not a clock).
 builtin={18,19,20,21,22,32,33,34,35,36}
 xfs=root.find(NS+'cellXfs')
 if xfs is None:return set()
 result=set()
 for index,xf in enumerate(xfs.findall(NS+'xf')):
  try:fmtid=int(xf.attrib.get('numFmtId','0'))
  except ValueError:continue
  if fmtid in builtin:
   result.add(index)
   continue
  pattern=custom.get(fmtid,'')
  # Remove quoted strings and escaped literal characters from format codes.
  pattern=re.sub(r'"[^"]*"|\\.', '', pattern).casefold()
  # hh:mm, h:mm:ss, [h]:mm; not mm:ss / date-only formats.
  if re.search(r'\[?h{1,2}\]?:mm',pattern):
   result.add(index)
 return result


def read_xlsx(path):
 with zipfile.ZipFile(path) as z:
  clock_style_ids=_excel_clock_styles(z)
  shared=[]
  if 'xl/sharedStrings.xml' in z.namelist():
   root=ET.fromstring(z.read('xl/sharedStrings.xml'))
   shared=[''.join(t.text or '' for t in si.iter(NS+'t')) for si in root]
  paths=_workbook_sheets(z)
  if not paths:raise ValueError('Plik Excel nie zawiera czytelnego arkusza pracy')
  saw_old_card=False
  for sheet in paths:
   root=ET.fromstring(z.read(sheet)); output=[]; current=None
   header_labels={}
   for hdr in root.iter(NS+'row'):
    if int(hdr.attrib.get('r','0'))>=14:break
    for c in hdr.findall(NS+'c'):
     col=(re.match(r'[A-Z]+',c.attrib.get('r','')) or [None])[0]
     if not col:continue
     vv=c.find(NS+'v'); ii=c.find(NS+'is')
     txt=vv.text if vv is not None else ''.join(ii.itertext()) if ii is not None else ''
     if c.attrib.get('t')=='s' and txt:txt=shared[int(txt)]
     if txt and not str(txt).replace('.','',1).isdigit():header_labels[col]=str(txt)
   clock_roles=time_column_roles(header_labels)
   for row in root.iter(NS+'row'):
    n=int(row.attrib.get('r','0'))
    if n<14 or n>34: continue
    vals={}
    time_styles={}
    for cell in row.findall(NS+'c'):
     col=re.match(r'[A-Z]+',cell.attrib['r']).group()
     v=cell.find(NS+'v'); inline=cell.find(NS+'is')
     value=v.text if v is not None else ''.join(inline.itertext()) if inline is not None else ''
     if cell.attrib.get('t')=='s' and value: value=shared[int(value)]
     vals[col]=value
     if col in ('D','E'):
      try:time_styles[col] = int(cell.attrib.get('s','0')) in clock_style_ids
      except ValueError:time_styles[col] = False
    if vals.get('C'):
     try:
      serial=float(vals['C'])
      if not 35000<serial<65000: continue
      current=(dt.datetime(1899,12,30)+dt.timedelta(days=serial)).date().isoformat()
     except (ValueError,OverflowError):
      current=None
      continue
    if not current:continue
    if not supported_date(current):
     saw_old_card=True
     continue
    def num(k):
     try:return float(vals.get(k) or 0)
     except ValueError:return 0.
    hours={k:num(k) for k in 'GHIJKL'}
    # N is the original Excel "Typ pracy" (work type). O is a separate
    # informational TAK/NIE column: "Praca w morzu". These must not be mixed.
    try:
     raw_type=str(vals.get('N','')).strip()
     work_type=(int(float(raw_type.replace(',','.')))
               if raw_type and float(raw_type.replace(',','.')).is_integer()
               else None)
    except (ValueError,OverflowError):
     work_type=None
    if (not any(hours.values()) and not str(vals.get('P','')).strip() and
        not str(vals.get('Q','')).strip() and work_type is None and
        not str(vals.get('O','')).strip() and not vals.get('C')):continue
    clocks=source_clocks(vals,clock_roles,time_styles)
    output.append({'date':current,'row':n,**(clocks or {}),'N':hours['G'],'A':hours['H'],'B':hours['I'],'PN':hours['J'],'P':hours['K'],'T':hours['L'],
                   'work_type':work_type,'work_type_raw':raw_type,
                   'sea_work_raw':str(vals.get('O','')).strip(),
                   'sea_work':str(vals.get('O','')).strip().upper()=='TAK',
                   'offshore':work_type==9,'offshore_travel':work_type==10,
                   'paid_day_off_hours':8. if work_type==5 else 0.,'leave_code':work_type==6,
                   'country':str(vals.get('P','')).strip(),'job':str(vals.get('Q','')).strip()})
   if output:return output
  if saw_old_card:raise UnsupportedCardYear("Karta pracy jest sprzed 2024 roku")
  return []

def travel_breakdown(rows):
 """Travel 06:00–20:00: 8 free TRAVEL hours per ordinary workday.

 Only travel within 06:00–20:00 consumes the daily eight-hour allowance.
 Travel outside that window, or on a scheduled free day, is fully eligible.
 Work/training N is not subtracted from the eight-hour travel allowance.
 Intervals over midnight are classified using their actual calendar date.

 The source P/T amount must match the independently recognised D/E clock
 interval. Otherwise its time-of-day is UNKNOWN: conservatively treat it as
 daytime travel (not as automatically eligible night travel). This prevents
 an invented clock value from inflating the supplement. Re-importing a
 readable original work card can supply trustworthy clock times.

 Returns {source_day: (travel_before, travel_deducted, travel_paid)}.
 """
 from night_work import interval_minutes
 source_hours=defaultdict(float)
 # actual-day => (start minute, order, source_day, daytime h, outside h)
 events=defaultdict(list)
 for order,r in enumerate(rows):
  source_day=str(r['date'])[:10]
  booked=max(0.,float(r.get('P',0) or 0)+float(r.get('T',0) or 0))
  # Preserve zero-travel dates for the daily summary table and export.
  source_hours[source_day]+=booked
  if booked<=0:continue
  day=dt.date.fromisoformat(source_day)
  clocks=interval_minutes(r)
  # A trustworthy time frame must describe precisely these travel hours.
  # A mixed work/travel row is ambiguous, even if its D/E clocks are valid.
  if clocks and abs((clocks[1]-clocks[0])/60-booked)<=.025:
   start,end=clocks
   current=start
   while current<end:
    offset=current//1440
    next_cut=min(end,(offset+1)*1440)
    day_date=day+dt.timedelta(days=offset)
    local_a=current-offset*1440
    local_b=next_cut-offset*1440
    daylight=max(0,min(local_b,1200)-max(local_a,360))/60.
    external=(local_b-local_a)/60.-daylight
    events[day_date].append((local_a,order,source_day,daylight,external))
    current=next_cut
  else:
   # Unknown time of day: never presume that the trip was at night.
   # It is still included in the total and the daytime eight-hour cap.
   events[day].append((1440,order,source_day,booked,0.))

 deducted=defaultdict(float)
 for actual_day,segments in events.items():
  free=8. if day_category(actual_day)=='workday' else 0.
  for start,order,source_day,daytime,external in sorted(segments):
   used=min(free,daytime)
   free-=used
   deducted[source_day]+=used

 return {day:(round(before,5),round(deducted[day],5),
              round(max(0.,before-deducted[day]),5))
         for day,before in source_hours.items()}

def travel_bonus(rows,cfg):
 """50% supplement for eligible travel according to travel_breakdown.

 Work-card time intervals are used when verifiable; the hourly pay rate is
 looked up on the source date. Company days off receive no travel deduction.
 """
 multiplier=float(cfg.get('travel_rate',.5))
 base_rate=cent(float(cfg.get('salary',0))/float(cfg.get('nominal',1))) if cfg.get('nominal') else 0.
 lookup=cfg.get('_rate_for_date') or (lambda _day:base_rate)
 return cent(sum(cent(v[2]*cent(cent(lookup(day))*multiplier))
                 for day,v in travel_breakdown(rows).items()))

def calc(rows, cfg):
 if cfg.get('social_limit') is None or cfg['social_limit'] <= 0:
  raise MissingAnnualLimit('Brak opublikowanego limitu emerytalno-rentowego dla wybranego roku. Prognoza netto nie jest dostępna.')
 # N in the MONTHLY PAYROLL is the calendar-month nominal only. Work-card N
 # remains available for daily/weekly inspection and actual-work leave history,
 # but must NEVER overwrite the payroll denominator or displayed payroll N.
 totals={k:sum(float(r.get(k,0) or 0) for r in rows) for k in ['A','B','PN','P','T']}
 totals['N']=float(cfg.get('nominal',0) or 0)
 offshore_days=len({r['date'] for r in rows if r.get('work_type')==9})
 # Code 10 (offshore travel) is intentionally NOT counted as a paid offshore
 # day until its separate allowance rules are confirmed.
 rate=cent(cfg['salary']/cfg['nominal']) if cfg['nominal'] else 0
 # The 2026 payslips show the 2-decimal hourly rate and premium are rounded
 # BEFORE multiplying by hours. Retro overtime follows the work-date rate.
 lookup=cfg.get('_rate_for_date') or (lambda _date:rate)
 overtime=overtime_components(rows,lookup)
 # Payslip codes: 1700 = all overtime hours at basic 100% of the rate;
 # 1711 = additional 50% A; 1721 = additional 100% B.
 overtime_base=overtime['all_base']
 overtime_a_premium=overtime['premium_a']
 overtime_b_premium=overtime['premium_b']
 night_allowance=night_bonus_detail(rows)['amount']
 # Travel: 06:00–20:00 8-hour daytime allowance, outside automatic 50%.
 # When clock intervals are absent, avoid inventing night travel hours.
 travel_hours=sum(v[2] for v in travel_breakdown(rows).values())
 extras=(cfg.get('_leave_variable_pay',0.0)+overtime_base+overtime_a_premium+overtime_b_premium+night_allowance
         +travel_bonus(rows,cfg)+offshore_days*cfg['offshore']
         +cfg.get('car_bonus_count',0)*400+cfg.get('shared_room_nights',0)*100
         +cfg.get('domestic_diet_extra_days',0)*55
         +cfg.get('risk_days',0)*230*cfg.get('risk_factor',1)+cfg.get('other_gross',0))
 extras=cent(extras+cfg.get('eu_c_allowance',0))
 zfss=cent(cfg.get('zfss_cash',0))
 zfss_exempt,zfss_taxable=zfss_tax_split(zfss,cfg.get('_zfss_prior_year',0))
 wage_gross=cent(cfg['salary']+extras)
 gross=cent(wage_gross+zfss)
 # Benefits are not cash paid to the employee, but may affect contribution bases.
 # September 2026 payslip: 27,784.46 cash gross + 150 Edenred + 547.90 LuxMed
 # = 28,482.36 social contribution base. Employer PPE/PPO affect PIT base,
 # but do not increase cash gross, social/health base or bank transfer.
 benefits=(cfg.get('edenred_benefit',0)+cfg.get('luxmed_benefit',0))*cfg.get('benefits_in_social',1)
 social_base=wage_gross+benefits
 cap_left=max(0,cfg['social_limit']-cfg['social_ytd'])
 capped=min(social_base,cap_left)
 pension=cent(capped*.0976); disability=cent(capped*.015); sickness=cent(social_base*.0245)
 social=pension+disability+sickness
 health=cent((social_base-social)*.09)
 # §19-20 regulation: employer PPE 3.5%, PPO 0.5% for eligible staff.
 # Only listed allowances are included in this estimation. Unknown awards,
 # retro corrections and actual payment dates require payslip reconciliation.
 # 09/2026 actual payslip: employer PPE/PPO base 28,482.36 PLN,
 # identical to the full social base including Edenred + LuxMed (uncapped).
 # Earlier months also strongly support this, subject to eligibility exclusions.
 employer_ppe,employer_ppo=pension_employer_estimate(cfg,social_base)
 employer_taxable=(employer_ppe+employer_ppo)*cfg.get('employer_pension_taxable',1)
 taxable=max(0,zloty(wage_gross+benefits+employer_taxable-social-cfg['costs']+zfss_taxable))
 pit_gross,_tax_status=marginal_tax(cfg.get('ytd_tax_base',0),taxable,int(cfg.get('_tax_year',2026)))
 pit=max(0,zloty(pit_gross-cfg['pit_relief']))
 ppk=cent(wage_gross*cfg['ppk']/100)
 net=cent(gross-social-health-pit-ppk-cfg.get('ppe_extra',0)-cfg.get('other_deductions',0))
 return totals,offshore_days,rate,extras,gross,social,health,taxable,pit,ppk,net

def payroll_breakdown(rows,cfg,calc_result=None):
 totals,days,rate,extra,gross,social,health,taxable,pit,ppk,net=calc_result if calc_result is not None else calc(rows,cfg)
 benefits=(cfg.get('edenred_benefit',0)+cfg.get('luxmed_benefit',0))*cfg.get('benefits_in_social',1)
 zfss=cent(cfg.get('zfss_cash',0))
 social_base=cent(gross-zfss)+benefits
 capped=min(social_base,max(0,cfg['social_limit']-cfg['social_ytd']))
 pension=cent(capped*.0976)
 disability=cent(capped*.015)
 sickness=cent(social_base*.0245)
 employer_ppe,employer_ppo=pension_employer_estimate(cfg,social_base)
 zfss_exempt,zfss_taxable=zfss_tax_split(zfss,cfg.get('_zfss_prior_year',0))
 return {'zfss_exempt':zfss_exempt,'zfss_taxable':zfss_taxable,'zfss_prior':cfg.get('_zfss_prior_year',0),'eu_c_allowance':cfg.get('eu_c_allowance',0),'emerytalna':pension,'rentowa':disability,'chorobowa':sickness,'zdrowotna':health,'pit':pit,'social_base':social_base,'health_base':social_base-social,'noncash':benefits,'employer_ppe':employer_ppe,'employer_ppo':employer_ppo,'net':net}



EN_TRANSLATIONS={'Dodatek C — wyrównanie UE (brutto, miesiąc WYPŁATY)':'EU C top-up (gross, PAYMENT month)',
 'ZFŚS — świadczenie socjalne (gotówka, miesiąc WYPŁATY)':'ZFSS — cash social benefit (PAYMENT month)',
 'Dodatek C — wyrównanie UE (brutto)':'EU C top-up (gross)',
 'ZFŚS — świadczenie gotówkowe':'ZFSS — cash social benefit',
 'ZFŚS — część zwolniona z PIT':'ZFSS — PIT-exempt portion',
 'ZFŚS — część opodatkowana':'ZFSS — taxable portion',
 'Nalicz PPE pracodawcy 3,5% (1=tak, 0=nie)':'Calculate employer PPE 3.5% (1=yes, 0=no)',
 'Nalicz PPO pracodawcy 0,5% (1=tak, 0=nie)':'Calculate employer PPO 0.5% (1=yes, 0=no)',
 'Korekta PPE pracodawcy z paska (0=automatycznie)':'Employer PPE payslip override (0=automatic)',
 'Korekta PPO pracodawcy z paska (0=automatycznie)':'Employer PPO payslip override (0=automatic)',
 'Pensja zasadnicza jest zapisywana od wybranego miesiąca. Import kart pracy jej nie zmienia.':'Base salary changes take effect from the selected month. Work card imports do not overwrite them.',
 'PRÓG PODATKOWY (PIT)':'INCOME TAX BAND (PIT)','Prognozowany próg PIT:':'Estimated PIT band:', 'Szacunek — niepełne dane z kart pracy':'Estimate — incomplete work-card history','Automatycznie: dane z historii rozliczeń':'Automatic: based on payroll history','Z kalendarza firmowego 2026':'From the 2026 company calendar','Uzgodnij PIT i ZUS z paskiem płacowym':'Reconcile PIT and ZUS against payslip','Szczegóły / korekta danych': 'Details / correct data', 'Szacunkowe wynagrodzenie urlopowe wyliczono automatycznie z kart pracy i zapisanych ustawień. Daty faktycznych wypłat i kwalifikację dodatków sprawdź na pasku płacowym.': 'Estimated leave pay was calculated from work cards and stored settings. Verify actual payment dates and eligible wage components against your payslip.', 'Brak danych z części wymaganych miesięcy. Nie doliczono zmiennej części urlopu do prognozy. Sprawdź karty pracy i okresy rozliczeniowe.': 'Some reference months are missing. Variable leave pay was not added to the estimate. Check the work cards and payroll periods.', 'SZACUNEK: zmienna część urlopu jest automatycznie obliczona z nadgodzin i godzin faktycznej pracy. Przypisanie do miesiąca wypłaty jest niepotwierdzone; sprawdź z paskiem płacowym.': 'ESTIMATE: variable leave pay is calculated automatically from overtime and actual work hours. Payment months are unverified; compare with payslips.', 'Brakuje kart lub przypisania tygodni w miesiącach podstawy urlopowej. Zmienna część urlopu nie została doliczona.': 'Cards or week assignments are missing in the leave reference months. Variable leave pay was not added.', 'Brak danych': 'No data', 'Pulpit': 'Dashboard', 'Karty pracy': 'Work cards', 'Podsumowanie': 'Summary', 'Rozliczenie': 'Payroll', 'Zestawienie do A1': 'A1 report', 'Kalendarz': 'Calendar', 'Historia': 'History', 'Ustawienia': 'Settings', 'KALKULATOR WYNAGRODZENIA': 'SALARY CALCULATOR', 'PENSJA PODSTAWOWA BRUTTO': 'GROSS BASE SALARY', 'PROGNOZA PRZELEWU': 'ESTIMATED BANK TRANSFER', 'NADGODZINY A': 'OVERTIME A', 'NADGODZINY B': 'OVERTIME B', 'PODSUMOWANIE MIESIĄCA': 'MONTHLY SUMMARY', 'Godziny normalne N': 'Regular hours N', 'Godziny normalne N — kalendarz':'Regular hours N — calendar', '1700 — wynagrodzenie za nadgodziny 100%': '1700 — overtime basic pay 100%',
 '1711 — dodatek A 50%': '1711 — A premium 50%',
 '1721 — dodatek B 100%': '1721 — B premium 100%',
 '1746 — dodatek do diety 55 zł/dzień (brutto)': '1746 — per-diem supplement PLN 55/day (gross)',
 'Nadgodziny A — dodatek 50%': 'Overtime A — 50% premium', 'Nadgodziny B — dodatek 100%': 'Overtime B — 100% premium', 'Dodatek za podróż (T po)': 'Travel allowance (T)', 'Łączna liczba godzin': 'Total hours', 'KARTY PRACY — ZESTAWIENIE PLIKÓW': 'WORK CARDS — FILE LIST', 'Kliknij pole ✓, aby włączyć lub wyłączyć kartę z obliczeń. Zaznaczenie wiersza pokazuje szczegóły.': 'Click ✓ to include or exclude a card. Select a row to see details.', 'Tydzień': 'Week', 'Karta pracy / plik': 'Work card / file', 'Data': 'Date', 'Dzień': 'Day', 'Kraj': 'Country', 'Godz. prac': 'Work hours', 'Godz. podr': 'Travel hours', 'Nadgodziny': 'Overtime', 'Razem': 'Total', 'Status': 'Status', 'SZCZEGÓŁY KARTY': 'CARD DETAILS', 'Wybierz kartę pracy, aby zobaczyć jej zakres dat i liczbę wpisów.': 'Select a work card to see its date range and number of entries.', 'Usuń wybraną kartę': 'Delete selected card', 'Podsumowanie dzienne': 'Daily summary', 'Podsumowanie tygodniowe': 'Weekly summary', 'KOMENTARZ DNIA — INSTALACJA / NR ZLECENIA': 'DAILY COMMENT — INSTALLATION / JOB NUMBER', 'Wybierz dzień z tabeli, aby zobaczyć instalację i numer zlecenia.': 'Select a day to see the installation and job number.', 'Rok / tydzień': 'Year / week', 'Zakres dat': 'Date range', 'T po odliczeniu': 'Travel after deduction', 'T przed odliczeniem': 'Travel before deduction', 'T odliczone': 'Travel deducted', 'T przed odl.': 'Travel before', 'T odlicz.': 'Travel deducted', 'T po odl.': 'Travel after', 'Dni offshore': 'Offshore days', 'Urlop (h)': 'Leave (h)', 'Godziny urlopu (h)': 'Annual leave hours (h)', 'Dni urlopu': 'Annual leave days', 'Wynagrodzenie urlopowe — część zmienna': 'Annual leave pay — variable part', 'Dane do wynagrodzenia urlopowego': 'Leave pay input', 'URLOP WYPOCZYNKOWY': 'PAID ANNUAL LEAVE', 'Uzupełnij dane z pasków płacowych': 'Enter payslip data', 'Brak kompletu danych z pasków płacowych. Prognoza przelewu nie zawiera zmiennej części wynagrodzenia urlopowego.': 'Payslip records are incomplete. The bank transfer estimate excludes the variable part of annual leave pay.', 'Wpisane dane dotyczą miesięcy WYPŁATY dodatków, a nie okresu przepracowania nadgodzin.': 'Enter the months in which variable allowances were PAID, not the months when overtime was worked.', 'Kwota faktycznie wypłaconych składników zmiennych (zł)': 'Variable gross actually paid (PLN)', 'Godziny rzeczywiście przepracowane (h)': 'Hours actually worked (h)', 'Zapisz podstawę urlopową': 'Save leave pay basis', 'Razem godziny': 'Total hours', 'SZCZEGÓŁY ROZLICZENIA': 'PAYROLL DETAILS', 'Stała pensja podstawowa brutto': 'Fixed gross base salary', 'Stawka godzinowa': 'Hourly rate', 'Liczba nadgodzin A (h)': 'Overtime A hours', 'Liczba nadgodzin B (h)': 'Overtime B hours', 'Liczba godzin podróży T przed (h)': 'Travel hours before deduction', 'Liczba godzin odliczonych (h)': 'Deducted travel hours', 'Liczba godzin podróży T po (h)': 'Paid travel hours', '1710 — dodatek A 50%': '1710 — A premium 50%', '1720 — dodatek B 100%': '1720 — B premium 100%', 'Podróże T po — dodatek 50%': 'Paid travel — 50% premium', 'Dodatek PN za pracę w nocy (20% minimum)': 'Night-work PN premium (20% of minimum wage)', 'Podróż autem': 'Travel by car', 'Wspólna kabina': 'Shared cabin', 'Ryzyko': 'Risk allowance', 'Dodatki razem': 'Total allowances', 'Wynagrodzenie brutto (gotówkowe)': 'Gross cash remuneration', 'Emerytalne pracownika (9,76%)': 'Employee pension contribution (9.76%)', 'Rentowe pracownika (1,50%)': 'Employee disability contribution (1.50%)', 'Chorobowe pracownika (2,45%)': 'Employee sickness contribution (2.45%)', 'Składka zdrowotna (9%)': 'Health insurance (9%)', 'Podstawa PIT (0 = nie wyznaczana w symulacji)': 'PIT taxable base', 'Zaliczka PIT': 'PIT advance', 'PPE dodatkowe': 'Additional PPE', 'Pozostałe potrącenia': 'Other deductions', 'ŚWIADCZENIA POZAPŁACOWE — NIE DODAWAĆ DO PRZELEWU': 'NON-CASH BENEFITS — EXCLUDED FROM BANK TRANSFER', 'Edenred — osobna karta (nie przelew)': 'Edenred — separate card', 'LuxMed — świadczenie niepieniężne': 'LuxMed — non-cash benefit', 'PPE pracodawcy — osobny rachunek': 'Employer PPE — separate account', 'PPO pracodawcy — osobny rachunek': 'Employer PPO — separate account', 'Razem świadczenia poza przelewem': 'Total non-cash benefits', 'Eksport godzin CSV': 'Export hours CSV', 'Eksport rozliczenia':'Export payroll report', 'HISTORIA GODZIN Z ZAIMPORTOWANYCH KART': 'HISTORY OF IMPORTED WORK HOURS', 'Historia pokazuje godziny, nie archiwalne wypłaty. Nie należy stosować bieżących parametrów podatkowych do poprzednich miesięcy.': 'History shows hours, not historical payslips. Current tax settings should not be applied to past months.', 'ZESTAWIENIE A1 — POBYT W KRAJACH': 'A1 REPORT — DAYS BY COUNTRY', 'Polska = dni w wybranym okresie minus unikalne dni za granicą. Braki kraju wymagają weryfikacji.': 'Poland = days in the selected period minus unique days abroad. Missing country data requires verification.', 'Cały rok': 'Full year', 'Rok:': 'Year:', 'Od (RRRR-MM-DD):': 'From (YYYY-MM-DD):', 'Do:': 'To:', 'PRZELICZ A1': 'CALCULATE A1', 'EKSPORT DO EXCELA': 'EXPORT TO EXCEL', 'Liczba dni': 'Number of days', 'POLSKA': 'POLAND', 'ŁĄCZNIE DNI W OKRESIE': 'TOTAL DAYS IN PERIOD', 'RAZEM ZA GRANICĄ': 'TOTAL DAYS ABROAD', 'KALENDARZ OKRESÓW ROZLICZENIOWYCH': 'PAYROLL PERIOD CALENDAR', 'Nie przypisano tygodni': 'No assigned weeks', 'Tygodnie ISO (edytuj):': 'ISO weeks (edit):', 'Tydz.': 'Wk', 'Pn': 'Mo', 'Wt': 'Tu', 'Śr': 'We', 'Cz': 'Th', 'Pt': 'Fr', 'So': 'Sa', 'Nd': 'Su', 'Zapisz kalendarz': 'Save calendar', 'Import CSV': 'Import CSV', 'Eksport CSV': 'Export CSV', '↻ Odśwież folder': '↻ Refresh folder', '📁 Dodaj folder': '📁 Add folder', '+ Importuj karty Excel': '+ Import Excel cards', 'Miesiąc rozliczeniowy:': 'Payroll month:', '📅  Wybierz miesiąc': '📅  Select month', 'Stanowisko:': 'Position:', '✎  Zmień pensję podstawową': '✎  Change base salary', 'AUTOMATYCZNY IMPORT KART PRACY': 'AUTOMATIC WORK CARD IMPORT', 'Folder główny „Karta pracy” (podfoldery 2026, 2027 itd.)': 'Main work card folder (2026, 2027 subfolders etc.)', 'Przeglądaj...': 'Browse...', 'Automatycznie importuj karty z folderu wybranego roku': 'Automatically import cards for the selected year', 'Automatycznie synchronizuj karty pracy przy uruchomieniu': 'Automatically sync work cards at startup', 'ZAPISZ USTAWIENIA': 'SAVE SETTINGS', 'Poniedziałek': 'Monday', 'Wtorek': 'Tuesday', 'Środa': 'Wednesday', 'Czwartek': 'Thursday', 'Piątek': 'Friday', 'Sobota': 'Saturday', 'Niedziela': 'Sunday', 'Styczeń': 'January', 'Luty': 'February', 'Marzec': 'March', 'Kwiecień': 'April', 'Maj': 'May', 'Czerwiec': 'June', 'Lipiec': 'July', 'Sierpień': 'August', 'Wrzesień': 'September', 'Październik': 'October', 'Listopad': 'November', 'Grudzień': 'December', 'Włochy': 'Italy', 'Polska': 'Poland', 'Wielka Brytania': 'United Kingdom', 'Belgia': 'Belgium', 'Hiszpania': 'Spain', 'Francja': 'France', 'Niemcy': 'Germany', 'Holandia': 'Netherlands', 'Dania': 'Denmark', 'Finlandia': 'Finland', 'BRAK': 'MISSING', 'Brak przypisanych tygodni w kalendarzu rozliczeniowym — uzupełnij kalendarz.': 'No weeks assigned in the payroll calendar — update the calendar.'}
# Translation additions for the dashboard and recent payroll features.
EN_TRANSLATIONS.update({
    'Czas podróży przed odliczeniem': 'Travel time before deduction',
    'Czas podróży odliczony': 'Deducted travel time',
    'Czas podróży po odliczeniu': 'Travel time after deduction',
    'Godziny nocne PN': 'Night-work PN hours',
    'Wspólna kabina — liczba nocy': 'Shared cabin — nights',
    'Dodatek do diety — liczba dni': 'Diet supplement — days',
    'Podróż samochodem — liczba dodatków': 'Travel by car — allowances',
    'Dodatek za ryzyko — dni': 'Risk allowance — days',
    'Dodatkowe wynagrodzenie brutto': 'Additional gross pay',
    'PANEL NAWIGACYJNY': 'NAVIGATION PANEL',
    'Nominał godzin:': 'Nominal working hours:',
    'automatycznie według kalendarza PL': 'automatically from the Polish calendar',
    'Dodatki razem (z urlopowym, gdy oszacowane)': 'Total allowances (including estimated leave pay)',
   
    'dni': 'days',
    'dzień': 'day',
    'Tak': 'Yes', 'Nie': 'No',
})
NAVY='#081725'; PANEL='#10293c'; PANEL2='#193a51'; GOLD='#d8b16b'; WHITE='#f2f6f9'; MUTED='#aec0cd'; GREEN='#138567'
class App:
 def __init__(self,root):
  _init_start=perf_monotonic()
  init_performance_log(HOME,"ACH" )
  # Preserve Tk's normal exception reporting while recording error class only.
  previous_reporter=getattr(root,'report_callback_exception',None)
  def report_callback_exception(exc_type,exc_value,traceback):
   perf_record_error('gui_callback',exc_value)
   if previous_reporter:previous_reporter(exc_type,exc_value,traceback)
  root.report_callback_exception=report_callback_exception
  schedule_navy_titlebar(root,background=NAVY,foreground="#ffffff")
  self.ui_scale=dpi_scale(root)
  self.root=root; self.db=load();self.theme_mode='dark';root._payroll_theme_mode=self.theme_mode;root.title(f'Kalkulator wynagrodzeń | ACH | {APP_VERSION_LABEL}');root.geometry(f'{min(round(1510*self.ui_scale),round(root.winfo_screenwidth()*.94))}x{min(round(900*self.ui_scale),round(root.winfo_screenheight()*.88))}');root.minsize(780,520);root.configure(bg=NAVY)
  self.style=ttk.Style(root)
  if 'clam' in self.style.theme_names():self.style.theme_use('clam')
  self.style.configure('Payroll.Treeview',background='#ffffff',foreground='#193047',
                       fieldbackground='#ffffff',rowheight=round(32*self.ui_scale),font=('Segoe UI',10),
                       borderwidth=0)
  self.style.map('Payroll.Treeview.Heading',background=[('active','#173c56'),('pressed','#173c56'),('!active','#173c56')],foreground=[('active','#ffffff'),('pressed','#ffffff')],relief=[('active','flat'),('pressed','flat')])
  self.style.configure('Payroll.Treeview.Heading',background='#173c56',foreground='#ffffff',
                       font=('Segoe UI',10,'bold'),padding=(10,9),relief='flat')
  self.style.configure('Payroll.TNotebook',background=PANEL,borderwidth=0)
  self.style.configure('Payroll.TNotebook.Tab',font=('Segoe UI',10,'bold'),padding=(12,6),background='#193a51',foreground='#ffffff',borderwidth=0)
  self.style.map('Payroll.TNotebook.Tab',padding=[('selected',(20,13)),('!selected',(12,6))],background=[('selected','#b9dff5'),('!selected','#193a51')],foreground=[('selected','#123d5c'),('!selected','#ffffff')],relief=[('selected','flat'),('!selected','flat')])
  self.style.map('Payroll.Treeview',
                 background=[('selected','#b9d6e9')],
                 foreground=[('selected','#092238')])
  self.month=tk.StringVar(value=dt.date.today().strftime('%Y-%m'));self.position=tk.StringVar(value=self.db.get('position','Service Engineer'));self.page='Pulpit';self.widgets=[];self.language=self.db.get('language','pl')
  self.banner=tk.Canvas(root,height=round(174*self.ui_scale),bg=NAVY,highlightthickness=0);self.banner.pack(fill='x');self.banner.bind('<Configure>',self.draw_banner)
  body=tk.Frame(root,bg=NAVY);body.pack(fill='both',expand=True)
  # Sidebar has its own vertical scroll area: all navigation buttons remain
  # reachable when the window is shorter than the menu.
  self.side=tk.Frame(body,bg='#092238',width=round(265*dpi_scale(root)))
  self.side.pack(side='left',fill='y')
  self.side.pack_propagate(False)
  self.side_scroll=ttk.Scrollbar(self.side,orient='vertical')
  self.side_canvas=tk.Canvas(self.side,bg='#092238',highlightthickness=0,
                             yscrollcommand=self.side_scroll.set)
  self.side_canvas.pack(side='left',fill='both',expand=True)
  self.side_scroll.configure(command=self.side_canvas.yview)
  self.side_content=tk.Frame(self.side_canvas,bg='#092238')
  self.side_window=self.side_canvas.create_window((0,0),window=self.side_content,anchor='nw')
  self.side_content.bind('<Configure>',lambda e:(self.side_canvas.configure(scrollregion=self.side_canvas.bbox('all')),self._schedule_scrollbars()))
  self.side_canvas.bind('<Configure>',lambda e:(self.side_canvas.itemconfigure(self.side_window,width=e.width),self._schedule_scrollbars()))
  self.sidebar_title=tk.Label(self.side_content,text=self.tr('PANEL NAWIGACYJNY'),font=('Segoe UI',15,'bold'),bg='#092238',fg=GOLD,justify='left',wraplength=round(220*self.ui_scale));self.sidebar_title.pack(anchor='w',padx=17,pady=(12,12))
  self.nav_buttons={}
  self.nav_icons={}
  asset_base=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
  for idx,key in enumerate(['Pulpit','Karty pracy','Podsumowanie','Rozliczenie','Zestawienie do A1','Kalendarz','Historia','Ustawienia']):
   try:
    self.nav_icons[key]=image_photo(self.root,f'nav_{idx}',21)
   except (OSError,tk.TclError):pass
  # Deep-navy pictograms are used only with the pale sidebar.
  # Dark mode retains the original high-contrast white/gold images.
  self.nav_icons_light={key:tinted_image_photo(self.root,f'nav_{idx}',21,'#173f61')
                        for idx,key in enumerate(['Pulpit','Karty pracy','Podsumowanie','Rozliczenie',
                                                   'Zestawienie do A1','Kalendarz','Historia','Ustawienia'])}
  self.nav_icons_light['logout']=tinted_image_photo(self.root,'logout',22,'#9b641c')
  self.nav_icons['logout']=image_photo(self.root,'logout',22)
  self.calendar_icon=image_photo(self.root,'calendar',21)
  self.folder_icon=image_photo(self.root,'folder',19)
  self.refresh_icon=image_photo(self.root,'refresh',19)
  for name in ['Pulpit','Karty pracy','Podsumowanie','Rozliczenie','Zestawienie do A1','Kalendarz','Historia','Ustawienia']:
   btn=tk.Button(self.side_content,text='  '+self.tr(name),image=self.nav_icons.get(name),compound='left',anchor='w',font=('Segoe UI',11,'bold'),bg=PANEL2,fg=WHITE,activebackground=GOLD,activeforeground=NAVY,bd=0,relief='flat',highlightthickness=0,pady=round(7*self.ui_scale),command=lambda n=name:self.show(n));btn.pack(fill='x',padx=9,pady=3);self.nav_buttons[name]=btn
  self.logout_btn=tk.Button(self.side_content,text='  '+('Log out' if self.language=='en' else 'Wyloguj się'),image=self.nav_icons['logout'],compound='left',anchor='w',font=('Segoe UI',11,'bold'),bg='#163447',fg=GOLD,activebackground=GOLD,activeforeground=NAVY,bd=0,relief='flat',highlightthickness=0,pady=round(7*self.ui_scale),command=self.logout)
  self.logout_btn.pack(fill='x',padx=9,pady=(8,6))
  # Central mouse-wheel routing supports hovered navigation and nested pages.
  self.view=tk.Frame(body,bg=NAVY);self.view.pack(side='left',fill='both',expand=True,padx=8,pady=8)
  self.main_canvas=tk.Canvas(self.view,bg=NAVY,highlightthickness=0)
  self.main_xscroll=ttk.Scrollbar(self.view,orient='horizontal',command=self.main_canvas.xview)
  self.main_yscroll=ttk.Scrollbar(self.view,orient='vertical',command=self.main_canvas.yview)
  self.main_canvas.configure(xscrollcommand=self.main_xscroll.set,yscrollcommand=self.main_yscroll.set)
  # Scrollbars are displayed only when content actually overflows.
  self.main_canvas.pack(side='left',fill='both',expand=True)
  self.main=tk.Frame(self.main_canvas,bg=NAVY)
  self.main_window=self.main_canvas.create_window((0,0),window=self.main,anchor='nw')
  self.page_host=self.main
  self._page_frames={}
  self._active_page_frame=None
  self._month_cfg_cache={}
  self._month_cfg_revision=DATA_REVISION
  self._tax_preview_cache={}
  self.page_host.bind('<Configure>',lambda e:(self.main_canvas.configure(scrollregion=self.main_canvas.bbox('all')),self._schedule_scrollbars()))
  self.main_canvas.bind('<Configure>',self._resize_content)
  self.root.bind_all('<MouseWheel>',self._route_mousewheel)
  self.root.bind_all('<Shift-MouseWheel>',self._route_mousewheel)
  self.root.bind_all('<Button-4>',self._route_mousewheel)
  self.root.bind_all('<Button-5>',self._route_mousewheel)
  # Intercept Combobox wheel before ttk changes its selected value.
  self.root.bind_class('TCombobox','<MouseWheel>',lambda e:(self._route_mousewheel(e),'break')[1])
  self.settings_canvas=None;self.calendar_canvas=None
  self._update_navigation()
  self.sidebar_title.configure(text=self.tr('PANEL NAWIGACYJNY'))
  self.show('Pulpit')
  self.root.after_idle(self._apply_interface_theme)
  self.root.after_idle(self._maximize_main_window)
  self.root.after(750,self.show_monthly_payroll_reminder)
  self.root.after(350,self._auto_import_on_start)
  self.root.after(1900,self._maybe_refresh_annual_limits)
  performance_measure("app_init",_init_start,rows=len(self.db.get("rows",())))
 EN_EXTRA = {
  'Pokaż daty do weryfikacji': 'Show dates requiring review',
  'DO WERYFIKACJI — DATY I KARTY PRACY': 'REVIEW REQUIRED — DATES AND WORK CARDS',
  'Data': 'Date',
  'Powód': 'Reason',
  'Kraj z karty': 'Country in card',
  'Wiersz Excel': 'Excel row',
  'Ścieżka do pliku': 'File path',
  'Różne kraje': 'Different countries',
  'Brak kraju': 'Missing country',
  'Zamknij': 'Close',
  'Otwórz kartę w Excelu': 'Open work card in Excel',
  'Dwukrotne kliknięcie wiersza otworzy źródłową kartę Excel.': 'Double-click a row to open the original Excel work card.',
  'Każdy wiersz wskazuje oryginalne źródło. Konflikty wymagają weryfikacji — program nie wybiera kraju automatycznie.': 'Every row identifies the original source. Country conflicts require review — the app does not choose a country automatically.',
  'Nie znaleziono wpisów wymagających weryfikacji.': 'No entries require review.',
  'Kraj (ujednolicony)': 'Country (normalized)',
  'Weryfikacja A1': 'A1 review',
  'Do weryfikacji': 'Review required',
  'Karta / plik': 'Card / file',
  'BEZPIECZEŃSTWO KONTA':'ACCOUNT SECURITY',
  'Zmień PIN':'Change PIN',
  'Zmień adres e-mail':'Change email address',
  'Zweryfikuj adres e-mail':'Verify email address',
  'Liczba dni dodatku do diety (55 zł/dzień)':'Domestic per-diem supplement days (PLN 55)',

  'Dodatki razem (z urlopowym, gdy potwierdzone)':'Total allowances (including confirmed leave pay)',
  'USTAWIENIA WYNAGRODZENIA':'PAYROLL SETTINGS',
  'Pensja podstawowa nie zmienia się przy imporcie kart ani wyborze miesiąca.':'Base salary is not changed by importing work cards or selecting a month.',
  'STAŁA PENSJA PODSTAWOWA BRUTTO (zł)':'FIXED GROSS BASE SALARY (PLN)',
  'Nominał godzin:':'Standard monthly hours:',
  'automatycznie według kalendarza PL':'automatically calculated for Polish public holidays',
  'Offshore brutto za dzień (zł)':'Offshore gross allowance per day (PLN)',
  'Praca w morzu':'At sea',
  'KARTY PRACY WYBRANEGO TYGODNIA':'WORK CARDS IN SELECTED WEEK',
  'Karta pracy':'Work card',
  'Daty':'Dates',
  'Lokalizacja':'Location',
  'Otwórz w Excelu':'Open in Excel',
  'Nie znaleziono pliku':'File not found',
  'Kliknij tydzień, aby wyświetlić jego karty. Podwójne kliknięcie karty otworzy ją w Excelu.':'Select a week to list its cards. Double-click a card to open it in Excel.',
  'Dodatek podróżny jako ułamek stawki godzinowej (0,5 = 50%)':'Travel premium as a fraction of hourly rate (0.5 = 50%)',
  'Koszty uzyskania przychodu (zł)':'Tax-deductible employment costs (PLN)',
  'Miesięczne zmniejszenie zaliczki PIT (zł)':'Monthly PIT tax credit (PLN)',
  'Podstawa PIT od początku roku przed tym miesiącem (zł)':'Year-to-date PIT taxable income before this month (PLN)',
  'Podstawa emerytalno-rentowa od początku roku (zł)':'Year-to-date pension and disability contribution base (PLN)',
  'Roczny limit podstawy emerytalno-rentowej (zł)':'Annual pension and disability contribution base cap (PLN)',
  'PPK pracownika (%)':'Employee PPK (%)',
  'Edenred i LuxMed w podstawie ZUS/PIT (1=tak, 0=nie)':'Include Edenred and LuxMed in ZUS/PIT base (1=yes, 0=no)',
  'PPE i PPO pracodawcy w podstawie PIT (1=tak, 0=nie)':'Include employer PPE and PPO in PIT base (1=yes, 0=no)',
  'Edenred — świadczenie pozapłacowe z paska (zł)':'Edenred — non-cash payslip benefit (PLN)',
  'LuxMed — świadczenie pozapłacowe z paska (zł)':'LuxMed — non-cash payslip benefit (PLN)',
  'PPE pracodawcy — kwota referencyjna z września (zł)':'Employer PPE — September reference amount (PLN)',
  'PPO pracodawcy — kwota referencyjna z września (zł)':'Employer PPO — September reference amount (PLN)',
  'PPE dodatkowe — potrącenie z przelewu (zł)':'Additional PPE — bank transfer deduction (PLN)',
  'Liczba zatwierdzonych dodatków za jazdę autem (400 zł)':'Number of approved car travel allowances (PLN 400)',
  'Liczba kwalifikowanych nocy w pokoju dwuosobowym (100 zł)':'Qualifying shared-cabin nights (PLN 100)',
  'Dni wysokiego ryzyka (po zatwierdzeniu)':'High-risk days (subject to approval)',
  'Współczynnik ryzyka (1 / 0,75 / 0,5 / 0,25)':'Risk multiplier (1 / 0.75 / 0.5 / 0.25)',
  'Inne dodatki brutto / korekty (zł)':'Other gross allowances / adjustments (PLN)',
  'Pozostałe potrącenia z przelewu (zł)':'Other bank transfer deductions (PLN)',
  'Offshore: ręczna liczba dni (-1 = automatycznie)':'Offshore: manual day count (-1 = automatic)',
  'Dwukrotne wpisy jednego dnia są sumowane; PN może nakładać się na inne godziny.':'Multiple entries for one day are summed; PN may overlap other hours.',
  'Brak informacji w zaimportowanych danych — odśwież folder z oryginalnymi kartami.':'No information in imported data — refresh the folder with original work cards.',
  'PANEL NAWIGACYJNY':'NAVIGATION PANEL',
  'Wybierz miesiąc':'Select month',
  'Dodaj folder':'Add folder',
  'Odśwież folder':'Refresh folder',
  'Rok ISO':'ISO year',
  'Każdy kolorowy pasek oznacza tydzień przypisany do miesiąca rozliczeniowego. Przewijaj w pionie i poziomie.':'Each colored bar represents a week assigned to a payroll month. Scroll vertically and horizontally.',
 }
 def tr(self,text):
  if self.language!='en':return str(text)
  text=str(text)
  if text in self.EN_EXTRA:return self.EN_EXTRA[text]
  if text in EN_TRANSLATIONS:return EN_TRANSLATIONS[text]
  # Translate common composed phrases without altering numerical values.
  for old,new in [('Okres rozliczeniowy:','Payroll period:'),('Tygodnie ISO:','ISO weeks:'),('Zaimportowane karty:','Imported cards:'),('Zaznaczone:','Selected:'),('Pominięte:','Excluded:'),('Wpisów:','Entries:'),('Podróże:','Travel:'),('dni','days'),('tyg.','weeks'),('Do weryfikacji:','Review required:'),(' dat bez kraju;',' dates without country;'),(' dat z kilkoma krajami.',' dates with multiple countries.'),('SUMA:','TOTAL:'),('Rok ISO ','ISO year '),('Każdy kolorowy pasek oznacza tydzień przypisany do miesiąca rozliczeniowego. Przewijaj w pionie i poziomie.','Each colored bar represents a week assigned to a payroll month. Scroll vertically and horizontally.'),('Podróże:','Travel:')]:
   text=text.replace(old,new)
  for old,new in [('Październik','October'),('Wrzesień','September'),('Styczeń','January'),('Luty','February'),('Marzec','March'),('Kwiecień','April'),('Maj','May'),('Czerwiec','June'),('Lipiec','July'),('Sierpień','August'),('Listopad','November'),('Grudzień','December')]:
   text=text.replace(old,new)
  for old,new in EN_TRANSLATIONS.items():
   if old in ('Polska','Włochy','Belgia','Hiszpania','Francja','Niemcy','Holandia','Dania','Finlandia','Wielka Brytania'):
    text=text.replace(old,new)
  return text
 def _update_navigation(self):
  for key,btn in self.nav_buttons.items():btn.configure(text='  '+self.tr(key))
  if hasattr(self,'logout_btn'):
   self.logout_btn.configure(text='  '+('Log out' if self.language=='en' else 'Wyloguj się'))
 def set_language(self,language):
  if language not in ('pl','en') or language==self.language:return
  self.language=language;self.db['language']=language;save(self.db)
  self._update_navigation();self.sidebar_title.configure(text=self.tr('PANEL NAWIGACYJNY'));self.draw_banner();self.show(self.page)
 def _translate_widgets(self,parent):
  for w in parent.winfo_children():
   try:
    if isinstance(w,(tk.Label,tk.Button,tk.Checkbutton,tk.Radiobutton)):
     value=w.cget('text')
     if value:w.configure(text=self.tr(value))
    if isinstance(w,ttk.Notebook):
     for tab in w.tabs():w.tab(tab,text=self.tr(w.tab(tab,'text')))
    if isinstance(w,ttk.Treeview):
     for col in w['columns']:w.heading(col,text=self.tr(w.heading(col,'text')))
   except tk.TclError:pass
   self._translate_widgets(w)
 def _is_descendant(self,widget,ancestor):
  while widget is not None:
   if widget is ancestor:return True
   widget=getattr(widget,'master',None)
  return False
 def _route_mousewheel(self,event):
  """Scroll the hovered sidebar, nested page or table; do not require focus/click."""
  if event.widget.winfo_toplevel() is not self.root:return
  try:
   hovered=self.root.winfo_containing(event.x_root,event.y_root) or event.widget
  except (AttributeError,tk.TclError):hovered=event.widget
  # Let Treeview/combobox/text controls use their native wheel behavior.
  current=hovered
  while current is not None:
   if isinstance(current,(ttk.Treeview,tk.Text,tk.Listbox)):
    return
   current=getattr(current,'master',None)
  delta=getattr(event,'delta',0)
  if getattr(event,'num',0)==4:direction=-1
  elif getattr(event,'num',0)==5:direction=1
  elif delta:direction=-max(1,round(abs(delta)/120)) if delta>0 else max(1,round(abs(delta)/120))
  else:return
  shift=bool(event.state & 1)
  if self._is_descendant(hovered,self.side):
   canvas=self.side_canvas
  else:
   canvas=None
   for candidate in (getattr(self,'settings_canvas',None),getattr(self,'calendar_canvas',None)):
    if candidate is not None and candidate.winfo_exists() and self._is_descendant(hovered,candidate.master):
     canvas=candidate;break
   if canvas is None and self._is_descendant(hovered,self.view):canvas=self.main_canvas
  if canvas is None:return
  # Horizontal wheel scrolling with Shift when an x-scrollbar is available.
  if shift and canvas is not self.side_canvas:
   if canvas.xview()!=(0.0,1.0):canvas.xview_scroll(direction*3,'units')
   else:self.main_canvas.xview_scroll(direction*3,'units')
  else:
   first,last=canvas.yview()
   if last-first<0.999:canvas.yview_scroll(direction*3,'units')
   elif canvas is not self.main_canvas and canvas is not self.side_canvas:
    self.main_canvas.yview_scroll(direction*3,'units')
  return 'break'
 def _schedule_scrollbars(self):
  if getattr(self,'_scroll_update_pending',False):return
  self._scroll_update_pending=True
  self.root.after_idle(self._update_scrollbars)
 def _recheck_page_scrollbars(self):
  # Tk geometry may be temporarily stale when a cached page is re-packed.
  # Refresh after the first idle layout AND after it has stabilized.
  # Increment a generation token so earlier page transitions cannot override
  # the scrollbar state of the newly visible page.
  generation=getattr(self,'_page_geometry_generation',0)+1
  self._page_geometry_generation=generation
  for delay in (45,140,320):
   def after_layout(generation=generation):
    if (not self.root.winfo_exists() or
        generation!=self._page_geometry_generation):return
    self._schedule_scrollbars()
   self.root.after(delay,after_layout)
 def _update_scrollbars(self):
  self._scroll_update_pending=False
  if not self.main_canvas.winfo_exists():return
  c=self.main_canvas
  cw=max(1,c.winfo_width());ch=max(1,c.winfo_height())
  # Measure the current page, not the previous page's stale canvas-window height.
  if not self.main.winfo_exists():return
  # Tk recalculates requested geometry during idle; avoid forcing
  # all idle layout handlers to run synchronously on every page switch.
  if self.page=='Ustawienia':
   # Settings has its own canvas and two scrollbars. The surrounding canvas
   # must stay viewport-sized or the INNER horizontal bar ends up off-screen.
   content_w,content_h=cw,ch
  else:
   content_w=max(1,self.main.winfo_reqwidth())
   content_h=max(1,self.main.winfo_reqheight())
  c.itemconfigure(self.main_window,width=max(cw,content_w),height=max(ch,content_h))
  c.configure(scrollregion=(0,0,max(cw,content_w),max(ch,content_h)))
  need_x=content_w>cw+3
  need_y=content_h>ch+3
  if need_x and not self.main_xscroll.winfo_manager():self.main_xscroll.pack(side='bottom',fill='x',before=c)
  elif not need_x and self.main_xscroll.winfo_manager():self.main_xscroll.pack_forget();c.xview_moveto(0)
  if need_y and not self.main_yscroll.winfo_manager():self.main_yscroll.pack(side='right',fill='y',before=c)
  elif not need_y and self.main_yscroll.winfo_manager():self.main_yscroll.pack_forget();c.yview_moveto(0)
  side_needed=self.side_content.winfo_reqheight()>self.side_canvas.winfo_height()+3
  if side_needed and not self.side_scroll.winfo_manager():self.side_scroll.pack(side='right',fill='y',before=self.side_canvas)
  elif not side_needed and self.side_scroll.winfo_manager():self.side_scroll.pack_forget();self.side_canvas.yview_moveto(0)
 def _resize_content(self,event):
  self._schedule_scrollbars()
 def draw_banner(self,event=None):
  c=self.banner;c.delete('all')
  w=max(c.winfo_width(),1);h=max(c.winfo_height(),1)
  try:
   banner_kind=(self.language,self.theme_mode)
   if not hasattr(self,'banner_source') or getattr(self,'banner_source_kind',None)!=banner_kind:
    base=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
    # Keep the original English-localized header until a matching approved
    # translation of the new light artwork is available.
    image_name=('marine_header_en.jpg' if self.language=='en' else
                'marine_header_light.jpg' if self.theme_mode=='light' else
                'marine_header.jpg')
    self.banner_source=Image.open(base/image_name).convert('RGB')
    self.banner_source_kind=banner_kind
   src=self.banner_source
   # Banner artwork already contains the title and subtitle.
   # Fit the ENTIRE composition into the header: do not center-crop the emblem.
   # Stretch only slightly to the current header aspect ratio.
   resized=src.resize((w,h),Image.Resampling.LANCZOS)
   self.banner_photo=ImageTk.PhotoImage(resized)
   c.create_image(0,0,anchor='nw',image=self.banner_photo)
  except Exception:c.create_rectangle(0,0,w,h,fill=NAVY,outline='')
  c.create_rectangle(0,h-3,w,h,fill=GOLD,outline='')
 def label(self,parent,text,size=11,color=WHITE,bold=False,**kw):return tk.Label(parent,text=self.tr(text),bg=parent.cget('bg'),fg=color,font=('Segoe UI',size,'bold' if bold else 'normal'),**kw)
 def button(self,parent,text,cmd,color=GREEN):return tk.Button(parent,text=self.tr(text),command=cmd,bg=color,fg=WHITE,font=('Segoe UI',10,'bold'),relief='flat',bd=0,highlightthickness=0,padx=round(15*self.ui_scale),pady=round(9*self.ui_scale),activebackground=GOLD,activeforeground=NAVY)
 def frame(self,parent= None):return tk.Frame(parent or self.main,bg=PANEL,highlightbackground='#365b72',highlightthickness=1)
 def _apply_interface_theme(self):
  """Presentation only; never changes payroll calculation or stored work cards."""
  self.root._payroll_theme_mode=self.theme_mode
  apply_ui_theme(self.root,self.theme_mode,popup=False)
  apply_ui_style(self.style,self.theme_mode)
  # All sidebar surfaces must follow the light theme, including the canvas
  # beneath its navigation buttons. This is presentation-only.
  if self.theme_mode == 'light':
   sidebar_bg='#edf4fa'
   for area in (self.side,self.side_canvas,self.side_content):
    area.configure(bg=sidebar_bg)
   self.sidebar_title.configure(bg=sidebar_bg,fg='#173f61')
   for name,btn in self.nav_buttons.items():
    if name==self.page:
     btn.configure(bg='#f4c664',fg='#102b43',activebackground='#e8b24b',
                   activeforeground='#102b43',image=self.nav_icons_light.get(name))
    else:
     btn.configure(bg='#ffffff',fg='#173f61',activebackground='#dceaf6',
                   activeforeground='#173f61',image=self.nav_icons_light.get(name))
   self.logout_btn.configure(bg='#ffffff',fg='#9b641c',activebackground='#dceaf6',
                             activeforeground='#173f61',image=self.nav_icons_light['logout'])
  else:
   # The original dark palette and icon assets remain unchanged.
   for name,btn in self.nav_buttons.items():
    btn.configure(image=self.nav_icons.get(name))
   self.logout_btn.configure(image=self.nav_icons['logout'])
  update_caption(self.root)
  for child in self.root.winfo_children():
   if isinstance(child,tk.Toplevel) and hasattr(child,'_refresh_payroll_theme'):
    child._refresh_payroll_theme()

 def set_interface_theme(self,mode):
  if mode not in ('dark','light') or self.theme_mode==mode:return
  self.theme_mode=mode
  # Session-only preference. The next start always uses dark mode.
  # Do not rewrite payroll/user data for a purely visual toggle.
  self._apply_interface_theme()
  self.draw_banner()
  self.show(self.page)

 def theme_switch(self,toolbar):
  """Dashboard control in the upper-right of the SECOND toolbar row."""
  pane=tk.Frame(toolbar,bg=NAVY)
  pane.pack(side='right',padx=(10,4))
  self.label(pane,'Motyw:' if self.language=='pl' else 'Theme:',10,MUTED).pack(side='left',padx=(0,5))
  for mode,text in (('dark','Ciemny' if self.language=='pl' else 'Dark'),
                    ('light','Jasny' if self.language=='pl' else 'Light')):
   active=(self.theme_mode==mode)
   tone='#173449' if active else WHITE
   art=icon_image(self.root,'moon' if mode=='dark' else 'sun',self.theme_mode,round(16*self.ui_scale),color=tone)
   btn=tk.Button(pane,text=f' {text}',command=lambda m=mode:self.set_interface_theme(m),
                 bg='#b9dff5' if active else PANEL2,fg='#173449' if active else WHITE,
                 padx=11,pady=7,relief='flat',bd=0,font=('Segoe UI',10,'bold' if active else 'normal'),
                 image=art,compound='left')
   btn.image=art
   btn.pack(side='left',padx=2)

 def language_flags(self,parent):
  flags=tk.Frame(parent,bg=parent.cget('bg'));flags.pack(side='right',padx=(10,2))
  if not hasattr(self,'flag_images'):
   # Vector masters are packaged in wektory_svg. Tk gets high-res RGBA renders.
   self.flag_images={code:image_photo(self.root,'flag_'+code,36,24) for code in ('pl','en')}
  for code in ('pl','en'):
   tk.Button(flags,image=self.flag_images[code],command=lambda lang=code:self.set_language(lang),bg=PANEL2 if self.language==code else parent.cget('bg'),activebackground=PANEL2,bd=2 if self.language==code else 0,relief='solid' if self.language==code else 'flat',cursor='hand2',padx=3,pady=3).pack(side='left',padx=3)
 def _page_cache_token(self,page):
  common=(DATA_REVISION,self.language,self.theme_mode)
  if page=='Karty pracy':return common+(getattr(self,'_card_filter_year','Wszystkie lata'),)
  if page=='Kalendarz':
   return common+(getattr(self,'calendar_selected_year',int(self.month.get()[:4])),)
  if page=='Zestawienie do A1':
   return common+(self.month.get()[:4],)
  return common+(self.month.get(),)

 def show(self,page):
  _page_start=perf_monotonic()
  # Invalidate only views that depend on the selected accounting period.
  # Card lists are independent of month; A1/calendar depend on selected year.
  # Settings, Dashboard, Payroll, Summary and History DO depend on month.
  token=self._page_cache_token(page)
  old=self._active_page_frame
  if old is not None and old.winfo_exists():old.pack_forget()
  entry=self._page_frames.get(page)
  if entry and entry[1]==token and entry[0].winfo_exists():
   panel=entry[0]
   self.main=panel
   self.page=page
   panel.pack(fill='both',expand=True)
   self.main_canvas.xview_moveto(0);self.main_canvas.yview_moveto(0)
   self._active_page_frame=panel
   self.root.after_idle(self._schedule_scrollbars)
   self._recheck_page_scrollbars()
   self.root.after_idle(self._apply_interface_theme)
   performance_measure("page_render",_page_start,page=page,cache="hit")
   return
  if entry:
   if entry[0].winfo_exists():entry[0].destroy()
   del self._page_frames[page]
  panel=tk.Frame(self.page_host,bg=NAVY)
  self._page_frames[page]=(panel,token)
  self.main=panel
  self.page=page
  panel.pack(fill='both',expand=True)
  self._active_page_frame=panel
  self.main_canvas.xview_moveto(0);self.main_canvas.yview_moveto(0)
  special=page in ('Zestawienie do A1','Kalendarz')
  if not special:
   head=tk.Frame(self.main,bg=NAVY);head.pack(fill='x',pady=(2,12))
   if page=='Pulpit' and self.theme_mode=='light':
    heading=tk.Frame(head,bg=NAVY);heading.pack(side='left')
    home_icon=icon_image(self.root,'home','light',round(28*self.ui_scale))
    house=tk.Label(heading,image=home_icon,bg=NAVY)
    house.image=home_icon;house.pack(side='left',padx=(4,5))
    tk.Label(heading,text=self.tr(page).upper(),font=('Segoe UI',17,'bold'),bg=NAVY,fg='#123c67').pack(side='left')
   else:
    self.label(head,self.tr(page).upper(),17,GOLD,True).pack(side='left')
   self.language_flags(head)
  # Import and payroll toolbar only on relevant pages.
  # A1 and Kalendarz have their own independent period controls.
  self.root.after_idle(self._schedule_scrollbars)
  if page in ('Pulpit','Karty pracy','Podsumowanie'):
   self.button(head,'+ Importuj karty Excel',self.add_files).pack(side='right',padx=5)
   add_folder_btn=self.button(head,'Dodaj folder',self.choose_folder,PANEL2)
   add_folder_btn.configure(image=self.folder_icon,compound='left',text='  '+self.tr('Dodaj folder'))
   add_folder_btn.pack(side='right',padx=5)
   refresh_btn=self.button(head,'Odśwież folder',self.refresh_folder,PANEL2)
   refresh_btn.configure(image=self.refresh_icon,compound='left',text='  '+self.tr('Odśwież folder'))
   refresh_btn.pack(side='right',padx=5)
  if page not in ('Karty pracy','Zestawienie do A1','Kalendarz'):
   toolbar=tk.Frame(self.main,bg=NAVY)
   toolbar.pack(fill='x',pady=(0,12))
   self.label(toolbar,'Miesiąc rozliczeniowy:',10,MUTED).pack(side='left')
   month_btn=self.button(toolbar,'Wybierz miesiąc',lambda:self.pick_month(toolbar),PANEL2)
   month_btn.configure(image=self.calendar_icon,compound='left',text='  '+self.tr('Wybierz miesiąc'))
   month_btn.pack(side='left',padx=9)
   self.label(toolbar,self.month.get(),11,WHITE,True).pack(side='left',padx=7)
   if page=='Pulpit':
    self.label(toolbar,'Stanowisko:',10,MUTED).pack(side='left',padx=(18,4))
    position_box=ttk.Combobox(toolbar,textvariable=self.position,values=POSITIONS,state='readonly',width=23)
    position_box.pack(side='left',padx=7)
    position_box.bind('<<ComboboxSelected>>',self.set_position)
    self.theme_switch(toolbar)
   # Same accounting calendar drives monthly hours AND monthly salary.
   if page in ('Pulpit','Rozliczenie'):
    try:
     yy,mm=map(int,self.month.get().split('-'))
     ws=calendar_for(self.db,yy).get(str(mm),[])
     if ws:
      first=dt.date.fromisocalendar(yy,min(ws),1)
      last=dt.date.fromisocalendar(yy,max(ws),7)
      self.label(self.main,f'Okres rozliczeniowy: {MONTHS[mm-1]} {yy}  |  Tygodnie ISO: '+', '.join(f'W{w:02d}' for w in ws)+f'  |  {first:%d.%m.%Y} – {last:%d.%m.%Y}',10,MUTED).pack(anchor='w',pady=(0,8))
     else:
      self.label(self.main,'Brak przypisanych tygodni w kalendarzu rozliczeniowym — uzupełnij kalendarz.',10,'#ffb28e').pack(anchor='w',pady=(0,8))
    except (ValueError,TypeError):pass

  try:
   rows=self.current() if page in ('Pulpit','Rozliczenie','Podsumowanie') else []
   if page in ('Pulpit','Rozliczenie'):
    leave_report=self.leave_report(rows)
    month_cfg=self.cfg_for_month()
    month_cfg['_leave_variable_pay']=leave_report['variable_amount'] if leave_report['complete'] else 0.
    result=calc(rows,month_cfg)
    self._tax_preview_cache[(DATA_REVISION,self.month.get())]=result[7]
    t,days,rate,extra,gross,social,health,taxable,pit,ppk,net=result
    progress=month_cfg.get('_ytd_progress',{})
    if progress.get('missing_months'):
     absent=', '.join(progress['missing_months'])
     warning=(f'INCOMPLETE PAYROLL HISTORY: missing data for {absent}. '
              'PIT/ZUS balances and bank transfer may be too high or too low. '
              'Fill in the historical settings or reconcile payslip balances.' if self.language=='en' else
              f'NIEPEŁNA HISTORIA ROZLICZEŃ: brak danych za {absent}. '
              'Narastające PIT/ZUS oraz prognoza przelewu mogą być zawyżone lub zaniżone. '
              'Uzupełnij ustawienia historyczne albo potwierdź salda z paskiem płacowym.')
     self.label(self.main,warning,10,'#ffcb85',wraplength=1050,justify='left').pack(anchor='w',padx=12,pady=6)
  except MissingAnnualLimit as e:
   note=('Official pension/disability base cap unavailable for the selected year. The net-pay estimate is disabled; check official ZUS limits online.' if self.language=='en' else str(e))
   self.label(self.main,note,11,'#ffcb85',wraplength=1050,justify='left').pack(anchor='w',padx=12,pady=10)
   return
  except Exception as e:self.label(self.main,str(e),11,'#ff9292').pack();return
  if page=='Pulpit':
   # Preview tools are available only in the Payroll page.
   strip=tk.Frame(self.main,bg=NAVY);strip.pack(fill='x')
   # Real icon artworks on the LEFT of each tile; NEVER change payroll inputs.
   for icon,title,value,prominent in [
      ('coins','PENSJA PODSTAWOWA BRUTTO',money(self.cfg_for_month()['salary']),False),
      ('wallet','PROGNOZA PRZELEWU',money(net) if rows else self.tr('Brak danych'),True),
      ('clock','NADGODZINY A',f'{t["A"]:g} h',False),
      ('double_clock','NADGODZINY B',f'{t["B"]:g} h',False)]:
    metric_card(strip,self.tr(title),value,icon,self.theme_mode,self.root,
                self.ui_scale,prominent=prominent)
   attach_leave_dashboard(self, self.main, save)
   if int(self.month.get()[:4])>=2027:
    note=('2027 PIT reform (12/24/32%) is still a proposal. Forecast uses the currently enacted 12/32% scale and must be verified after publication.' if self.language=='en' else 'Skala PIT na 2027 r. (12/24/32%) pozostaje projektem. Prognoza używa obecnej skali 12/32% i wymaga ponownej weryfikacji po publikacji ustawy.')
    self.label(self.main,note,10,'#ffd08a',wraplength=1050).pack(anchor='w',padx=12,pady=4)
   if not month_cfg.get('_company_calendar_verified'):
    note=('Company calendar has not been supplied for this year. Hourly rates use Polish statutory calendar — verify with employer.' if self.language=='en' else 'Brak kalendarza firmowego dla wybranego roku. Stawka godzinowa opiera się na kalendarzu ustawowym — sprawdź z firmą.')
    self.label(self.main,note,10,'#ffd08a',wraplength=1050).pack(anchor='w',padx=12,pady=4)
   if leave_report['hours'] and not leave_report['complete']:
    self.label(self.main,self.tr('Brak danych z części wymaganych miesięcy. Nie doliczono zmiennej części urlopu do prognozy. Sprawdź karty pracy i okresy rozliczeniowe.'),10,'#ffd08a',wraplength=1100).pack(anchor='w',padx=12,pady=5)
   self.button(self.main,'✎  Zmień pensję podstawową',lambda:self.show('Ustawienia'),PANEL2).pack(anchor='e',padx=5,pady=5)
   if self.theme_mode=='light':
    pane=tk.Frame(self.main,bg='#ffffff',highlightthickness=1,highlightbackground='#b7cce0')
   else:
    pane=self.frame()
   pane.pack(fill='both',expand=True,pady=12)
   section_heading(pane,self.tr('PODSUMOWANIE MIESIĄCA'),'chart',self.theme_mode,
                   self.root,self.ui_scale)
   travel_parts=list(travel_breakdown(rows).values())
   travel_before=sum(v[0] for v in travel_parts)
   travel_deducted=sum(v[1] for v in travel_parts)
   travel_after=sum(v[2] for v in travel_parts)
   total_hours=sum(t[k] for k in ('N','A','B','P','T'))
   from monthly_summary import visible_monthly_summary
   summary=visible_monthly_summary(
       t,travel_before,travel_deducted,travel_after,days,
       leave_report['hours'],month_cfg,total_hours,
       day_unit=self.tr('dni'),night_unit=('nights' if self.language=='en' else 'nocy'))
   # Keep formatter keys untouched: these pictures are presentation only.
   row_art={'Godziny normalne N — kalendarz':'calendar',
            'Nadgodziny A — dodatek 50%':'clock',
            'Nadgodziny B — dodatek 100%':'double_clock',
            'Godziny nocne PN':'moon',
            'Czas podróży przed odliczeniem':'plane',
            'Czas podróży po odliczeniu':'plane',
            'Offshore':'ship',
            'Urlop (h)':'umbrella',
            'Wspólna kabina — liczba nocy':'calendar',
            'Dodatek do diety — liczba dni':'calendar',
            'Podróż samochodem — liczba dodatków':'car',
            'Łączna liczba godzin':'chart'}
   for row_index,(key,value) in enumerate(summary):
    light=self.theme_mode=='light'
    back=('#eef5fb' if row_index%2==0 else '#ffffff') if light else PANEL
    line=tk.Frame(pane,bg=back)
    line.pack(fill='x',padx=6 if light else 20,pady=1 if light else 5)
    art=icon_image(self.root,row_art.get(key,'chart'),self.theme_mode,
                   round(19*self.ui_scale))
    icon_widget=tk.Label(line,image=art,bg=back)
    icon_widget.image=art
    icon_widget.pack(side='left',padx=(13 if light else 0,8))
    tk.Label(line,text=self.tr(key),bg=back,
             fg='#203e57' if light else MUTED,
             font=('Segoe UI',11)).pack(side='left',pady=6 if light else 0)
    tk.Label(line,text=value,bg=back,
             fg='#0e355b' if light else WHITE,
             font=('Segoe UI',11,'bold')).pack(side='right',padx=16 if light else 0,pady=6 if light else 0)
  elif page=='Karty pracy':
   attach_card_validation(self,self.main)
   years=sorted({r['date'][:4] for r in self.db['rows'] if supported_date(r.get('date'))},reverse=True)
   filter_bar=tk.Frame(self.main,bg=NAVY);filter_bar.pack(fill='x',padx=10,pady=(0,8))
   tk.Label(filter_bar,text=('Show year:' if self.language=='en' else 'Wyświetl rok:'),bg=NAVY,fg=WHITE,font=('Segoe UI',10,'bold')).pack(side='left',padx=(0,9))
   year_var=tk.StringVar(value=getattr(self,'_card_filter_year','Wszystkie lata'))
   choices=['Wszystkie lata']+years
   if year_var.get() not in choices:year_var.set('Wszystkie lata')
   selector=ttk.Combobox(filter_bar,textvariable=year_var,values=choices,state='readonly',width=17)
   selector.pack(side='left')
   def set_card_year(_event=None):
    self._card_filter_year=year_var.get()
    self.show('Karty pracy')
   selector.bind('<<ComboboxSelected>>',set_card_year)
   # The work-card content blends into the page instead of sitting inside
   # a second bordered panel with a redundant heading.
   pane=tk.Frame(self.main,bg=NAVY);pane.pack(fill='both',expand=True,pady=0)
   self.label(pane,'Kliknij pole ✓, aby włączyć lub wyłączyć kartę z obliczeń. Zaznaczenie wiersza pokazuje szczegóły.',10,MUTED).pack(anchor='w',padx=12,pady=(0,5))
   cols=('✓','Tydzień','Karta pracy / plik','Data','Godz. prac','Godz. podr','Nadgodziny','Razem','Status')
   row_font=tkfont.Font(root=self.root,family='Segoe UI',size=10)
   filenames=[str(r.get('file') or self.db.get('files',{}).get(r.get('file_id'),'—'))
              for r in self.db['rows'] if supported_date(r.get('date')) and
                     (getattr(self,'_card_filter_year','Wszystkie lata')=='Wszystkie lata' or r['date'][:4]==self._card_filter_year)]
   file_width=max([310]+[row_font.measure(name)//self.ui_scale+38 for name in filenames])
   tree=self.table(pane,cols,{'✓':52,'Tydzień':105,'Karta pracy / plik':file_width,
                                  'Data':130,'Godz. prac':117,'Godz. podr':117,
                                  'Nadgodziny':130,'Razem':100,'Status':95},
                   fixed_columns=True,fill_available_width=True)
   self.tree=tree
   grouped=defaultdict(list)
   for r in self.db['rows']:
    if supported_date(r.get('date')) and (year_var.get()=='Wszystkie lata' or r['date'][:4]==year_var.get()):grouped[r['file_id']].append(r)
   excluded=set(self.db.get('excluded_files',[]))
   self.card_file_ids={}
   for i,(fid,items) in enumerate(sorted(grouped.items(),key=lambda kv:(max(r['date'] for r in kv[1]),kv[1][0].get('file','')),reverse=True),1):
    first=min(items,key=lambda r:r['date']);date=dt.date.fromisoformat(first['date'])
    yy,ww,_=date.isocalendar()
    normal=sum(float(r.get('N',0)) for r in items)
    travel=sum(float(r.get('P',0))+float(r.get('T',0)) for r in items)
    overtime=sum(float(r.get('A',0))+float(r.get('B',0)) for r in items)
    total=normal+travel+overtime
    # Name is optional in older imports; do not invent employee identity.
    employee=next((str(r.get('employee','')).strip() for r in items if str(r.get('employee','')).strip()),'—')
    vals=('☐' if fid in excluded else '☑',f'{ww:02d}',first.get('file',self.db['files'].get(fid,'—')),date.strftime('%d.%m.%Y'),f'{normal:g}',f'{travel:g}',f'{overtime:g}',f'{total:g}','OK')
    iid=tree.insert('','end',values=vals)
    self.card_file_ids[iid]=fid
   footer=tk.Frame(pane,bg=PANEL2);footer.pack(fill='x',padx=9,pady=(0,3))
   status=tk.StringVar()
   details=tk.StringVar(value=self.tr('Wybierz kartę pracy, aby zobaczyć jej zakres dat i liczbę wpisów.'))
   self.label(footer,'SZCZEGÓŁY KARTY',10,GOLD,True).pack(anchor='w',padx=12,pady=(9,3))
   tk.Label(footer,textvariable=details,bg=PANEL2,fg=WHITE,font=('Segoe UI',10),anchor='w',justify='left',wraplength=1100).pack(fill='x',padx=12,pady=(0,8))
   def refresh_status():
    n=len(grouped);active=sum(fid not in set(self.db.get('excluded_files',[])) for fid in grouped)
    status.set(self.tr(f'Zaimportowane karty: {n}    |    Zaznaczone: {active}    |    Pominięte: {n-active}'))
   def on_select(_=None):
    selection=tree.selection()
    if not selection:return
    fid=self.card_file_ids[selection[0]];items=grouped[fid]
    dates=[dt.date.fromisoformat(r['date']) for r in items]
    details.set(self.tr(f'{min(dates):%d.%m.%Y} – {max(dates):%d.%m.%Y}   |   Wpisów: {len(items)}   |   {self.db["files"].get(fid,items[0].get("file",""))}'))
   def on_click(event):
    iid=tree.identify_row(event.y);col=tree.identify_column(event.x)
    if not iid or col!='#1':return
    fid=self.card_file_ids[iid];excluded=set(self.db.get('excluded_files',[]))
    if fid in excluded:excluded.remove(fid)
    else:excluded.add(fid)
    self.db['excluded_files']=sorted(excluded);save(self.db)
    tree.set(iid,'✓','☐' if fid in excluded else '☑')
    refresh_status()
   def open_card(event):
    iid=tree.identify_row(event.y)
    if not iid:return
    fid=self.card_file_ids.get(iid)
    if not fid:return
    self._open_original_card(grouped[fid])
   tree.bind('<Double-1>',open_card)
   tree.bind('<<TreeviewSelect>>',on_select)
   tree.bind('<ButtonRelease-1>',on_click,add='+')
   actions=tk.Frame(pane,bg=PANEL);actions.pack(fill='x',padx=10,pady=2)
   tk.Label(actions,textvariable=status,bg=PANEL,fg=MUTED,font=('Segoe UI',10)).pack(side='left')
   self.button(actions,'Usuń wybraną kartę',self.delete_selected,'#9c5050').pack(side='right')
   refresh_status()
  elif page=='Podsumowanie':
   self.show_summary(rows)
  elif page=='Zestawienie do A1':
   self.show_a1()
  elif page=='Kalendarz':
   self.show_calendar()
  elif page=='Rozliczenie':
   attach_preview_tools(self,self.main,include_pdf=True)
   pane=self.frame();pane.pack(fill='both',expand=True);self.label(pane,'📄  '+self.tr('SZCZEGÓŁY ROZLICZENIA'),15,GOLD,True).pack(anchor='w',padx=20,pady=12)
   deductions=payroll_breakdown(rows,month_cfg,result)
   if month_cfg.get('ppe_auto_enabled') or month_cfg.get('ppo_auto_enabled'):
    warning=('Employer PPE/PPO are ESTIMATES from known pay elements; missing bonuses and retro payment dates can change the actual contribution base. Verify against the payslip.' if self.language=='en' else 'PPE/PPO pracodawcy to SZACUNEK ze znanych składników wynagrodzenia. Inne premie i przesunięcia wypłat mogą zmienić podstawę; porównaj wynik z paskiem.')
    self.label(pane,warning,10,'#ffd08a',wraplength=1050,justify='left').pack(anchor='w',padx=20,pady=(0,6))
   self.label(pane,'🏖  '+self.tr('URLOP WYPOCZYNKOWY'),13,GOLD,True).pack(anchor='w',padx=20,pady=(5,5))
   self.label(pane,f'{self.tr("Godziny urlopu (h)")}: {leave_report["hours"]:g}   |   {self.tr("Dni urlopu")}: {leave_report["days"]}',11,WHITE).pack(anchor='w',padx=20,pady=(0,5))
   if leave_report['estimated']:
    self.label(pane,self.tr('SZACUNEK: zmienna część urlopu jest automatycznie obliczona z nadgodzin i godzin faktycznej pracy. Przypisanie do miesiąca wypłaty jest niepotwierdzone; sprawdź z paskiem płacowym.'),10,'#ffd08a',wraplength=1050).pack(anchor='w',padx=20,pady=(0,6))
   if leave_report['hours'] and not leave_report['complete']:
    self.label(pane,self.tr('Brakuje kart lub przypisania tygodni w miesiącach podstawy urlopowej. Zmienna część urlopu nie została doliczona.'),10,'#ffd08a',wraplength=1050).pack(anchor='w',padx=20,pady=(0,6))
   if leave_report['complete']:
    self.label(pane,f'{self.tr("Wynagrodzenie urlopowe — część zmienna")}: {money(leave_report["variable_amount"])}'+('  (szacunek)' if leave_report['estimated'] and self.language=='pl' else '  (estimated)' if leave_report['estimated'] else '  (potwierdzone)' if self.language=='pl' else '  (verified)'),11,WHITE,True).pack(anchor='w',padx=20,pady=(0,5))
   self.button(pane,'Szczegóły / korekta danych',lambda:self.open_leave_basis_editor(rows),PANEL2).pack(anchor='w',padx=20,pady=(4,12))
   overtime_detail=overtime_components(rows,month_cfg.get('_rate_for_date',lambda _:rate))
   travel_detail=travel_breakdown(rows)
   data=[('Stała pensja podstawowa brutto',self.cfg_for_month()['salary']),('Stawka godzinowa',rate),('Liczba nadgodzin A (h)',t['A']),('Liczba nadgodzin B (h)',t['B']),('Liczba godzin podróży T przed (h)',sum(v[0] for v in travel_detail.values())),('Liczba godzin odliczonych (h)',sum(v[1] for v in travel_detail.values())),('Liczba godzin podróży T po (h)',sum(v[2] for v in travel_detail.values())),('1700 — wynagrodzenie za nadgodziny 100%',overtime_detail['all_base']),('1711 — dodatek A 50%',overtime_detail['premium_a']),('1721 — dodatek B 100%',overtime_detail['premium_b']),('Dodatek PN za pracę w nocy (20% minimum)',night_bonus_detail(rows)['amount']),('Podróże T po — dodatek 50%',travel_bonus(rows,month_cfg)),('Offshore',days*month_cfg['offshore']),('Podróż autem',month_cfg.get('car_bonus_count',0)*400),('Wspólna kabina',month_cfg.get('shared_room_nights',0)*100),('1746 — dodatek do diety 55 zł/dzień (brutto)',month_cfg.get('domestic_diet_extra_days',0)*55),('Ryzyko',month_cfg.get('risk_days',0)*230*month_cfg.get('risk_factor',1)),('Dodatek C — wyrównanie UE (brutto)',month_cfg.get('eu_c_allowance',0)),('ZFŚS — świadczenie gotówkowe',month_cfg.get('zfss_cash',0)),('ZFŚS — część zwolniona z PIT',deductions['zfss_exempt']),('ZFŚS — część opodatkowana',deductions['zfss_taxable']),('Dodatki razem (z urlopowym, gdy oszacowane)',extra),('Wynagrodzenie brutto (gotówkowe)',gross),('Emerytalne pracownika (9,76%)',-deductions['emerytalna']),('Rentowe pracownika (1,50%)',-deductions['rentowa']),('Chorobowe pracownika (2,45%)',-deductions['chorobowa']),('Składka zdrowotna (9%)',-health),('Podstawa PIT (0 = nie wyznaczana w symulacji)',taxable),('Zaliczka PIT',-pit),('PPK',-ppk),('PPE dodatkowe',-month_cfg.get('ppe_extra',0)),('Pozostałe potrącenia',-month_cfg.get('other_deductions',0)),('ŚWIADCZENIA POZAPŁACOWE — NIE DODAWAĆ DO PRZELEWU',0),('Edenred — osobna karta (nie przelew)',month_cfg.get('edenred_benefit',0)),('LuxMed — świadczenie niepieniężne',month_cfg.get('luxmed_benefit',0)),('PPE pracodawcy — osobny rachunek',deductions['employer_ppe']),('PPO pracodawcy — osobny rachunek',deductions['employer_ppo']),('Razem świadczenia poza przelewem',sum(month_cfg.get(k,0) for k in ('edenred_benefit','luxmed_benefit'))+deductions['employer_ppe']+deductions['employer_ppo']),('PROGNOZA PRZELEWU',net)]
   for name,value in data:
    line=tk.Frame(pane,bg=PANEL);line.pack(fill='x',padx=20,pady=5);self.label(line,name,11,GOLD if 'PRZELEWU' in name else MUTED,'PRZELEWU' in name).pack(side='left');self.label(line,(self.tr('Brak danych') if name=='PROGNOZA PRZELEWU' and not rows else (f'{value:g} h' if name.startswith('Liczba ') else money(value))),12,GOLD if 'PRZELEWU' in name else WHITE,True).pack(side='right')
   if night_bonus_detail(rows)['unpriced_hours']>0:
    self.label(pane,'Nieznana stawka dodatku PN dla części godzin — nie uwzględniono ich w prognozie. Sprawdź minimalne wynagrodzenie dla roku pracy.',10,'#ffd08a',wraplength=1000).pack(anchor='w',padx=20,pady=5)
   self.button(pane,'Eksport rozliczenia',lambda:__import__('payroll_export').export_month_report_dialog(self),GREEN).pack(anchor='e',padx=20,pady=10)
  elif page=='Historia':
   pane=self.frame();pane.pack(fill='both',expand=True);self.label(pane,'HISTORIA GODZIN Z ZAIMPORTOWANYCH KART',14,GOLD,True).pack(anchor='w',padx=16,pady=15)
   months=defaultdict(list)
   excluded=set(self.db.get('excluded_files',[]))
   for row in self.db['rows']:
    if row.get('file_id') in excluded or not supported_date(row.get('date')):continue
    period=accounting_month(row['date'],self.db)
    if period:months[period].append(row)
   for m in sorted(months,reverse=True):
    mr=months[m]
    yyyy,mm=map(int,m.split('-'))
    regular=nominal_for_calendar_month(yyyy,mm,self.db)
    a=sum(float(r.get('A',0) or 0) for r in mr)
    b=sum(float(r.get('B',0) or 0) for r in mr)
    travel=sum(float(r.get('P',0) or 0)+float(r.get('T',0) or 0) for r in mr)
    offshore=len({r['date'] for r in mr if r.get('work_type')==9})
    self.label(pane,f'{m}    N (kalendarz): {regular:g} h     A: {a:g} h     B: {b:g} h     Podróże: {travel:g} h     Offshore: {offshore} dni',11,WHITE).pack(anchor='w',padx=16,pady=8)
   for special_period in sorted((self.db.get('monthly_special_payments') or {}),reverse=True):
    if not isinstance(special_period,str):continue
    try: special=get_special_month(self.db,special_period)
    except ValueError:continue
    if special['eu_c_allowance'] or special['zfss_cash']:
     self.label(pane,f'{special_period}    Dodatek C: {money(special["eu_c_allowance"])}    |    ZFŚS: {money(special["zfss_cash"])}',11,WHITE).pack(anchor='w',padx=16,pady=5)
   self.label(pane,'N pochodzi z kalendarza miesiąca; A/B z kart pracy według tygodni rozliczeniowych. Nie są to archiwalne wypłaty.',10,MUTED,wraplength=800).pack(anchor='w',padx=16,pady=20)
  elif page=='Ustawienia':
   self.show_settings()
  if self.language=='en':self._translate_widgets(self.main)
  self.root.after_idle(self._apply_interface_theme)
  self._recheck_page_scrollbars()
  performance_measure("page_render",_page_start,page=page,cache="miss")
 def pick_month(self,parent):
  popup=tk.Toplevel(self.root);theme_popup(popup,self);popup.title(self.tr('Wybierz miesiąc'));popup.configure(bg=PANEL)
  schedule_navy_titlebar(popup,background=PANEL,foreground="#ffffff")
  popup.transient(self.root);popup.resizable(False,False)
  popup.geometry(f'292x272+{parent.winfo_rootx()+135}+{parent.winfo_rooty()+34}')
  y,m=map(int,self.month.get().split('-'))
  year=tk.IntVar(value=y)
  top=tk.Frame(popup,bg=PANEL);top.pack(fill='x',padx=10,pady=10)
  month_cells=[]
  def refresh_year():
   title.config(text=str(year.get()))
   for number,square,button in month_cells:
    active=(number==m and year.get()==y)
    square.configure(bg='#e9b54f' if active else '#55768e')
    button.configure(bg='#b9dff5' if active else PANEL2,fg=NAVY if active else WHITE)

  tk.Button(top,text='◀',command=lambda:(year.set(year.get()-1),refresh_year()),bg=PANEL2,fg=WHITE,bd=0,width=4).pack(side='left')
  title=tk.Label(top,text=str(y),bg=PANEL,fg=GOLD,font=('Segoe UI',14,'bold'));title.pack(side='left',expand=True)
  tk.Button(top,text='▶',command=lambda:(year.set(year.get()+1),refresh_year()),bg=PANEL2,fg=WHITE,bd=0,width=4).pack(side='right')
  grid=tk.Frame(popup,bg=PANEL);grid.pack(padx=9,pady=5)
  def choose(mm):
   self.month.set(f'{year.get()}-{mm:02d}');popup.destroy();self.show(self.page)
  for i,name in enumerate(MONTHS,1):
   selected=i==m and year.get()==y
   border='#e9b54f' if selected else '#55768e'
   square=tk.Frame(grid,bg=border,bd=0,padx=1,pady=1)
   square.grid(row=(i-1)//3,column=(i-1)%3,padx=3,pady=3,sticky='nsew')
   button=tk.Button(square,text=(['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][i-1] if self.language=='en' else name[:3]),
                    width=8,command=lambda i=i:choose(i),bg='#b9dff5' if selected else PANEL2,
                    fg=NAVY if selected else WHITE,bd=0,relief='flat',pady=7,
                    activebackground='#e2eff8',activeforeground=NAVY)
   button.pack(fill='both',expand=True)
   month_cells.append((i,square,button))
  popup.grab_set()
 def show_settings(self):
  # Oddzielny przewijany formularz, bez ukrywania pól w ciasnym oknie.
  outer=self.frame();outer.pack(fill='both',expand=True)
  cv=tk.Canvas(outer,bg=PANEL,highlightthickness=0)
  self.settings_canvas=cv
  self.settings_horizontal_scroll=None
  sy=ttk.Scrollbar(outer,orient='vertical',command=cv.yview)
  sx=ttk.Scrollbar(outer,orient='horizontal',command=cv.xview)
  self.settings_horizontal_scroll=sx
  cv.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
  outer.grid_rowconfigure(0,weight=1)
  outer.grid_columnconfigure(0,weight=1)
  cv.grid(row=0,column=0,sticky='nsew')
  content=tk.Frame(cv,bg=PANEL)
  win=cv.create_window((0,0),window=content,anchor='nw')
  def sync_settings_scroll():
   if not cv.winfo_exists():return
   needed_y=content.winfo_reqheight()>cv.winfo_height()+2
   needed_x=max(round(1100*self.ui_scale),content.winfo_reqwidth())>cv.winfo_width()+2
   # Grid positions keep scrollbars accessible even in a small window.
   if needed_y:sy.grid(row=0,column=1,sticky='ns')
   else:sy.grid_remove();cv.yview_moveto(0)
   if needed_x:sx.grid(row=1,column=0,sticky='ew')
   else:sx.grid_remove();cv.xview_moveto(0)
  def layout_settings(event=None):
   if not cv.winfo_exists():return
   width=max(round(1100*self.ui_scale),content.winfo_reqwidth(),cv.winfo_width()-8)
   cv.itemconfigure(win,width=width)
   cv.configure(scrollregion=cv.bbox('all'))
   self.root.after_idle(sync_settings_scroll)
  cv.bind('<Configure>',layout_settings)
  content.bind('<Configure>',layout_settings)
  self.root.after(180,layout_settings)
  self.label(content,'USTAWIENIA WYNAGRODZENIA',17,GOLD,True).grid(row=0,column=0,columnspan=3,sticky='w',padx=22,pady=(20,7))
  self.label(content,self.tr('Pensja zasadnicza jest zapisywana od wybranego miesiąca. Import kart pracy jej nie zmienia.'),11,MUTED,wraplength=720).grid(row=1,column=0,columnspan=3,sticky='w',padx=22,pady=(0,18))
  fields=[('salary','STAŁA PENSJA PODSTAWOWA BRUTTO (zł)'),('offshore','Offshore brutto za dzień (zł)'),('travel_rate','Dodatek podróżny jako ułamek stawki godzinowej (0,5 = 50%)'),('costs','Koszty uzyskania przychodu (zł)'),('pit_relief','Miesięczne zmniejszenie zaliczki PIT (zł)'),('social_limit','Roczny limit podstawy emerytalno-rentowej (zł)'),('ppk','PPK pracownika (%)'),('benefits_in_social','Edenred i LuxMed w podstawie ZUS/PIT (1=tak, 0=nie)'),('employer_pension_taxable','PPE i PPO pracodawcy w podstawie PIT (1=tak, 0=nie)'),('edenred_benefit','Edenred — świadczenie pozapłacowe z paska (zł)'),('luxmed_benefit','LuxMed — świadczenie pozapłacowe z paska (zł)'),('ppe_auto_enabled','Nalicz PPE pracodawcy 3,5% (1=tak, 0=nie)'),('ppo_auto_enabled','Nalicz PPO pracodawcy 0,5% (1=tak, 0=nie)'),('ppe_employer_override','Korekta PPE pracodawcy z paska (0=automatycznie)'),('ppo_employer_override','Korekta PPO pracodawcy z paska (0=automatycznie)'),('ppe_extra','PPE dodatkowe — potrącenie z przelewu (zł)'),('car_bonus_count','Liczba zatwierdzonych dodatków za jazdę autem (400 zł)'),('shared_room_nights','Liczba kwalifikowanych nocy w pokoju dwuosobowym (100 zł)'),('domestic_diet_extra_days','Liczba dni dodatku do diety (55 zł/dzień)'),('risk_days','Dni wysokiego ryzyka (po zatwierdzeniu)'),('risk_factor','Współczynnik ryzyka (1 / 0,75 / 0,5 / 0,25)'),('other_gross','Inne dodatki brutto / korekty (zł)'),('eu_c_allowance','Dodatek C — wyrównanie UE (brutto, miesiąc WYPŁATY)'),('zfss_cash','ZFŚS — świadczenie socjalne (gotówka, miesiąc WYPŁATY)'),('other_deductions','Pozostałe potrącenia z przelewu (zł)')]
  # Read-only information; there is no manual switch or manual-hours entry.
  y,m=map(int,self.month.get().split('-'))
  nominal_hours=nominal_for_calendar_month(y,m,self.db)
  info=tk.Frame(content,bg=PANEL)
  info.grid(row=2,column=0,columnspan=3,sticky='w',padx=22,pady=(0,8))
  self.label(info,self.tr('Nominał godzin:'),11,MUTED).pack(side='left')
  self.label(info,f' {nominal_hours} h — '+(self.tr('Z kalendarza firmowego 2026') if has_confirmed_company_schedule(y) else self.tr('automatycznie według kalendarza PL')),11,WHITE).pack(side='left')
  self.nominal_info_icon=image_photo(self.root,'info',20)
  from payroll_help import open_parameter_help
  tk.Button(info,image=self.nominal_info_icon,command=lambda:open_parameter_help(self.root,'nominal',self.tr('Nominał godzin'),self.language),bg=PANEL,activebackground=PANEL,relief='flat',bd=0,highlightthickness=0,cursor='hand2').pack(side='left',padx=(12,0))
  cfg_preview=self.cfg_for_month()
  preview_key=(DATA_REVISION,self.month.get())
  if preview_key not in self._tax_preview_cache:
   try:
    self._tax_preview_cache[preview_key]=calc(self.current(),cfg_preview)[7]
   except Exception:
    # Never show a made-up tax band if the calculation is unavailable.
    self._tax_preview_cache[preview_key]=None
  if len(self._tax_preview_cache)>48:
   self._tax_preview_cache={preview_key:self._tax_preview_cache[preview_key]}
  preview_taxable=self._tax_preview_cache[preview_key]
  tax_pct,_state=(bracket_name(cfg_preview.get('ytd_tax_base',0),preview_taxable,y)
                  if preview_taxable is not None else ('—','UNAVAILABLE'))
  progress=cfg_preview.get('_ytd_progress',{})
  if progress.get('missing_months'):
   missing=', '.join(progress['missing_months'])
   note=(f'Missing data: {missing}. Tax/ZUS estimates unreliable.' if self.language=='en'
         else f'Brak danych za {missing}. Szacunek PIT/ZUS jest niewiarygodny.')
  else:
   note=('Estimate — incomplete work-card history' if self.language=='en' else 'Szacunek — niepełne dane z kart pracy') if progress.get('status')!='confirmed' else ('From confirmed payslip balance' if self.language=='en' else 'Na podstawie potwierdzonego paska płacowego')
  if y>=2027:
   note+=(' · 2027 three-band PIT reform not yet in force' if self.language=='en' else ' · trójstopniowa skala PIT 2027 jeszcze nie obowiązuje')
  status=tk.Frame(content,bg=PANEL)
  status.grid(row=3,column=0,columnspan=3,sticky='w',padx=22,pady=(2,8))
  self.label(status,('Estimated PIT band: ' if self.language=='en' else 'Prognozowany próg PIT: ')+tax_pct,12,GOLD,True).pack(side='left',padx=(0,12))
  self.label(status,note,9,MUTED,wraplength=340).pack(side='left',padx=(0,12))
  self.button(status,('Reconcile with payslip' if self.language=='en' else 'Uzgodnij z paskiem'),self.reconcile_payslip_balances,PANEL2).pack(side='left')
  self.vars={}
  # One shared High-DPI icon, individually clickable for every settings row.
  self.settings_info_icon=image_photo(self.root,'info',22)
  for i,(key,desc) in enumerate(fields,start=4):
   self.label(content,self.tr(desc),11,GOLD if key=='salary' else WHITE,key=='salary').grid(row=i,column=0,sticky='w',padx=(22,12),pady=10)
   stored_value=self.cfg_for_month().get(key,self.db.get(key,0))
   shown=('—' if stored_value is None else f'{stored_value:.2f}'.replace('.',','))
   v=tk.StringVar(value=shown);self.vars[key]=v
   if key=='social_limit':
    cell=tk.Frame(content,bg=PANEL)
    cell.grid(row=i,column=1,sticky='w',padx=12,pady=(6,10))
   else:
    cell=content
   ent=tk.Entry(cell,textvariable=v,width=22,font=('Segoe UI',13 if key=='salary' else 11,'bold' if key=='salary' else 'normal'),bg='#ffffff',fg='#142b3b',relief='solid',bd=1)
   if key=='social_limit':
    ent.pack(anchor='w',ipady=5)
    ent.configure(state='readonly',readonlybackground='#dae6ec',fg='#153e51',cursor='arrow')
    source=source_for_year(y,self.db.get('social_limits_cache'))
    hint=('Automatically for '+str(y)+' · '+('officially published' if source else 'not yet published') if self.language=='en' else 'Automatycznie dla '+str(y)+' r. · '+('wartość urzędowa' if source else 'brak potwierdzonej wartości'))
    line=tk.Frame(cell,bg=PANEL)
    line.pack(anchor='w',pady=(6,0))
    self.label(line,hint,9,MUTED).pack(side='left',padx=(0,8))
    self.button(line,('Check ZUS online' if self.language=='en' else 'Sprawdź ZUS online'),lambda:self._start_limit_refresh(manual=True),PANEL2).pack(side='left')
   else:
    ent.grid(row=i,column=1,sticky='w',padx=12,pady=10,ipady=5)
   from payroll_help import open_parameter_help
   tk.Button(content,image=self.settings_info_icon,command=lambda k=key,t=desc:open_parameter_help(self.root,k,self.tr(t),self.language),
             bg=PANEL,activebackground=PANEL,relief='flat',bd=0,highlightthickness=0,cursor='hand2',
             takefocus=True).grid(row=i,column=2,sticky='w',padx=(0,18),pady=8)
  self.label(content,('Dodatek C i ZFŚS wpisz w miesiącu rzeczywistej wypłaty; nie przechodzą na kolejne miesiące. ZFŚS: tylko świadczenie pieniężne w całości z funduszu i przyznane według kryteriów socjalnych. Limit zwolnienia PIT 1 000 zł w roku; bez składek ZUS/zdrowotnej.' if self.language=='pl' else 'Enter C and ZFSS in the month of actual payment; they never carry forward. ZFSS: qualifying fund-financed cash benefits only. Annual PIT exemption PLN 1,000; social/health exempt.'),10,MUTED,wraplength=960,justify='left').grid(row=len(fields)+4,column=0,columnspan=3,sticky='w',padx=22,pady=(8,1))
  save_row=len(fields)+5
  self.button(content,'ZAPISZ USTAWIENIA',self.apply_settings).grid(row=save_row,column=0,sticky='w',padx=22,pady=(13,12))
  self.label(content,'AUTOMATYCZNY IMPORT KART PRACY',15,GOLD,True).grid(row=save_row+1,column=0,columnspan=3,sticky='w',padx=22,pady=(23,8))
  self.label(content,'Folder główny „Karta pracy” (podfoldery 2026, 2027 itd.)',11,WHITE).grid(row=save_row+2,column=0,sticky='w',padx=22,pady=8)
  self.auto_folder_var=tk.StringVar(value=self.db.get('auto_root',''))
  auto_line=tk.Frame(content,bg=PANEL);auto_line.grid(row=save_row+2,column=1,sticky='w',padx=12)
  folder_entry=tk.Entry(auto_line,textvariable=self.auto_folder_var,width=44,font=('Segoe UI',10),bg='white',fg=NAVY)
  folder_entry.pack(side='left',padx=(0,8),ipady=5)
  folder_entry.bind('<Return>',lambda _e:self._apply_auto_folder_selection())
  folder_entry.bind('<FocusOut>',lambda _e:self._apply_auto_folder_selection())
  self.button(auto_line,'Przeglądaj...',self._browse_auto_root,PANEL2).pack(side='left')
  tk.Button(auto_line,image=self.settings_info_icon,command=lambda:open_parameter_help(self.root,'auto_root',('Main work-card folder' if self.language=='en' else 'Folder główny kart pracy'),self.language),bg=PANEL,activebackground=PANEL,relief='flat',bd=0,highlightthickness=0,cursor='hand2').pack(side='left',padx=(12,0))
  self.auto_enabled_var=tk.IntVar(value=int(bool(self.db.get('auto_import',1))))
  tk.Checkbutton(content,text=self.tr('Automatycznie synchronizuj karty pracy przy uruchomieniu'),variable=self.auto_enabled_var,command=self._on_auto_import_toggle,bg=PANEL,fg=WHITE,selectcolor=PANEL2,activebackground=PANEL,activeforeground=WHITE,font=('Segoe UI',11)).grid(row=save_row+3,column=0,columnspan=2,sticky='w',padx=22,pady=8)
  tk.Button(content,image=self.settings_info_icon,command=lambda:open_parameter_help(self.root,'auto_import',('Automatic work-card import' if self.language=='en' else 'Automatyczny import kart pracy'),self.language),bg=PANEL,activebackground=PANEL,relief='flat',bd=0,highlightthickness=0,cursor='hand2').grid(row=save_row+3,column=2,sticky='w',padx=(0,18),pady=8)
  self.label(content,'BEZPIECZEŃSTWO KONTA',15,GOLD,True).grid(row=save_row+4,column=0,columnspan=3,sticky='w',padx=22,pady=(20,8))
  security_actions=tk.Frame(content,bg=PANEL)
  security_actions.grid(row=save_row+5,column=0,columnspan=3,sticky='w',padx=22,pady=(4,8))
  def security_help():
   if self.language=='en':
    title='Help — account security'
    body=('CHANGE PIN\nEnter your current PIN, new PIN (6–20 digits) and confirmation.\n\n'
          'CHANGE EMAIL\nEnter the first part of your Gmail address (the @gmail.com suffix cannot be edited) and your current PIN. The application sends a verification code to the new address; check Spam as well. The change is applied only after code confirmation.\n\n'
          'VERIFY EMAIL\nConfirm your PIN, then enter the six-digit code sent to your email.\n\n'
          'RECOVER PIN\nOn the login screen choose email verification or your saved emergency code.')
   else:
    title='Pomoc — bezpieczeństwo konta'
    body=('ZMIANA PIN-U\nWpisz aktualny PIN, następnie nowy PIN (6–20 cyfr) i jego potwierdzenie.\n\n'
          'ZMIANA ADRESU E-MAIL\nWpisz początek adresu Gmail (domena @gmail.com jest stała) i aktualny PIN. Program wyśle kod na nowy adres. Sprawdź również folder Spam. Zmiana nastąpi po potwierdzeniu kodu.\n\n'
          'WERYFIKACJA ADRESU E-MAIL\nPotwierdź PIN i wpisz sześciocyfrowy kod wysłany na adres e-mail.\n\n'
          'ODZYSKIWANIE PIN-U\nNa ekranie logowania wybierz kod wysłany e-mailem albo zapisany kod awaryjny.')
   messagebox.showinfo(title,body,parent=self.root)
  security_actions_list=[
   ('Zmień PIN',lambda:__import__('ach_security').change_pin_dialog(self.root)),
   ('Zmień adres e-mail',lambda:__import__('ach_security').change_email_dialog(self.root)),
   ('Zweryfikuj adres e-mail',lambda:__import__('ach_security').verify_existing_email_dialog(self.root)),
  ]
  for label,action in security_actions_list:
   self.button(security_actions,label,action).pack(side='left',padx=(0,13))
  # Vector-based antialiased help symbol. Do not draw a 27-px canvas circle.
  self.help_icon=image_photo(self.root,'help',27)
  icon=tk.Button(security_actions,image=self.help_icon,command=security_help,bg=PANEL,activebackground=PANEL,relief='flat',bd=0,highlightthickness=0,cursor='hand2',takefocus=1)
  icon.pack(side='left',padx=(0,0))
  # Errors never disappear from the report even if the startup popup is hidden.
  self.label(content,('WORK CARD SYNCHRONIZATION REPORT' if self.language=='en' else 'RAPORT SYNCHRONIZACJI KART PRACY'),15,GOLD,True).grid(row=save_row+6,column=0,columnspan=3,sticky='w',padx=22,pady=(22,8))
  issues_line=tk.Frame(content,bg=PANEL)
  issues_line.grid(row=save_row+7,column=0,columnspan=3,sticky='w',padx=22,pady=(2,8))
  self.button(issues_line,('Show all synchronization issues' if self.language=='en' else 'Pokaż wszystkie problemy synchronizacji'),lambda:self._show_sync_issues(manual=True),PANEL2).pack(side='left',padx=(0,15))
  self.button(issues_line,('Enable startup alerts' if self.language=='en' else 'Włącz ponownie powiadomienia'),self._enable_sync_issues,PANEL2).pack(side='left')
  count=len(self.db.get('last_sync_issues') or [])
  self.label(content,(f'Last scan: {count} issue(s); dismissing alerts does not fix import errors.' if self.language=='en' else f'Ostatni skan: {count} problemów. Ukrycie okna nie naprawia błędów importu.'),10,MUTED).grid(row=save_row+8,column=0,columnspan=3,sticky='w',padx=22,pady=(0,12))
  # Re-evaluate overflow after Tk finishes laying out the newly selected page.
  self.root.after(80,self._schedule_scrollbars)
  self.root.after(250,self._schedule_scrollbars)
 def logout(self):
  """Lock current session without deleting persistent data or restarting the process."""
  if not messagebox.askyesno('Wylogowanie','Wylogować się i wrócić do ekranu PIN?\n\nZapisane dane pozostaną bez zmian.',parent=self.root):return
  import ach_security
  for child in list(self.root.winfo_children()):child.destroy()
  self.root.withdraw()
  if ach_security.gate(self.root):
   App(self.root)
  else:self.root.destroy()
 def _maybe_refresh_annual_limits(self):
  # Non-blocking background check, normally once in 30 days. Known years work
  # immediately from the offline official table, even without Internet access.
  try:
   previous=dt.date.fromisoformat(self.db.get('social_caps_last_checked',''))
   if (dt.date.today()-previous).days<30:return
  except (TypeError,ValueError):pass
  self._start_limit_refresh(manual=False)

 def _start_limit_refresh(self,manual=False):
  if getattr(self,'_limit_fetch_active',False):return
  self._limit_fetch_active=True
  self._limit_fetch_manual=manual
  self._limit_fetch_queue=queue.Queue()
  def worker():
   try:self._limit_fetch_queue.put((fetch_official_limits(timeout=7),None))
   except Exception as exc:self._limit_fetch_queue.put((None,str(exc)))
  threading.Thread(target=worker,daemon=True,name='zus-annual-limit-check').start()
  self.root.after(120,self._poll_limit_refresh)

 def _poll_limit_refresh(self):
  if not self.root.winfo_exists():return
  try:values,error=self._limit_fetch_queue.get_nowait()
  except queue.Empty:
   self.root.after(120,self._poll_limit_refresh)
   return
  self._limit_fetch_active=False
  manual=self._limit_fetch_manual
  today=dt.date.today().isoformat()
  changed=(self.db.get('social_caps_last_checked')!=today)
  self.db['social_caps_last_checked']=today
  added=[];conflicts=[]
  if not error:
   old_cache=self.db.get('social_limits_cache',{})
   updated,added,conflicts=update_verified_cache(old_cache,values)
   if updated!=old_cache:
    self.db['social_limits_cache']=updated
    changed=True
  if changed:save(self.db)
  if manual:
   if error:
    msg=('Cannot connect to the official ZUS site. Embedded published limits remain available.' if self.language=='en' else 'Nie udało się połączyć z oficjalną stroną ZUS. Wbudowane, ogłoszone limity pozostają dostępne.')
    messagebox.showwarning(('ZUS — update' if self.language=='en' else 'ZUS — aktualizacja'),msg,parent=self.root)
   elif conflicts:
    msg=('Conflicting figures on the official site; automatic overwrite was blocked. Verify the legal act.' if self.language=='en' else 'Wykryto rozbieżność z wbudowanym limitem. Automatyczne nadpisanie zostało zablokowane — sprawdź akt prawny.')
    messagebox.showwarning(('ZUS — verification' if self.language=='en' else 'ZUS — weryfikacja'),msg,parent=self.root)
   else:
    msg=(('New official years: '+', '.join(map(str,added))) if self.language=='en' else ('Nowe lata: '+', '.join(map(str,added)))) if added else ('No new officially published limits found.' if self.language=='en' else 'Nie znaleziono nowych oficjalnie ogłoszonych limitów.')
    messagebox.showinfo(('ZUS — update' if self.language=='en' else 'ZUS — aktualizacja'),msg,parent=self.root)
  if added and self.page in ('Ustawienia','Pulpit','Rozliczenie'):
   self.show(self.page)

 def cfg_for_month(self, month_id=None, _skip_progress=False):
  """Effective historical rates with automatic YTD, without mutating saved months."""
  selected_id=month_id or self.month.get()
  if getattr(self,'_month_cfg_revision',None)!=DATA_REVISION:
   self._month_cfg_cache={}
   self._month_cfg_revision=DATA_REVISION
  cache_key=(selected_id,bool(_skip_progress))
  cached=self._month_cfg_cache.get(cache_key)
  if cached is not None:return dict(cached)
  effective_values,_version=active_month_version(self.db,selected_id)
  cfg=dict(self.db)
  cfg.update(effective_values)
  cfg.update(get_special_month(self.db,selected_id))
  cfg['_zfss_prior_year']=zfss_prior(self.db,selected_id)
  year,month=map(int,selected_id.split('-'))
  # For periods from 11/2026 forward, replace the old default 220 with the
  # user-confirmed 230 PLN/day; archived previous periods remain untouched.
  # Other individually chosen values remain exactly as recorded.
  if selected_id >= '2026-11' and float(cfg.get('offshore') or 0)==220.:
   cfg['offshore']=230.
  # 2026 FSE remuneration rules §13: travel premium is 50% of hourly base.
  # Legacy zero was an unconfigured field, not a proven historical exemption.
  if year>=2026 and float(cfg.get('travel_rate') or 0)==0:
   cfg['travel_rate']=0.5
  cfg['auto_nominal']=1.
  cfg['nominal']=nominal_for_calendar_month(year,month,self.db)
  cfg['social_limit']=annual_limit(year,self.db.get('social_limits_cache'))
  cfg['_tax_year']=year
  cfg['_company_calendar_verified']=has_confirmed_company_schedule(year)
  cfg['reference_payslip_mode']=False
  if not _skip_progress:
   progress=opening_balances(self.db,selected_id,
       lambda p:self.cfg_for_month(p,_skip_progress=True),calc,accounting_month)
   cfg['ytd_tax_base']=progress['tax']
   cfg['social_ytd']=progress['social']
   cfg['_ytd_progress']=progress
   def rate_for_date(day):
    try:
     # Work at the boundary of a calendar month belongs to its ISO payroll
     # period. E.g. 28 Sep 2026 is in the 2026-10 (W40–W44) period.
     source_period=accounting_month(day,self.db) or day[:7]
     raw=self.cfg_for_month(source_period,_skip_progress=True)
     return (float(raw['salary'])/float(raw['nominal'])) if raw.get('nominal') else 0.
    except (ValueError,TypeError,KeyError):return 0.
   cfg['_rate_for_date']=rate_for_date
  if len(self._month_cfg_cache)>=48:self._month_cfg_cache.clear()
  self._month_cfg_cache[cache_key]=dict(cfg)
  return dict(cfg)
 def reconcile_payslip_balances(self):
  """Optional verified end-of-month balance; never demand it at each startup."""
  period=self.month.get(); record=self.db.get('payslip_balances',{}).get(period,{})
  popup=tk.Toplevel(self.root);theme_popup(popup,self);popup.title(self.tr('Uzgodnij PIT i ZUS z paskiem płacowym'))
  schedule_navy_titlebar(popup,background=PANEL,foreground="#ffffff")
  popup.configure(bg=PANEL);popup.geometry('535x330');popup.transient(self.root)
  self.label(popup,('PAYSPLIP BALANCE — '+period if self.language=='en' else 'SALDA Z PASKA PŁACOWEGO — '+period),14,GOLD,True).pack(anchor='w',padx=18,pady=(18,12))
  info=('Enter the END-OF-MONTH cumulative PIT and/or pension/disability base. Either field may be left blank; only documented values should be saved.' if self.language=='en' else 'Wpisz narastające wartości na KONIEC wskazanego miesiąca. Możesz uzupełnić tylko ZUS lub tylko PIT. Nie wpisuj wartości niepotwierdzonych jako faktów.')
  self.label(popup,info,10,WHITE,wraplength=490,justify='left').pack(anchor='w',padx=18,pady=(0,12))
  values=[]
  for index,(key,label) in enumerate([('tax',('Cumulative taxable income (PLN)' if self.language=='en' else 'Dochód opodatkowany od początku roku (zł)')),('social',('Annual pension/disability base (PLN)' if self.language=='en' else 'Roczna podstawa emerytalno-rentowa (zł)'))]):
   # Visually group each label with its own white entry. Alternate bands
   # use existing palette colours; only the dialog base is exact #10293c.
   shade='#142f43' if index%2==0 else '#1b394f'
   line=tk.Frame(popup,bg=shade,padx=12,pady=8)
   line.pack(fill='x',padx=18,pady=4)
   self.label(line,label,10,WHITE).pack(side='left')
   v=tk.StringVar(value=('%0.2f'%record[key]).replace('.',',') if key in record else '')
   tk.Entry(line,textvariable=v,width=15,font=('Segoe UI',11),bg='#ffffff',fg='#172e40',
            insertbackground='#172e40',relief='flat').pack(side='right',ipady=3)
   values.append(v)
  def confirmed():
   raw=[v.get().strip().replace(' ','').replace(',','.') for v in values]
   if any(raw):
    try:
     amounts={key:float(value) for key,value in zip(('tax','social'),raw) if value}
     if any(not (0<=v<=100000000) or not math.isfinite(v) for v in amounts.values()):raise ValueError()
    except ValueError:
     messagebox.showerror('Błędne dane','Podaj nieujemne kwoty liczbowe.',parent=popup);return
    self.db.setdefault('payslip_balances',{})[period]=amounts
   else:self.db.setdefault('payslip_balances',{}).pop(period,None)
   save(self.db);popup.destroy();self.show(self.page)
  self.button(popup,('Save verified balances' if self.language=='en' else 'Zapisz wartości z paska'),confirmed,GREEN).pack(side='right',padx=18,pady=12)
  popup.grab_set()
 def _maximize_main_window(self):
  """Open the authenticated app maximized, keeping the normal title bar."""
  if not self.root.winfo_exists():return
  try:
   self.root.state('zoomed')  # Native maximized state on Windows.
  except tk.TclError:
   try:self.root.attributes('-zoomed',True)  # X11 fallback.
   except tk.TclError:
    # Platforms without a native zoom state retain a sizable normal window.
    self.root.geometry(f'{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}+0+0')

 def show_monthly_payroll_reminder(self):
  """Show from day 10; only an explicit opt-out persists across launches."""
  if not self.root.winfo_exists() or self.db.get('hide_reminder_forever'):return
  previous_popup=getattr(self,'_monthly_reminder_popup',None)
  if previous_popup is not None and previous_popup.winfo_exists():
   previous_popup.lift(self.root)
   return
  today=dt.date.today()
  if today.day<10:return
  previous=today.replace(day=1)-dt.timedelta(days=1)
  period=previous.strftime('%Y-%m')
  period_name=(['January','February','March','April','May','June','July','August','September','October','November','December'][previous.month-1] if self.language=='en' else MONTHS[previous.month-1])+' '+str(previous.year)
  popup=tk.Toplevel(self.root)
  theme_popup(popup,self)
  popup.title('Moje Wynagrodzenie' if self.language=='pl' else 'My Payroll')
  popup.configure(bg=NAVY)
  popup.resizable(False,False)
  popup.transient(self.root)
  self._monthly_reminder_popup=popup
  popup.geometry('700x350')
  # Center over the maximized main window without covering the system title bar.
  popup.update_idletasks()
  x=max(0,self.root.winfo_rootx()+(self.root.winfo_width()-700)//2)
  y=max(0,self.root.winfo_rooty()+(self.root.winfo_height()-350)//2)
  popup.geometry(f'700x350+{x}+{y}')
  try:
   from ui_assets import set_window_icon, set_navy_titlebar
   set_window_icon(popup)
   # Preserve the native Windows title, icon and close button; request a dark
   # system caption after the Toplevel has acquired a real Win32 handle.
   popup.after_idle(lambda: set_navy_titlebar(popup, background=NAVY, foreground=WHITE)
                    if popup.winfo_exists() else None)
  except (ImportError, OSError, tk.TclError):pass
  outer=tk.Frame(popup,bg=PANEL,highlightbackground=GOLD,highlightthickness=2)
  outer.pack(fill='both',expand=True,padx=8,pady=8)
  header=tk.Frame(outer,bg=NAVY,height=55)
  header.pack(fill='x');header.pack_propagate(False)
  self.label(header,'Moje Wynagrodzenie' if self.language=='pl' else 'My Payroll',13,WHITE,True).pack(side='left',padx=18,pady=14)
  tk.Button(header,text='✕',font=('Segoe UI',13),command=popup.destroy,bg=NAVY,fg=WHITE,relief='flat',bd=0).pack(side='right',padx=17)
  content=tk.Frame(outer,bg=PANEL);content.pack(fill='both',expand=True,padx=26,pady=(22,12))
  self.label(content,('Przypomnienie o weryfikacji wynagrodzenia' if self.language=='pl' else 'Reminder: verify your salary'),16,GOLD,True,wraplength=620,justify='left').pack(anchor='w',pady=(0,16))
  if self.language=='en':
   msg=f'Check your salary calculation for {period_name} against your payslip. If there are differences, verify your entries in the calculator.'
  else:
   msg=f'Sprawdź rozliczenie wynagrodzenia za {period_name} i porównaj je z paskiem płacowym. W razie rozbieżności zweryfikuj dane w kalkulatorze.'
  self.label(content,msg,12,WHITE,wraplength=615,justify='left').pack(anchor='w')
  footer=tk.Frame(outer,bg=NAVY);footer.pack(side='bottom',fill='x',padx=14,pady=13)
  # The opt-out only saves the preference for FUTURE launches. It must not
  # close the reminder currently on screen; only an X or Close action does.
  hide_var=tk.BooleanVar(master=popup,value=False)
  def change_reminder_preference():
   self.db['hide_reminder_forever']=bool(hide_var.get())
   save(self.db)
  tk.Checkbutton(footer,text='Ukryj — nie pokazuj więcej' if self.language=='pl' else 'Hide — do not show again',
    command=change_reminder_preference,variable=hide_var,bg=NAVY,fg=WHITE,
    activebackground=NAVY,activeforeground=WHITE,selectcolor=PANEL2,
    font=('Segoe UI',10),highlightthickness=0).pack(side='left',padx=5)
  def navigate():
   # Navigation is not consent to dismiss the reminder. Keep it visible
   # until the user explicitly clicks X / Zamknij.
   self.month.set(period)
   self._auto_import_for_year(silent=True)
   self.show('Rozliczenie')
   if popup.winfo_exists():popup.lift(self.root)
  self.button(footer,'Sprawdź rozliczenie' if self.language=='pl' else 'Review payslip',navigate).pack(side='right',padx=5)
  self.button(footer,'Zamknij' if self.language=='pl' else 'Close',popup.destroy,PANEL2).pack(side='right',padx=5)
  # Clicking outside the reminder must never dismiss it. A background
  # click can bring the owner forward on some window managers, so re-raise
  # the transient popup without changing focus or the saved preference.
  def keep_reminder_visible(event):
   if popup.winfo_exists() and event.widget.winfo_toplevel() is self.root:
    self.root.after_idle(lambda:popup.lift(self.root) if popup.winfo_exists() else None)
  click_id=self.root.bind('<Button-1>',keep_reminder_visible,add='+')

  last_size=[(self.root.winfo_width(),self.root.winfo_height())]
  pending_raise=[None]
  def raise_after_resize():
   pending_raise[0]=None
   if not popup.winfo_exists():return
   # The window manager may cover a transient popup when the owner is zoomed.
   x=max(0,self.root.winfo_rootx()+(self.root.winfo_width()-700)//2)
   y=max(0,self.root.winfo_rooty()+(self.root.winfo_height()-350)//2)
   popup.geometry(f'+{x}+{y}')
   popup.lift(self.root)
  def on_main_resize(event):
   if event.widget is not self.root or not popup.winfo_exists():return
   size=(event.width,event.height)
   if size==last_size[0]:return
   last_size[0]=size
   if pending_raise[0] is None:
    pending_raise[0]=self.root.after_idle(raise_after_resize)
  resize_id=self.root.bind('<Configure>',on_main_resize,add='+')
  def on_main_map(event):
   if event.widget is self.root and popup.winfo_exists() and pending_raise[0] is None:
    pending_raise[0]=self.root.after_idle(raise_after_resize)
  map_id=self.root.bind('<Map>',on_main_map,add='+')
  def cleanup(event):
   if event.widget is not popup:return
   self._monthly_reminder_popup=None
   for sequence,binding in (('<Button-1>',click_id),('<Configure>',resize_id),('<Map>',map_id)):
    try:self.root.unbind(sequence,binding)
    except tk.TclError:pass
   if pending_raise[0] is not None:
    try:self.root.after_cancel(pending_raise[0])
    except tk.TclError:pass
  popup.bind('<Destroy>',cleanup,add='+')
  popup.lift(self.root)
  popup.focus_set()

 def leave_report(self,rows=None):
  """Calculate from active cards automatically; payslip overrides are optional."""
  selected=rows if rows is not None else self.current()
  excluded=set(self.db.get('excluded_files',[]))
  all_rows=[r for r in self.db.get('rows',[]) if supported_date(r.get('date')) and r.get('file_id') not in excluded]
  auto=estimate_monthly_variable_history(
      all_rows,lambda day:accounting_month(day,self.db),
      lambda period:self.cfg_for_month(period,_skip_progress=True))
  return calculate_leave_pay(selected,all_rows,
      self.db.get('leave_variable_history',{}),auto)

 def open_leave_basis_editor(self,rows):
  """Optional details and corrections, with card-based values populated automatically."""
  report=self.leave_report(rows)
  target_months=sorted({m for start in report['basis_months'] for m in prior_months(start)})
  if not target_months:
   target_months=sorted(prior_months(self.month.get()))
  dialog=tk.Toplevel(self.root)
  theme_popup(dialog,self,popup_surface='main')
  schedule_navy_titlebar(dialog,background=NAVY,foreground="#ffffff")
  dialog.title(self.tr('Szczegóły / korekta danych'))
  dialog.configure(bg=NAVY)
  dialog.geometry('870x'+str(max(535,min(740,350+49*len(target_months)))))
  dialog.minsize(690,450)
  dialog.transient(self.root)
  from ui_assets import set_window_icon
  try:set_window_icon(dialog)
  except Exception:pass
  self.label(dialog,'Szczegóły / korekta danych',16,GOLD,True).pack(anchor='w',padx=20,pady=(13,5))
  text_pl=('Wartości z kart pracy są pobierane automatycznie. Nie musisz ich przepisywać. '
      'Kwoty zmienne są szacunkiem z nadgodzin A/B, przypisanym do miesiąca rozliczeniowego, '
      'nie potwierdzoną wypłatą. Do korekty wpisz OBA pola z paska płacowego. '
      'Puste pola korekty = użyj wartości automatycznych.')
  text_en=('Values are read automatically from work cards. Estimated variable pay contains '
      'A/B overtime attributed to the accounting month, not verified payment dates. '
      'To correct a month, enter BOTH payslip values. Empty correction fields use automatic data.')
  self.label(dialog,text_en if self.language=='en' else text_pl,10,WHITE,wraplength=820,justify='left').pack(anchor='w',padx=20,pady=(0,13))
  wrapper=tk.Frame(dialog,bg=PANEL)
  wrapper.pack(fill='both',expand=True,padx=20)
  table=tk.Frame(wrapper,bg=PANEL)
  table.pack(fill='x')
  heads=(('Month','Auto variable gross (PLN)','Auto worked (h)','Payslip gross override','Payslip hours override') if self.language=='en' else
        ('Miesiąc','Auto składniki zmienne (zł)','Auto godziny pracy (h)','Korekta kwoty z paska (zł)','Korekta godzin z paska (h)'))
  widths=(12,25,22,24,24)
  for col,head in enumerate(heads):
   self.label(table,head,9,GOLD,True,wraplength=175).grid(row=0,column=col,sticky='w',padx=3,pady=(0,8))
  auto=estimate_monthly_variable_history(
       [r for r in self.db.get('rows',[]) if supported_date(r.get('date')) and r.get('file_id') not in set(self.db.get('excluded_files',[]))],
       lambda day:accounting_month(day,self.db),self.cfg_for_month)
  history=self.db.get('leave_variable_history',{})
  vars_by_month={}
  for i,month in enumerate(target_months,1):
   calculated=auto.get(month)
   prior=history.get(month,{})
   a=tk.StringVar(value='' if 'paid_variable_gross' not in prior else str(prior['paid_variable_gross']).replace('.',','))
   h=tk.StringVar(value='' if 'worked_hours' not in prior else str(prior['worked_hours']).replace('.',','))
   band_color='#142f43' if i%2 else '#1b394f'
   row_band=tk.Frame(table,bg=band_color,height=45)
   row_band.grid(row=i,column=0,columnspan=5,sticky='nsew',pady=2)
   row_band.grid_propagate(False)
   table.grid_rowconfigure(i,minsize=47)
   self.label(table,month,10,WHITE,True).grid(row=i,column=0,sticky='w',padx=9,pady=5)
   table.grid_slaves(row=i,column=0)[0].configure(bg=band_color)
   auto_pay=(f'{calculated["paid_variable_gross"]:.2f}' if calculated else '—')
   auto_h=(f'{calculated["worked_hours"]:g}' if calculated else '—')
   pay_label=self.label(table,auto_pay,10,WHITE)
   pay_label.configure(bg=band_color);pay_label.grid(row=i,column=1,sticky='w',padx=7)
   hour_label=self.label(table,auto_h,10,WHITE)
   hour_label.configure(bg=band_color);hour_label.grid(row=i,column=2,sticky='w',padx=7)
   for col,v in ((3,a),(4,h)):
    tk.Entry(table,textvariable=v,width=17,font=('Segoe UI',10),bg='#ffffff',fg=NAVY).grid(row=i,column=col,sticky='w',padx=6,pady=5,ipady=4)
   vars_by_month[month]=(a,h)
  self.label(dialog,('The automatic result is an ESTIMATE. Only confirmed payslip amounts and qualified wage components make the basis verifiable.' if self.language=='en' else
    'Automatyczny wynik to SZACUNEK. Ujęto tylko nadgodziny A/B — inne kwalifikujące się dodatki i faktyczne daty wypłat wymagają sprawdzenia. Brak kart oznacza brak danych, nie zero.'),10,'#f5d1a1',wraplength=820).pack(anchor='w',padx=20,pady=(10,7))
  actions=tk.Frame(dialog,bg=PANEL)
  actions.pack(fill='x',padx=20,pady=(5,15))
  def save_history():
   updated=dict(self.db.get('leave_variable_history',{}))
   try:
    for month,(v1,v2) in vars_by_month.items():
     raw_amount=v1.get().strip().replace(' ','').replace(',','.')
     raw_hours=v2.get().strip().replace(' ','').replace(',','.')
     if not raw_amount and not raw_hours:
      updated.pop(month,None)  # Revert manual correction to automatic values.
      continue
     if not raw_amount or not raw_hours:
      raise ValueError(month+': '+('both override fields are required' if self.language=='en' else 'uzupełnij oba pola korekty'))
     amount=float(raw_amount);hours=float(raw_hours)
     if not (0<=amount<10_000_000 and 0<=hours<=744):
      raise ValueError(month+': '+('invalid amount or hours' if self.language=='en' else 'nieprawidłowa kwota lub godziny'))
     updated[month]={'paid_variable_gross':round(amount,2),'worked_hours':hours}
    self.db['leave_variable_history']=updated
    save(self.db)
    dialog.destroy();self.show('Rozliczenie')
   except (ValueError,OverflowError) as exc:
    messagebox.showerror(self.tr('Błędne dane') if self.language=='en' else 'Błędne dane',str(exc),parent=dialog)
  self.button(actions,'Zapisz korekty' if self.language=='pl' else 'Save corrections',save_history,GREEN).pack(side='right',padx=4)
  self.button(actions,'Zamknij' if self.language=='pl' else 'Close',dialog.destroy,PANEL2).pack(side='right',padx=4)
  dialog.bind('<Escape>',lambda _e:dialog.destroy())
  dialog.grab_set()
  dialog.focus_set()

 def set_position(self,event=None):
  self.db['position']=self.position.get()
  save(self.db)
 def table(self,parent,columns,widths=None,fixed_columns=False,fill_available_width=False,fill_weights=None):
  area=tk.Frame(parent,bg=PANEL);area.pack(fill='both',expand=True,padx=9,pady=3)
  tree=ttk.Treeview(area,columns=columns,show='headings',selectmode='browse',style='Payroll.Treeview')
  # Fixed tables keep stable, centered columns at all screen sizes.
  # Widths are based on the translated heading AND the effective Windows DPI.
  heading_font=tkfont.Font(root=self.root,family='Segoe UI',size=10,weight='bold')
  base_column_widths={}
  for col in columns:
   label=self.tr(col)
   base=(widths or {}).get(col,105)
   width=(max(round(base*self.ui_scale),heading_font.measure(label)+round(27*self.ui_scale))
          if fixed_columns else base)
   base_column_widths[col]=width
   tree.heading(col,text=label,anchor='center')
   tree.column(col,width=width,minwidth=width if fixed_columns else 20,
               anchor='center',stretch=not fixed_columns)
  # Only the work-cards list uses dynamic FULL-WINDOW distribution. Every
  # column retains a fixed minimum for readability and manual resizing stays
  # disabled; extra screen space is shared proportionally across all columns.
  tree.kw_base_column_widths=base_column_widths
  if fixed_columns:
   # Returning 'break' suppresses ttk's built-in header separator drag and
   # double-click auto-fit; scrolling, sorting elsewhere and row clicks survive.
   def block_column_resize(event):
    if tree.identify_region(event.x,event.y)=='separator':
     return 'break'
   tree.bind('<Button-1>',block_column_resize,add='+')
   tree.bind('<Double-1>',block_column_resize,add='+')
  sy=ttk.Scrollbar(area,orient='vertical',command=tree.yview);sx=ttk.Scrollbar(area,orient='horizontal',command=tree.xview)
  tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
  tree.grid(row=0,column=0,sticky='nsew')
  area.grid_columnconfigure(0,weight=1);area.grid_rowconfigure(0,weight=1)
  pending=[False]
  def update_table_scrollbars():
   pending[0]=False
   if not tree.winfo_exists():return
   if fill_available_width and fixed_columns and tree.winfo_width()>1:
    available=max(1,tree.winfo_width()-2)  # leave room for the table border
    min_total=sum(base_column_widths.values())
    extra=max(0,available-min_total)
    # Largest-remainder apportionment gives an exact, stable total without
    # introducing an unwanted trailing white strip or rounding drift.
    weights={col:max(1,int((fill_weights or base_column_widths).get(col,1))) for col in columns}
    weight_total=sum(weights.values())
    portions={col:(extra*weights[col]//weight_total) for col in columns}
    remainder=extra-sum(portions.values())
    fractional=sorted(columns,key=lambda col:(extra*weights[col]%weight_total,-columns.index(col)),reverse=True)
    for col in fractional[:remainder]:portions[col]+=1
    for col in columns:
     width=base_column_widths[col]+portions[col]
     if tree.column(col,'width')!=width:
      # Shrink the minwidth first when the window gets narrower again.
      tree.column(col,minwidth=width)
      tree.column(col,width=width)
   first,last=tree.yview()
   # A scrollbar is needed only if not all rows are visible.
   need_y=first>0.0001 or last<0.9999
   # Treeview columns stretch to fill the available width. Compare their
   # actual widths with the visible viewport, not the requested width.
   col_width=sum(tree.column(col,'width') for col in columns)
   need_x=col_width>tree.winfo_width()+3
   if need_y:sy.grid(row=0,column=1,sticky='ns')
   else:sy.grid_remove();tree.yview_moveto(0)
   if need_x:sx.grid(row=1,column=0,sticky='ew')
   else:sx.grid_remove();tree.xview_moveto(0)
  def schedule_table_scrollbars(event=None):
   if not pending[0] and tree.winfo_exists():
    pending[0]=True;tree.after_idle(update_table_scrollbars)
  tree.bind('<Configure>',schedule_table_scrollbars,add='+')
  tree.bind('<Map>',schedule_table_scrollbars,add='+')
  area.bind('<Configure>',schedule_table_scrollbars,add='+')
  tree.tag_configure('stripe_even',background='#ffffff',foreground='#193047')
  tree.tag_configure('stripe_odd',background='#f1f5f9',foreground='#193047')
  tree.tag_configure('total',background='#dcebdc',foreground='#173d2c',font=('Segoe UI',10,'bold'))
  tree.tag_configure('poland',background='#e4eef9',foreground='#143a58',font=('Segoe UI',10,'bold'))
  original_insert=tree.insert
  stripe_index=[0]
  def striped_insert(parent,index,**kw):
   tags=list(kw.pop('tags',()))
   if not tags:
    tags=['stripe_even' if stripe_index[0]%2==0 else 'stripe_odd']
   stripe_index[0]+=1
   result=original_insert(parent,index,tags=tuple(tags),**kw)
   schedule_table_scrollbars()
   return result
  tree.insert=striped_insert
  schedule_table_scrollbars()
  # Configure/Map and the coalesced idle callback handle later layout.
  return tree
 def _original_card_path(self,items):
  """Find the actual XLSX, preferring a recorded absolute source path."""
  for r in items:
   path=r.get('source_path')
   if path and Path(path).is_file():return Path(path)
  for r in items:
   name=r.get('file') or self.db.get('files',{}).get(r.get('file_id'))
   if not name:continue
   # Fallback paths for archives imported before absolute paths were stored.
   roots=[Path(self.db.get('folder',''))] if self.db.get('folder') else []
   if self.db.get('auto_root'):
    roots += [Path(self.db['auto_root']),Path(self.db['auto_root'])/r['date'][:4]]
   for root in roots:
    path=root/name
    if path.is_file():return path
  return None

 def _open_original_card(self,items):
  path=self._original_card_path(items)
  if not path:
   messagebox.showwarning('Nie znaleziono pliku','Nie znaleziono oryginalnej karty Excel. Wskaż folder kart pracy i odśwież import.')
   return False
  try:
   if sys.platform=='win32':os.startfile(str(path.resolve()))
   else:__import__('subprocess').Popen(['xdg-open',str(path.resolve())])
   return True
  except (OSError,ValueError) as exc:
   messagebox.showerror('Nie można otworzyć Excel',f'Nie można otworzyć oryginalnego pliku:\n{path}\n{exc}')
   return False

 def choose_week_card(self,source_cards):
  """Choose a workbook only when the aggregated week has >1 source file."""
  dialog=tk.Toplevel(self.root)
  theme_popup(dialog,self)
  schedule_navy_titlebar(dialog,background=NAVY,foreground="#ffffff")
  dialog.title(self.tr('Wybierz kartę pracy'))
  dialog.configure(bg=NAVY)
  dialog.transient(self.root)
  dialog.resizable(False,False)
  try:
   from ui_assets import set_window_icon
   set_window_icon(dialog)
  except (OSError,tk.TclError):pass
  prompt=('This week contains multiple Excel files. Select one:' if self.language=='en'
          else 'Ten tydzień zawiera kilka kart pracy. Wybierz plik do otwarcia:')
  tk.Label(dialog,text=prompt,bg=NAVY,fg=WHITE,
           font=('Segoe UI',11,'bold')).pack(anchor='w',padx=16,pady=(16,8))
  box=tk.Listbox(dialog,width=65,height=min(10,len(source_cards)),
                 font=('Segoe UI',11),selectmode='browse',
                 bg='#eaf3f9',fg='#092238',activestyle='none',
                 selectbackground='#b9dff5')
  box.pack(fill='both',expand=True,padx=16,pady=(0,10))
  for group in source_cards:
   record=group[0]
   name=record.get('file') or self.db.get('files',{}).get(record.get('file_id'),'—')
   box.insert('end',name)
  box.selection_set(0)
  def open_selected(_event=None):
   selection=box.curselection()
   if not selection:return
   rows=source_cards[selection[0]]
   dialog.destroy()
   self._open_original_card(rows)
  box.bind('<Double-1>',open_selected)
  box.bind('<Return>',open_selected)
  actions=tk.Frame(dialog,bg=NAVY);actions.pack(fill='x',padx=16,pady=(0,15))
  self.button(actions,'Anuluj',dialog.destroy,PANEL2).pack(side='right')
  self.button(actions,'Otwórz w Excelu',open_selected,GREEN).pack(side='right',padx=(0,10))
  dialog.grab_set()
  box.focus_set()

 def show_summary(self,rows):
  tabs=ttk.Notebook(self.main,style='Payroll.TNotebook');tabs.pack(fill='both',expand=True)
  daily=tk.Frame(tabs,bg=PANEL);weekly=tk.Frame(tabs,bg=PANEL);tabs.add(daily,text='Podsumowanie dzienne');tabs.add(weekly,text='Podsumowanie tygodniowe')
  # Disable keyboard focus decoration on tabs; mouse selection remains functional.
  tabs.configure(takefocus=False)
  tabs.bind('<<NotebookTabChanged>>',lambda _event: self.root.after_idle(lambda: self.root.focus_set() if self.root.winfo_exists() else None),add='+')
  groups=defaultdict(list)
  for r in rows:groups[r['date']].append(r)
  cols=('Data','Dzień','Kraj','N (KP)','A','B','PN','T przed odl.','T odlicz.','T po odl.','Offshore','Urlop (h)','Praca w morzu')
  table_area=tk.Frame(daily,bg=PANEL)
  country_font=tkfont.Font(root=self.root,family='Segoe UI',size=10)
  by_day_countries=[', '.join(sorted({self.tr(r.get('country','') or 'BRAK') for r in items}))
                    for items in groups.values()]
  country_width=max([145]+[country_font.measure(name)//self.ui_scale+32
                           for name in by_day_countries])
  tree=self.table(table_area,cols,{
   'Data':112,'Dzień':112,'Kraj':country_width,'N (KP)':69,'A':53,'B':53,'PN':53,
   'T przed odl.':105,'T odlicz.':96,'T po odl.':91,
   'Offshore':90,'Urlop (h)':84,'Praca w morzu':118},fixed_columns=True,fill_available_width=True,
   fill_weights={'Data':5,'Dzień':4,'Kraj':7,'N (KP)':1,'A':1,'B':1,'PN':1,'T przed odl.':1,'T odlicz.':1,'T po odl.':1,'Offshore':2,'Urlop (h)':2,'Praca w morzu':2})
  travel_days=travel_breakdown(rows)
  leave_days=leave_hours_by_day(rows)
  for day,items in sorted(groups.items()):
   total={k:sum(float(r.get(k,0)) for r in items) for k in ['N','A','B','PN','P','T']}
   countries=', '.join(sorted({self.tr(r.get('country','') or 'BRAK') for r in items}))
   d=dt.date.fromisoformat(day)
   weekdays=['Poniedziałek','Wtorek','Środa','Czwartek','Piątek','Sobota','Niedziela']
   vals=[d.strftime('%d.%m.%Y'),self.tr(weekdays[d.weekday()]),countries]+[f'{total[k]:g}' for k in ['N','A','B','PN']]+[f'{travel_days[day][i]:g}' for i in range(3)]+[str(int(any(r.get('work_type')==9 for r in items))),f'{leave_days.get(day,0):g}',
         ('YES' if self.language=='en' else 'TAK') if any(r.get('sea_work',False) for r in items) else ('NO' if self.language=='en' else 'NIE')]
   tree.insert('','end',iid=day,values=vals)
  # Reserve a persistent lower section for the comment; the table alone scrolls.
  details=tk.Frame(daily,bg='#fff2bf',highlightbackground='#d8b65a',highlightthickness=1)
  details.pack(side='bottom',fill='x',padx=9,pady=(0,2))
  tk.Label(details,text=self.tr('KOMENTARZ DNIA — INSTALACJA / NR ZLECENIA'),bg='#fff2bf',fg='#795710',font=('Segoe UI',10,'bold')).pack(anchor='w',padx=10,pady=(4,2))
  note=tk.StringVar(value=self.tr('Wybierz dzień z tabeli, aby zobaczyć instalację i numer zlecenia.'))
  tk.Label(details,textvariable=note,bg='#fff2bf',fg='#27384a',font=('Segoe UI',10),anchor='w',justify='left',wraplength=950).pack(fill='x',padx=10,pady=(0,4),ipady=2)
  table_area.pack(side='top',fill='both',expand=True,padx=0,pady=(0,1))
  source_jobs={}
  def jobs_for_day(day):
   jobs=[]
   for r in groups.get(day,[]):
    job=str(r.get('job') or '').strip()
    if not job:
     path=r.get('source_path')
     if not path:
      folder=self.db.get('folder','')
      if folder:path=str(Path(folder)/r.get('file',''))
     if path and Path(path).is_file():
      if path not in source_jobs:
       try:source_jobs[path]=read_xlsx(path)
       except Exception:source_jobs[path]=[]
      for fresh in source_jobs[path]:
       if fresh['date']==day:
        value=str(fresh.get('job') or '').strip()
        if value:jobs.append(value)
    elif job:jobs.append(job)
   return list(dict.fromkeys(jobs))
  def selected(_):
   sel=tree.selection()
   if not sel:return
   d=sel[0]
   jobs=jobs_for_day(d)
   note.set(dt.date.fromisoformat(d).strftime('%d.%m.%Y')+'  |  '+('  ;  '.join(jobs) if jobs else self.tr('Brak informacji w zaimportowanych danych — odśwież folder z oryginalnymi kartami.')))
  tree.bind('<<TreeviewSelect>>',selected)
  tree.bind('<ButtonRelease-1>',lambda e:tree.after_idle(selected),add='+')
  tree.bind('<KeyRelease>',lambda e:tree.after_idle(selected),add='+')

  wc=('Rok / tydzień','Zakres dat','N (KP)','A','B','PN','T przed odl.','T odlicz.','T po odl.','Dni offshore','Urlop (h)','Razem godziny')
  wt=self.table(weekly,wc,{
   'Rok / tydzień':137,'Zakres dat':215,'N (KP)':69,'A':53,'B':53,'PN':53,
   'T przed odl.':105,'T odlicz.':96,'T po odl.':91,
   'Dni offshore':120,'Urlop (h)':84,'Razem godziny':136},fixed_columns=True,fill_available_width=True,
   fill_weights={'Rok / tydzień':5,'Zakres dat':8,'N (KP)':1,'A':1,'B':1,'PN':1,'T przed odl.':1,'T odlicz.':1,'T po odl.':1,'Dni offshore':2,'Urlop (h)':1,'Razem godziny':2})
  # A WEEK row is the only clickable link. There are no extra blue card rows.
  # When multiple distinct original work cards cover the week, ask the user
  # which file to open instead of choosing an arbitrary workbook.
  week_card_items={}
  def open_week_card(event=None):
   if event is None:
    selected=wt.selection()
    iid=selected[0] if selected else None
   else:
    if wt.identify_region(event.x,event.y)!='cell':
     return
    iid=wt.identify_row(event.y)
   source_cards=week_card_items.get(iid)
   if not source_cards:return
   if len(source_cards)==1:
    self._open_original_card(source_cards[0])
   else:
    self.choose_week_card(source_cards)
  wt.bind('<ButtonRelease-1>',open_week_card,add='+')
  wt.bind('<Return>',open_week_card,add='+')
  weeks=defaultdict(list)
  for r in rows:
   d=dt.date.fromisoformat(r['date']);y,w,_=d.isocalendar();weeks[(y,w)].append(r)
  # Sumy miesięcy rozliczeniowych, według mapowania tygodni pracodawcy.
  current_month=None
  month_totals=[0.0]*10
  def add_month_total():
   if current_month is None:return
   yy,mm=current_month.split('-')
   label=self.tr(f'SUMA: {MONTHS[int(mm)-1]}')
   vals=[label,'']+[f'{x:g}' for x in month_totals]
   wt.insert('','end',values=vals,tags=('total',))
  for (y,w),items in sorted(weeks.items()):
   monday=dt.date.fromisocalendar(y,w,1);sunday=monday+dt.timedelta(days=6)
   month_id=next((f'{y}-{int(m):02d}' for m,weeklist in calendar_for(self.db,y).items() if w in weeklist),None)
   if month_id!=current_month:
    add_month_total()
    current_month=month_id
    month_totals=[0.0]*10
   sums={k:sum(float(r.get(k,0)) for r in items) for k in ['N','A','B','PN','P','T']}
   off=len({r['date'] for r in items if r.get('work_type')==9})
   week_travel=[sum(v[i] for day,v in travel_days.items() if monday<=dt.date.fromisoformat(day)<=sunday) for i in range(3)]
   total=sums['N']+sums['A']+sums['B']+week_travel[2]
   week_leave=sum(h for day,h in leave_days.items() if monday<=dt.date.fromisoformat(day)<=sunday)
   vals=[sums['N'],sums['A'],sums['B'],sums['PN'],*week_travel,off,week_leave,total]
   if month_id is not None:
    month_totals=[x+y for x,y in zip(month_totals,vals)]
   iid=wt.insert('','end',values=[f'{y} / W{w:02d}',f'{monday:%d.%m.%Y} – {sunday:%d.%m.%Y}']+[f'{x:g}' for x in vals])
   # The entire aggregated row opens its original Excel source on one click.
   sources=defaultdict(list)
   for row in items:
    key=row.get('source_path') or row.get('file_id') or row.get('file','')
    sources[key].append(row)
   week_card_items[iid]=sorted(sources.values(),
       key=lambda group:str(group[0].get('file','')).casefold())
  add_month_total()
  self.label(weekly,('Click any week row to open its Excel work card.' if self.language=='en' else 'Kliknij w dowolne miejsce wiersza tygodnia, aby otworzyć kartę pracy w Excelu.'),10,MUTED).pack(anchor='w',padx=12,pady=8)
 def show_a1(self):
  pane=self.frame();pane.pack(fill='both',expand=True)
  a1_header=tk.Frame(pane,bg=NAVY)
  a1_header.pack(fill='x',padx=0,pady=(0,5))
  titlebar=tk.Frame(a1_header,bg=NAVY);titlebar.pack(fill='x',padx=14,pady=(8,5))
  self.language_flags(titlebar)
  self.label(titlebar,'ZESTAWIENIE A1 — POBYT W KRAJACH',16,GOLD,True).pack(side='left')
  self.label(a1_header,('A1: potwierdzone kraje z KP + szacowany pobyt pomiędzy wpisami. Nieustalone dni liczymy osobno, bez przypisywania do Polski.' if self.language=='pl' else 'A1: card countries plus estimated residence between assignments. Unresolved dates remain separate from Poland.'),10,MUTED,wraplength=1000).pack(anchor='w',padx=14,pady=(0,10))
  controls=tk.Frame(pane,bg=PANEL);controls.pack(fill='x',padx=14,pady=5)
  self.a1_mode=tk.StringVar(value=getattr(self,'a1_last_mode','year'))
  self.a1_year=tk.StringVar(value=str(getattr(self,'a1_last_year',self.month.get()[:4])))
  self.a1_start=tk.StringVar(value=getattr(self,'a1_last_start',f'{self.a1_year.get()}-01-01'))
  self.a1_end=tk.StringVar(value=getattr(self,'a1_last_end',f'{self.a1_year.get()}-12-31'))
  tk.Radiobutton(controls,text='Cały rok',variable=self.a1_mode,value='year',bg=PANEL,fg=WHITE,selectcolor=PANEL2,activebackground=PANEL,activeforeground=WHITE).grid(row=0,column=0,sticky='w',padx=5)
  tk.Radiobutton(controls,text='Zakres dat',variable=self.a1_mode,value='range',bg=PANEL,fg=WHITE,selectcolor=PANEL2,activebackground=PANEL,activeforeground=WHITE).grid(row=0,column=1,sticky='w',padx=5)
  self.label(controls,'Rok:',10,WHITE).grid(row=0,column=2,padx=(20,4));ttk.Combobox(controls,textvariable=self.a1_year,values=[str(y) for y in range(2020,2041)],width=8).grid(row=0,column=3,padx=5)
  self.label(controls,'Od (RRRR-MM-DD):',10,WHITE).grid(row=1,column=0,padx=5,pady=10,sticky='w')
  tk.Entry(controls,textvariable=self.a1_start,width=15).grid(row=1,column=1,padx=5,sticky='w')
  self.label(controls,'Do:',10,WHITE).grid(row=1,column=2,padx=5,sticky='e')
  tk.Entry(controls,textvariable=self.a1_end,width=15).grid(row=1,column=3,padx=5,sticky='w')
  # Buttons share one horizontal row, equal dimensions and 2 cm gap (~76 px at 96 DPI).
  actions_a1=tk.Frame(controls,bg=PANEL)
  actions_a1.grid(row=1,column=4,columnspan=2,sticky='w',padx=15)
  self.button(actions_a1,'PRZELICZ A1',lambda:render(),GREEN).pack(side='left')

  area=tk.Frame(pane,bg=PANEL);area.pack(fill='both',expand=True,padx=7,pady=5)
  cols=('Kraj','Liczba dni')
  tree=self.table(area,cols,{'Kraj':390,'Liczba dni':190})
  export_state={'period':None,'rows':[],'warning':''}
  def export_a1():
   if not export_state['period']:
    messagebox.showwarning('A1','Najpierw przelicz zestawienie.');return
   start,end=export_state['period']
   filename=f'Zestawienie_A1_{start:%Y%m%d}_{end:%Y%m%d}.xlsx'
   path=filedialog.asksaveasfilename(title='Eksport zestawienia A1',defaultextension='.xlsx',
      initialfile=filename,filetypes=[('Excel (*.xlsx)','*.xlsx')])
   if not path:return
   try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    wb=Workbook();ws=wb.active;ws.title='Zestawienie A1'
    ws.append(['ZESTAWIENIE A1 — POBYT W KRAJACH'])
    ws.append([f'Okres: {start:%d.%m.%Y} – {end:%d.%m.%Y}'])
    ws.append([])
    ws.append(['Kraj','Liczba dni'])
    for country,days in export_state['rows']:ws.append([country,days])
    ws.append([]);ws.append([export_state['warning']])
    ws.column_dimensions['A'].width=49;ws.column_dimensions['B'].width=19
    for row_num in (1,4):
     for cell in ws[row_num][:2]:
      cell.fill=PatternFill('solid',fgColor='153451')
      cell.font=Font(name='Calibri',size=14 if row_num==1 else 11,bold=True,color='FFFFFF')
    for row in ws.iter_rows(min_row=5,max_row=4+len(export_state['rows'])):
     if row[0].value in ('POLSKA','ŁĄCZNIE DNI W OKRESIE','RAZEM ZA GRANICĄ','DO USTALENIA','Unresolved'):
      for c in row:c.fill=PatternFill('solid',fgColor='DCEAF4');c.font=Font(bold=True)
     row[1].alignment=Alignment(horizontal='right')
    ws.freeze_panes='A5'
    if export_state.get('inferred'):
     inferred_sheet=wb.create_sheet('Szacowane dni')
     inferred_sheet.append(['Data','Kraj','Źródło przypisania'])
     for day,country in export_state['inferred'].items():
      inferred_sheet.append([day.strftime('%d.%m.%Y'),country,'Ciągłość delegacji — szacunek'])
     inferred_sheet.freeze_panes='A2'
     inferred_sheet.auto_filter.ref=f'A1:C{inferred_sheet.max_row}'
     for col,width in {'A':19,'B':25,'C':40}.items():
      inferred_sheet.column_dimensions[col].width=width
    if export_state.get('audit'):
     review=wb.create_sheet('Do weryfikacji')
     review.append(['Data','Powód','Kraj (ujednolicony)','Kraj z karty','Karta / plik','Wiersz Excel','Ścieżka do pliku'])
     for entry in export_state['audit']:
      review.append([entry['date'].strftime('%d.%m.%Y'),entry['reason'],entry['country'] or 'BRAK',
                     entry['raw_country'] or '',entry['file'],entry['row'],entry['source_path']])
     review.freeze_panes='A2'
     review.auto_filter.ref=f'A1:G{review.max_row}'
     for col,width in {'A':15,'B':22,'C':24,'D':23,'E':34,'F':16,'G':68}.items():
      review.column_dimensions[col].width=width
     for cell in review[1]:
      cell.fill=PatternFill('solid',fgColor='153451')
      cell.font=Font(name='Calibri',bold=True,color='FFFFFF')
    wb.save(path)
    messagebox.showinfo('Eksport A1','Zapisano zestawienie w pliku Excel.')
   except Exception as exc:messagebox.showerror('Błąd eksportu',str(exc))
  # Explicit widths ensure identical button dimensions despite different captions.
  for widget in actions_a1.winfo_children():
   widget.configure(width=19)
  export_btn=self.button(actions_a1,'EKSPORT DO EXCELA',export_a1,PANEL2)
  export_btn.configure(width=19)
  export_btn.pack(side='left',padx=(76,0))

  warnings=tk.StringVar(value='')
  warning_line=tk.Frame(pane,bg=PANEL);warning_line.pack(fill='x',padx=14,pady=(5,14))
  warning_label=tk.Label(warning_line,textvariable=warnings,bg=PANEL,fg=MUTED,font=('Segoe UI',10),
           anchor='w',justify='left',wraplength=800,cursor='hand2')
  warning_label.pack(side='left',fill='x',expand=True)
  def show_a1_review():
   self.show_a1_audit(export_state.get('audit',[]),export_state['period']) if export_state['period'] else None
  warning_label.bind('<Button-1>',lambda _e:show_a1_review())
  review_button=self.button(warning_line,'Pokaż daty do weryfikacji',show_a1_review,PANEL2)
  review_button.pack(side='right',padx=(10,0))
  review_button.configure(state='disabled')

  def render():
   try:
    if self.a1_mode.get()=='year':
     year=int(self.a1_year.get());start=dt.date(year,1,1);end=dt.date(year,12,31)
    else:start=dt.date.fromisoformat(self.a1_start.get().strip());end=dt.date.fromisoformat(self.a1_end.get().strip())
    if end<start:raise ValueError('Data końcowa nie może być wcześniejsza niż początkowa')
    self.a1_last_mode=self.a1_mode.get();self.a1_last_year=self.a1_year.get();self.a1_last_start=self.a1_start.get();self.a1_last_end=self.a1_end.get()
    # Only enabled cards contribute to the A1 report, as in payroll summaries.
    report=a1_audit([r for r in self.db['rows'] if supported_date(r.get('date'))],start,end,self.db.get('excluded_files',[]),self.db.get('files',{}))
    tree.delete(*tree.get_children())
    for country,days in report['counts']:
     tree.insert('','end',values=(self.tr(country),days))
    tree.insert('','end',values=(self.tr('POLSKA'),report['poland']),tags=('poland',))
    if report['unresolved']:
     tree.insert('','end',values=(('Unresolved' if self.language=='en' else 'DO USTALENIA'),report['unresolved']),tags=('total',))
    tree.insert('','end',values=(self.tr('ŁĄCZNIE DNI W OKRESIE'),report['total']),tags=('total',))
    tree.insert('','end',values=(self.tr('RAZEM ZA GRANICĄ'),report['foreign']),tags=('total',))
    warnings.set((f'Estimated automatically: {len(report["inferred"])} dates; unresolved: {report["unresolved"]}, conflicts: {report["conflict_count"]}.' if self.language=='en' else
                  f'Przypisano z ciągłości delegacji: {len(report["inferred"])} dni (szacunek). Do ustalenia: {report["unresolved"]} dni, konflikty: {report["conflict_count"]}.'))
    export_state['period']=(start,end)
    export_state['rows']=[(tree.item(i,'values')[0],int(tree.item(i,'values')[1])) for i in tree.get_children()]
    export_state['warning']=warnings.get()
    export_state['audit']=report['details']
    export_state['inferred']=report['inferred']
    review_button.configure(state='normal' if report['details'] else 'disabled')
   except (ValueError,OverflowError) as exc:messagebox.showerror('Nieprawidłowy okres',str(exc))
  render()
 def show_a1_audit(self, records, period):
  """Source-level A1 review. Never assigns a country automatically."""
  if not records:
   messagebox.showinfo(self.tr('Weryfikacja A1'),self.tr('Nie znaleziono wpisów wymagających weryfikacji.'))
   return
  start,end=period
  win=tk.Toplevel(self.root)
  theme_popup(win,self,keep_visible=True,popup_surface='main')
  schedule_navy_titlebar(win,background=NAVY,foreground="#ffffff")
  win.title(self.tr('DO WERYFIKACJI — DATY I KARTY PRACY'))
  win.geometry('1230x650')
  win.minsize(800,420)
  win.configure(bg=NAVY)
  win.transient(self.root)
  heading=tk.Frame(win,bg=NAVY);heading.pack(fill='x',padx=18,pady=(14,6))
  self.label(heading,'DO WERYFIKACJI — DATY I KARTY PRACY',14,GOLD,True).pack(anchor='w')
  self.label(win,f'{start:%d.%m.%Y} – {end:%d.%m.%Y}',10,MUTED).pack(anchor='w',padx=18)
  self.label(win,'Konflikty i nieustalone daty wymagają potwierdzenia. Pusty dzień bez karty nie ma źródłowego wiersza Excel.',10,MUTED,wraplength=1150).pack(anchor='w',padx=18,pady=(5,10))
  frame=tk.Frame(win,bg=PANEL);frame.pack(fill='both',expand=True,padx=14,pady=6)
  cols=('Data','Powód','Kraj (ujednolicony)','Kraj z karty','Karta / plik','Wiersz Excel','Ścieżka do pliku')
  tree=ttk.Treeview(frame,columns=cols,show='headings',selectmode='browse',style='Audit.Treeview')
  widths=(105,130,150,135,225,95,350)
  for col,width in zip(cols,widths):
   tree.heading(col,text=self.tr(col));tree.column(col,width=width,minwidth=75,anchor='w',stretch=False)
  sy=ttk.Scrollbar(frame,orient='vertical',command=tree.yview)
  sx=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview)
  tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
  sy.pack(side='right',fill='y');sx.pack(side='bottom',fill='x')
  tree.pack(side='left',fill='both',expand=True)
  light=self.theme_mode=='light'
  tree.tag_configure('even',background='#eff5fa' if light else '#10293c',foreground='#193047' if light else WHITE)
  tree.tag_configure('odd',background='#e2edf5' if light else '#193a51',foreground='#193047' if light else WHITE)
  items={}
  for index,entry in enumerate(records):
   row=entry['source']
   path=self._original_card_path([row])
   iid=tree.insert('','end',tags=('even' if index%2==0 else 'odd',),
      values=(entry['date'].strftime('%d.%m.%Y'),self.tr(entry['reason']),
      self.tr(entry['country']) if entry['country'] else self.tr('Brak kraju'),
      entry['raw_country'] or '—',entry['file'],entry['row'],str(path) if path else entry['source_path'] or '—'))
   items[iid]=row
  def open_selected(_=None):
   selection=tree.selection()
   if selection:self._open_original_card([items[selection[0]]])
  tree.bind('<Double-1>',open_selected)
  tree.bind('<Return>',open_selected)
  buttons=tk.Frame(win,bg=NAVY);buttons.pack(fill='x',padx=14,pady=(4,12))
  self.label(buttons,'Dwukrotne kliknięcie wiersza otworzy źródłową kartę Excel.',10,MUTED).pack(side='left')
  self.button(buttons,'Zamknij',win.destroy,PANEL2).pack(side='right',padx=(9,0))
  self.button(buttons,'Otwórz kartę w Excelu',open_selected,GREEN).pack(side='right')

 def show_calendar(self):
  outer=self.frame();outer.pack(fill='both',expand=True)
  light=self.theme_mode=='light'
  page_bg='#f7f9fc' if light else NAVY
  tile_bg='#ffffff' if light else PANEL2
  border_color='#b9ccdc' if light else '#476079'
  header_bg='#d9e7f2' if light else '#24455c'
  header_fg='#173f61' if light else WHITE
  work_a='#eef4fa' if light else '#24445b'
  work_b='#e1ecf5' if light else '#31546a'
  saturday_bg='#cfdbe6' if light else '#31546a'
  saturday_fg='#35556e' if light else '#e8ae83'
  outer.configure(bg=page_bg)
  head=tk.Frame(outer,bg=page_bg);head.pack(fill='x',padx=12,pady=(6,8))
  self.language_flags(head)
  tk.Label(head,text=self.tr('KALENDARZ OKRESÓW ROZLICZENIOWYCH'),font=('Segoe UI',16,'bold'),bg=page_bg,fg=GOLD).pack(side='left')
  yr=int(getattr(self,'calendar_selected_year',int(self.month.get()[:4])))
  self.calendar_selected_year=yr
  cfg=calendar_for(self.db,yr);self.calendar_vars={}
  # Only new control: year selection. Preserve every existing calendar tile,
  # its colors, layout, date badges and CSV/editing actions unchanged.
  year_selector=tk.StringVar(value=str(yr))
  def choose_calendar_year(_event=None):
   try: selected=int(year_selector.get())
   except ValueError:return
   if selected!=self.calendar_selected_year:
    self.calendar_selected_year=selected
    self.show('Kalendarz')
  year_box=ttk.Combobox(head,textvariable=year_selector,
      values=('2024','2025','2026'),width=7,state='readonly',font=('Segoe UI',11))
  year_box.pack(side='right',padx=(6,16),pady=(3,0))
  year_box.bind('<<ComboboxSelected>>',choose_calendar_year)
  self.label(head,'Rok:',10,MUTED).pack(side='right',pady=(3,0))
  info_fg='#456279' if light else MUTED
  tk.Label(outer,text=f'Rok ISO {yr}  •  Każdy kolorowy pasek oznacza tydzień przypisany do miesiąca rozliczeniowego. Przewijaj w pionie i poziomie.',font=('Segoe UI',10),bg=page_bg,fg=info_fg).pack(anchor='w',padx=12,pady=(0,8))
  viewport=tk.Frame(outer,bg=page_bg);viewport.pack(fill='both',expand=True,padx=8)
  canvas=tk.Canvas(viewport,bg=page_bg,highlightthickness=0)
  self.calendar_canvas=canvas
  sy=ttk.Scrollbar(viewport,orient='vertical',command=canvas.yview)
  sx=ttk.Scrollbar(viewport,orient='horizontal',command=canvas.xview)
  canvas.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
  canvas.pack(side='left',fill='both',expand=True)
  def sync_calendar_scroll():
   w=content.winfo_reqwidth();h=content.winfo_reqheight()
   nx=w>canvas.winfo_width()+2;ny=h>canvas.winfo_height()+2
   if nx and not sx.winfo_manager():sx.pack(side='bottom',fill='x',before=canvas)
   elif not nx and sx.winfo_manager():sx.pack_forget();canvas.xview_moveto(0)
   if ny and not sy.winfo_manager():sy.pack(side='right',fill='y',before=canvas)
   elif not ny and sy.winfo_manager():sy.pack_forget();canvas.yview_moveto(0)
  content=tk.Frame(canvas,bg=page_bg)
  win=canvas.create_window((0,0),window=content,anchor='nw')
  content.bind('<Configure>',lambda e:(canvas.configure(scrollregion=canvas.bbox('all')),self.root.after_idle(sync_calendar_scroll)))
  canvas.bind('<Configure>',lambda e:self.root.after_idle(sync_calendar_scroll))
  # Three wide columns stay legible even when the application is made narrow.
  for col in range(3):content.grid_columnconfigure(col,minsize=385)
  def wheel(e):
   if e.state & 1:canvas.xview_scroll(-int(e.delta/120) if e.delta else 0,'units')
   else:canvas.yview_scroll(-int(e.delta/120) if e.delta else 0,'units')
  # Global mouse-wheel routing in App handles this nested calendar canvas.

  daynames=['Pn','Wt','Śr','Cz','Pt','So','Nd']
  for i,name in enumerate(MONTHS,1):
   rr=(i-1)//3;cc=(i-1)%3
   tile=tk.Frame(content,bg=tile_bg,highlightbackground=border_color,highlightthickness=1)
   tile.grid(row=rr,column=cc,padx=8,pady=8,sticky='nsew')
   tk.Label(tile,text=f'{i:02d}  {self.tr(name).upper()}',bg=tile_bg,fg=GOLD,font=('Segoe UI',13,'bold'),anchor='w').pack(fill='x',padx=12,pady=(9,3))
   weeks=cfg.get(str(i),[])
   if weeks:
    first=dt.date.fromisocalendar(yr,min(weeks),1);last=dt.date.fromisocalendar(yr,max(weeks),7)
    self.label(tile,f'{first:%d.%m.%Y}  –  {last:%d.%m.%Y}  |  {len(weeks)} tyg.',10,MUTED).pack(anchor='w',padx=12,pady=(0,7))
   else:self.label(tile,'Nie przypisano tygodni',10,MUTED).pack(anchor='w',padx=12,pady=(0,7))
   board=tk.Frame(tile,bg=tile_bg);board.pack(fill='x',padx=12)
   for j,d in enumerate(['Tydz.']+daynames):
    tk.Label(board,text=d,bg=header_bg,fg=header_fg,font=('Segoe UI',9,'bold'),width=5).grid(row=0,column=j,sticky='ew',padx=1,pady=1)
   for rid,w in enumerate(weeks,1):
    monday=dt.date.fromisocalendar(yr,w,1)
    tk.Label(board,text=f'W{w:02d}',bg=GOLD,fg=NAVY,font=('Segoe UI',9,'bold'),width=5).grid(row=rid,column=0,sticky='ew',padx=1,pady=1)
    for d in range(7):
     day=monday+dt.timedelta(days=d)
     kind=day_category(day)
     bg=({'holiday':'#9e3440','company':'#b57b18','sunday':'#8a4a55','saturday':saturday_bg}.get(kind, work_b if rid%2 else work_a) if light else {'holiday':'#842E31','company':'#AD6B14','sunday':'#6F323B','saturday':'#31546a'}.get(kind, '#31546a' if rid%2 else '#24445b'))
     fg='#ffffff' if kind in ('holiday','company','sunday') else (saturday_fg if kind=='saturday' else '#173f61' if light else WHITE)
     cell=tk.Label(board,text=str(day.day),bg=bg,fg=fg,font=('Segoe UI',9,'bold' if kind!='workday' else 'normal'),width=5,cursor='hand2')
     cell.grid(row=rid,column=d+1,sticky='ew',padx=1,pady=1)
     def show_day(_ev,actual=day):
      messagebox.showinfo(actual.strftime('%d.%m.%Y'),day_description(actual,self.language),parent=self.root)
     cell.bind('<Button-1>',show_day)
   tk.Label(tile,text=self.tr('Tygodnie ISO (edytuj):'),bg=tile_bg,fg=info_fg,font=('Segoe UI',9)).pack(anchor='w',padx=12,pady=(8,1))
   v=tk.StringVar(value=','.join(map(str,weeks)));self.calendar_vars[i]=v
   tk.Entry(tile,textvariable=v,font=('Segoe UI',10),bg='#ffffff' if light else '#edf3f7',fg=NAVY,highlightthickness=1 if light else 0,highlightbackground=border_color).pack(fill='x',padx=12,pady=(0,12))
  legend=(('Red: statutory holiday/Sunday  •  Amber: employer day off  •  Grey: Saturday  •  Click a date for details' if self.language=='en' else 'Czerwony: święto/niedziela  •  Złoty: dzień wolny firmy  •  Szary: sobota  •  Kliknij datę, aby sprawdzić jej rodzaj'))
  tk.Label(outer,text=legend,font=('Segoe UI',10),bg=page_bg,fg=info_fg,wraplength=1030).pack(anchor='w',padx=20,pady=(4,0))
  footer=tk.Frame(outer,bg=page_bg);footer.pack(fill='x',padx=12,pady=10)
  self.button(footer,'Zapisz kalendarz',lambda:self.save_calendar(yr)).pack(side='left',padx=(0,10))
  self.button(footer,'Import CSV',lambda:self.import_calendar_csv(yr),PANEL2).pack(side='left',padx=(0,10))
  self.button(footer,'Eksport CSV',lambda:self.export_calendar_csv(yr),PANEL2).pack(side='left')
 def parse_calendar(self):
  result={};all_weeks=[]
  for m,v in self.calendar_vars.items():
   weeks=[]
   for part in v.get().replace(' ','').split(','):
    if not part:continue
    if '-' in part:
     a,b=map(int,part.split('-',1));weeks+=list(range(a,b+1))
    else:weeks.append(int(part))
   result[str(m)]=weeks;all_weeks+=weeks
  if len(all_weeks)!=len(set(all_weeks)):raise ValueError('Jeden tydzień przypisany do kilku miesięcy')
  return result
 def save_calendar(self,year):
  try:
   result=self.parse_calendar();expected=set(range(1,dt.date(year,12,28).isocalendar().week+1));got={w for arr in result.values() for w in arr}
   if got!=expected:raise ValueError('Brakujące lub nieprawidłowe tygodnie: '+str(sorted(expected-got))+' / '+str(sorted(got-expected)))
   self.db.setdefault('calendars',{})[str(year)]=result;save(self.db);messagebox.showinfo('Zapisano','Kalendarz zapisany. Rozliczenia będą korzystały z nowego podziału.');self.show('Kalendarz')
  except Exception as e:messagebox.showerror('Błąd kalendarza',str(e))
 def export_calendar_csv(self,year):
  path=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSV','*.csv')]);
  if not path:return
  with open(path,'w',encoding='utf-8-sig',newline='') as f:
   w=csv.writer(f,delimiter=';');w.writerow(['Rok ISO','Miesiąc','Tydzień ISO'])
   for m,ws in calendar_for(self.db,year).items():
    for week in ws:w.writerow([year,m,week])
 def import_calendar_csv(self,year):
  path=filedialog.askopenfilename(filetypes=[('CSV','*.csv')]);
  if not path:return
  try:
   with open(path,encoding='utf-8-sig',newline='') as f:
    reader=csv.DictReader(f,delimiter=';');out={str(m):[] for m in range(1,13)}
    for r in reader:
     if int(r['Rok ISO'])!=year:continue
     out[str(int(r['Miesiąc']))].append(int(r['Tydzień ISO']))
   for m,ws in out.items():self.calendar_vars[int(m)].set(','.join(map(str,ws)))
   self.save_calendar(year)
  except Exception as e:messagebox.showerror('Błąd importu CSV',str(e))
 def apply_settings(self):
  try:
   values={k:float(v.get().replace(' ','').replace(',','.')) for k,v in self.vars.items() if k!='social_limit'}
   if any(not math.isfinite(value) for value in values.values()):
    raise ValueError('Ustawienia muszą zawierać skończone liczby — NaN i nieskończoność są niedozwolone.')
   if values['salary']<=0:raise ValueError('Pensja podstawowa musi być dodatnia')
   special_values={k:values.pop(k) for k in SPECIAL_FIELDS}
   from special_payments import amount as validate_payment
   special_values={key:validate_payment(value) for key,value in special_values.items()}
   if values.get('pit_relief') not in (0.,100.,150.,300.):
    raise ValueError('PIT-2: wpisz 0, 100, 150 lub 300 zł zgodnie ze swoim oświadczeniem.')
   for toggle in ('ppe_auto_enabled','ppo_auto_enabled','benefits_in_social','employer_pension_taxable'):
    if values.get(toggle,0) not in (0,1):raise ValueError('W tym polu wpisz 1 (tak) lub 0 (nie): '+toggle)
   for field in ('car_bonus_count','shared_room_nights','domestic_diet_extra_days','risk_days'):
    value=values.get(field,0)
    if value<0 or not value.is_integer():raise ValueError('Liczba dni i zdarzeń musi być nieujemną liczbą całkowitą: '+field)
   # These two legacy keys remain for older data compatibility only, never editable.
   year,month=map(int,self.month.get().split('-'))
   self.db['auto_nominal']=1.
   self.db['nominal']=nominal_for_calendar_month(year,month,self.db)
   previous_source=(self.db.get('auto_root'),int(self.db.get('auto_import',1)))
   self.db['auto_root']=self.auto_folder_var.get().strip();self.db['auto_import']=int(self.auto_enabled_var.get())
   source_changed=previous_source!=(self.db['auto_root'],self.db['auto_import'])
   save_month_version(self.db,self.month.get(),values)
   save_special_month(self.db,self.month.get(),special_values)
   save(self.db);self.show('Ustawienia')
   # Changing salary is not a reason to rehash every Excel workbook.
   # If the source folder changed, use the existing safe background sync.
   if source_changed and self.db['auto_import']:
    self.root.after(40,self._auto_import_on_start)
   messagebox.showinfo(self.tr('Zapisano'),('Settings effective from '+self.month.get() if self.language=='en' else 'Zapisano ustawienia obowiązujące od '+self.month.get()+'. Poprzednie okresy zachowują własne wartości.'),parent=self.root)
  except ValueError as e:messagebox.showerror('Błędne dane',str(e))
 def save_special_from_simulator(self,period,eu_c,zfss):
  """Explicit save for manual supplements; a simulator calculation never saves."""
  from special_payments import amount
  payload={'eu_c_allowance':amount(eu_c),'zfss_cash':amount(zfss)}
  save_special_month(self.db,period,payload)
  save(self.db)
  # Re-render the active period without changing other months or work cards.
  self.show(self.page)
  return payload
 def import_paths(self,paths):
  # Same synchronization rules for manual files and automatic folder imports.
  # This also upgrades cards cached by earlier versions of the program.
  changed,imported,errors=self._sync_paths([Path(p) for p in paths])
  self.show(self.page)
  messagebox.showinfo('Import',f'Zaimportowano: {imported}\nZaktualizowano: {changed}'+('\nBłędy:\n'+'\n'.join(errors[:8]) if errors else ''))
 def add_files(self):
  paths=filedialog.askopenfilenames(filetypes=[('Karty Excel','*.xlsx')]);
  if paths:self.import_paths(paths)
 def _apply_auto_folder_selection(self):
  """Persist and import work cards independently of salary-form validation.

  Triggered by choosing a folder or editing its path. Never calls
  apply_settings(): an empty/invalid salary must not block the import.
  """
  path=self.auto_folder_var.get().strip()
  if path==self.db.get('auto_root',''):
   return
  self.db['auto_root']=path
  self.db['auto_import']=int(self.auto_enabled_var.get())
  save(self.db)
  if path and self.db['auto_import']:
   self._auto_import_for_year(silent=False)

 def _on_auto_import_toggle(self):
  self.db['auto_root']=self.auto_folder_var.get().strip()
  self.db['auto_import']=int(self.auto_enabled_var.get())
  save(self.db)
  if self.db['auto_import'] and self.db['auto_root']:
   self._auto_import_for_year(silent=False)

 def _browse_auto_root(self):
  path=filedialog.askdirectory(title='Wybierz folder główny Karta pracy',initialdir=self.db.get('auto_root') or None)
  if path:
   self.auto_folder_var.set(path)
   self._apply_auto_folder_selection()
 def _synchronize_configured(self, database):
  """Read the complete configured card collection, including earlier years.

  Always verify that the folder is readable before deleting disappeared files.
  This operation may run in a worker: never access Tk or mutate self.db here.
  """
  if database.get('auto_import',1) and database.get('auto_root'):
   paths, scanned_dirs, warnings=scan_root(database['auto_root'],year_folders=True)
   root=Path(database['auto_root']).expanduser().resolve()
   # If a previously scanned year folder disappears, do not treat it as a
   # folder full of deleted individual cards. Warn instead of losing data.
   known={Path(r['source_path']).parent for r in database.get('rows',[]) if r.get('source_path')}
   for folder in known:
    if folder!=root and root in folder.parents and folder.name.isdigit() and len(folder.name)==4 and int(folder.name)>=MIN_CARD_YEAR and not folder.exists():
     warnings.append('Nie znaleziono folderu rocznego: '+str(folder))
  elif database.get('folder'):
   paths, scanned_dirs, warnings=scan_root(database['folder'],year_folders=False)
  else:
   return {'new':0,'updated':0,'removed':0,'errors':[], 'dirty':False, 'scanned':0}, []
  _sync_start=perf_monotonic()
  report=sync_cards(database,paths,read_xlsx,scanned_dirs=scanned_dirs,allow_removals=True)
  performance_measure("card_sync",_sync_start,files=len(paths),changed=report["new"]+report["updated"]+report["removed"],errors=len(report["errors"]))
  return report,warnings

 def _enable_sync_issues(self):
  self.db['hide_sync_issues_forever']=False
  save(self.db)
  messagebox.showinfo(('Alerts enabled' if self.language=='en' else 'Powiadomienia włączone'),
                      ('Synchronization alerts will appear again when issues are found.' if self.language=='en' else 'Komunikaty synchronizacji będą ponownie wyświetlane, gdy zostaną wykryte problemy.'),parent=self.root)

 def _store_sync_issues(self,issues):
  normalized=normalize_issues(issues,self.db.get('auto_root') or self.db.get('folder') or '')
  self.db['last_sync_issues']=normalized
  save(self.db)
  return normalized

 def _show_sync_issues(self,manual=False):
  issues=self.db.get('last_sync_issues') or []
  if not issues and manual:
   messagebox.showinfo(('Synchronization report' if self.language=='en' else 'Raport synchronizacji'),
                       ('No problems were recorded during the last synchronization.' if self.language=='en' else 'Podczas ostatniej synchronizacji nie zarejestrowano problemów.'),parent=self.root)
   return
  if issues and (manual or not self.db.get('hide_sync_issues_forever',False)):
   hidden=show_sync_report(self.root,issues,language=self.language,
                           initial_hidden=bool(self.db.get('hide_sync_issues_forever',False)))
   if hidden != bool(self.db.get('hide_sync_issues_forever',False)):
    self.db['hide_sync_issues_forever']=hidden
    save(self.db)

 def _auto_import_on_start(self):
  """Sync after sign-in without freezing the application window.

  Workbook parsing/hashing occurs in a worker on an independent database
  snapshot; Tk widgets and persistence are updated in the UI thread only.
  """
  if self.db.get('auto_root') and not self.db.get('auto_import',1):return
  if not ((self.db.get('auto_import',1) and self.db.get('auto_root')) or self.db.get('folder')):
   return
  if getattr(self,'_sync_in_progress',False):return
  self._sync_in_progress=True
  results=queue.Queue(maxsize=1)
  baseline=copy.deepcopy(self.db)
  snapshot=copy.deepcopy(self.db)
  self._sync_notice=tk.Label(self.root,text=('Synchronizing work cards…' if self.language=='en' else 'Synchronizowanie kart pracy…'),
                             bg='#173c56',fg=WHITE,font=('Segoe UI',10))
  self._sync_notice.pack(side='bottom',fill='x')
  def worker():
   try:
    report,warnings=self._synchronize_configured(snapshot)
    results.put((snapshot,report,warnings,None))
   except Exception as exc:
    results.put((None,None,None,exc))
  threading.Thread(target=worker,daemon=True,name='CardFolderSync').start()
  def check():
   if not self.root.winfo_exists():return
   try:updated,report,warnings,error=results.get_nowait()
   except queue.Empty:
    self.root.after(90,check);return
   self._sync_in_progress=False
   if getattr(self,'_sync_notice',None) is not None:
    try:self._sync_notice.destroy()
    except tk.TclError:pass
    self._sync_notice=None
   if error:
    perf_record_error('card_sync',error)
    self._store_sync_issues([f'Błąd synchronizacji: {error}'])
    self._show_sync_issues()
    return
   # If the user edited imported cards, their checkboxes, or the selected
   # folder while the worker was busy, run again on the live database instead
   # of overwriting newer UI changes with a stale snapshot.
   if any(self.db.get(key)!=baseline.get(key) for key in
          ('rows','files','excluded_files','auto_root','folder','auto_import')):
    self.root.after(40,self._auto_import_on_start)
    return
   if report['dirty']:
    # Preserve settings changed by the user while the worker was reading.
    for key in ('rows','files','excluded_files','source_index'):
     self.db[key]=updated[key]
    save(self.db)
    if self.page!='Ustawienia':self.show(self.page)
   issues=warnings+report['errors']
   self._store_sync_issues(issues)
   self._show_sync_issues()
  self.root.after(90,check)

 def _auto_import_for_year(self,silent=False):
  """Refresh on demand, covering every readable year folder, not one year."""
  if not self.db.get('auto_import',1) or not self.db.get('auto_root'):return False
  report,warnings=self._synchronize_configured(self.db)
  if report['dirty']:save(self.db)
  if not silent:
   detail=f'Nowych: {report["new"]}; zmienionych: {report["updated"]}; usuniętych: {report["removed"]}.'
   issues=warnings+report['errors']
   self._store_sync_issues(issues)
   if issues:
    self._show_sync_issues(manual=True)
   else:
    messagebox.showinfo('Synchronizacja kart pracy',detail,parent=self.root)
  return bool(report['dirty'])

 def _sync_paths(self,paths):
  """Manual import: update/add files, never delete unrelated records."""
  report=sync_cards(self.db,paths,read_xlsx)
  if report['dirty']:save(self.db)
  return report['updated'],report['new'],report['errors']

 def _refresh_legacy_card_types(self):
  """Migrate cached imports using their source XLSX where possible.

  Old cached 'offshore' meant column O (at sea), never type 9.
  Until a source can be reopened, old rows retain work_type=None so their
  sea-work markers cannot generate an offshore allowance by accident.
  """
  old_rows=self.db.get('rows',[])
  pending=defaultdict(list)
  for r in old_rows:
   if 'work_type' not in r and r.get('file_id'):
    pending[r['file_id']].append(r)
  if not pending:return
  updated=[]
  replaced=set()
  for fid,old_items in pending.items():
   path=next((Path(r['source_path']) for r in old_items if r.get('source_path') and Path(r['source_path']).is_file()),None)
   if path and hashlib.sha256(path.read_bytes()).hexdigest()==fid:
    try:
     fresh=read_xlsx(path)
     if fresh:
      for r in fresh:r.update(file_id=fid,file=path.name,source_path=str(path.resolve()))
      updated.extend(fresh)
      replaced.add(fid)
    except (OSError,ValueError,zipfile.BadZipFile):
     pass
  if replaced:
   self.db['rows']=[r for r in old_rows if r.get('file_id') not in replaced]+updated
  # Ensure old legacy 'offshore' field is never interpreted as type 9.
  for r in self.db['rows']:
   if 'work_type' not in r:
    r['sea_work']=bool(r.get('offshore',False))
    r['work_type']=None
    r['offshore']=False
    r['offshore_travel']=False
    r['paid_day_off_hours']=0.
  save(self.db)

 def choose_folder(self):
  p=filedialog.askdirectory(title='Wybierz folder kart pracy')
  if p:self.db['folder']=p;save(self.db);self.refresh_folder()
 def refresh_folder(self):
  if self.db.get('auto_root') and self.db.get('auto_import',1):
   self._auto_import_for_year(silent=False)
  elif self.db.get('folder'):
   report,warnings=self._synchronize_configured(self.db)
   if report['dirty']:save(self.db)
   detail=f'Nowych: {report["new"]}; zmienionych: {report["updated"]}; usuniętych: {report["removed"]}.'
   issues=warnings+report['errors']
   self._store_sync_issues(issues)
   if issues:self._show_sync_issues(manual=True)
   else:messagebox.showinfo('Synchronizacja kart pracy',detail,parent=self.root)
  else:
   messagebox.showwarning('Folder','Najpierw wybierz folder.');return
  self.show(self.page)
 def current(self):
  m=self.month.get().strip()
  if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',m):raise ValueError('Wpisz miesiąc w formacie RRRR-MM')
  rows=self.db['rows']
  # Signature covers saved data, manual period edits and card exclusions.
  # Does not change file sync, saving or accounting_month semantics.
  key=(DATA_REVISION,id(self.db),id(rows),len(rows),
       repr(self.db.get('calendars',{})),frozenset(self.db.get('excluded_files',[])))
  if getattr(self,'_monthly_index_key',None)!=key:
   began=perf_monotonic()
   self._monthly_index=build_month_index(rows,self.db.get('excluded_files',[]),
                                          supported_date,accounting_month,self.db)
   self._monthly_index_key=key
   performance_measure('monthly_index',began,rows=len(rows))
  return list(self._monthly_index.get(m,()))
 def delete_selected(self):
  selected=self.tree.selection()
  if not selected:return
  ids={self.card_file_ids[i] for i in selected if i in self.card_file_ids}
  if not messagebox.askyesno('Potwierdź',f'Usunąć {len(ids)} kart pracy wraz ze wszystkimi ich wierszami?'):return
  self.db['rows']=[r for r in self.db['rows'] if r['file_id'] not in ids]
  for id in ids:self.db['files'].pop(id,None)
  self.db['excluded_files']=[x for x in self.db.get('excluded_files',[]) if x not in ids]
  save(self.db);self.show('Karty pracy')
 def export(self):
  rows=self.current()
  if not rows:messagebox.showwarning('Brak danych','Brak godzin do eksportu');return
  path=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSV','*.csv')]);
  if not path:return
  with open(path,'w',encoding='utf-8-sig',newline='') as f:
   keys=['date','row','N','A','B','PN','P','T','work_type','leave_code','offshore','country','job','file'];writer=csv.DictWriter(f,fieldnames=keys,delimiter=';');writer.writeheader();writer.writerows({k:r.get(k,'') for k in keys} for r in rows)
  messagebox.showinfo('Eksport','Zapisano plik CSV')
if __name__=='__main__':
 root=tk.Tk();App(root);root.mainloop()
