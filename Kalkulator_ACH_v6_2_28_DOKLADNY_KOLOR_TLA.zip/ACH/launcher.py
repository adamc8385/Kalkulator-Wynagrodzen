"""Fast startup for the ACH payroll app.

The official high-resolution KW icon is loaded from kw_icon.png, not redrawn.
The splash appears BEFORE loading heavy Excel, security and GUI libraries;
its progress is indeterminate rather than an invented percentage.
"""
import os
import queue
import sys
import threading
import traceback
from pathlib import Path

APP_ID = 'PL.ACH.KalkulatorWynagrodzen'
TITLE = 'Kalkulator wynagrodzeń'


def base():
    return Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))


def build_splash(root):
    import tkinter as tk
    w, h = 710, 405
    x = (root.winfo_screenwidth() - w) // 2
    y = (root.winfo_screenheight() - h) // 2
    root.withdraw()
    root.overrideredirect(True)
    root.geometry(f'{w}x{h}+{x}+{y}')
    root.configure(bg='#05172a')
    canvas = tk.Canvas(root, width=w, height=h, bg='#05172a',
                       highlightthickness=0, bd=0)
    canvas.pack(fill='both', expand=True)
    background = tk.PhotoImage(file=str(base() / 'startup_background.png'))
    canvas._background_image = background
    canvas.create_image(0, 0, anchor='nw', image=background)
    # Tk can display the bundled PNG directly. Subsampling keeps this stage
    # free of the Pillow import which previously delayed the startup screen.
    logo = tk.PhotoImage(file=str(base() / 'kw_icon.png')).subsample(5, 5)
    canvas._brand_logo = logo
    canvas.create_image(w//2, 116, image=logo)
    canvas.create_text(w//2, 214, text=TITLE, fill='#ffffff',
                       font=('Segoe UI', 28, 'bold'))
    canvas.create_text(w//2, 267, text='Uruchamianie programu…', fill='#f2f6f9',
                       font=('Segoe UI', 15))
    rail = (102, 316, 608, 333)
    canvas.create_rectangle(*rail, fill='#123149', outline='#d8b16b', width=2)
    bar = canvas.create_rectangle(105, 319, 210, 330, fill='#f4c85e', outline='')
    state = {'position': 105, 'direction': 1, 'running': True}

    def animate():
        if not state['running']:
            return
        state['position'] += state['direction'] * 9
        if state['position'] >= 505:
            state['position'] = 505
            state['direction'] = -1
        if state['position'] <= 105:
            state['position'] = 105
            state['direction'] = 1
        canvas.coords(bar, state['position'], 319, state['position']+100, 330)
        root.after(35, animate)

    root.after(25, animate)
    root.deiconify()
    root.update_idletasks()
    return state


def native_caption(root):
    if sys.platform != 'win32':
        return
    try:
        import ctypes
        root.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        from ctypes import byref, c_int, c_uint32, sizeof
        dark = c_int(1)
        for attribute in (20, 19):
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(
                    hwnd, attribute, byref(dark), sizeof(dark)) == 0:
                break
        navy = c_uint32(0x003C2B10)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 35, byref(navy), sizeof(navy))
        white = c_uint32(0x00FFFFFF)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 36, byref(white), sizeof(white))
    except Exception:
        pass


def main():
    from test_profile import prepare_isolated_profile
    prepare_isolated_profile("ACH")
    # Configure Windows DPI and taskbar grouping before the first Tk window.
    from ui_assets import enable_windows_hidpi
    enable_windows_hidpi(APP_ID)
    import tkinter as tk
    root = tk.Tk()
    spinner = build_splash(root)
    loaded = queue.Queue(maxsize=1)

    def load_modules():
        try:
            import ach_dialogs
            ach_dialogs.install()
            import kalkulator_wynagrodzenia as payroll
            import ach_security as security
            from ui_assets import set_window_icon
            loaded.put((payroll, security, set_window_icon, None))
        except Exception:
            loaded.put((None, None, None, traceback.format_exc()))

    threading.Thread(target=load_modules, name='PayrollStartup', daemon=True).start()

    def check_loading():
        try:
            payroll, security, set_window_icon, error = loaded.get_nowait()
        except queue.Empty:
            root.after(80, check_loading)
            return
        if error:
            raise RuntimeError(error)
        spinner['running'] = False

        def open_login():
            root.withdraw()
            root.overrideredirect(False)
            for child in root.winfo_children():
                child.destroy()
            set_window_icon(root)
            if not security.gate(root):
                root.destroy()
                return
            payroll.App(root)
            native_caption(root)

        root.after(50, open_login)

    root.after(100, check_loading)
    root.mainloop()


if __name__ == '__main__':
    try:
        main()
    except Exception:
        message = traceback.format_exc()
        try:
            logfile = Path.home() / 'ACH_START_ERROR.txt'
            logfile.write_text(message, encoding='utf-8')
            import tkinter.messagebox as mb
            mb.showerror('Kalkulator wynagrodzeń — błąd startu',
                         f'Nie udało się uruchomić programu.\n\n{logfile}\n\n{message[-900:]}')
        except Exception:
            print(message, file=sys.stderr)
