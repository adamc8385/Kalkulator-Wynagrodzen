"""v6.2.14: Company ISO overtime weeks and Settings horizontal scrolling."""
import datetime as dt
import unittest
from kalkulator_wynagrodzenia import (
    DEFAULT, App, accounting_month, nominal_for_calendar_month,
    WEEKS_2026, calendar_for,
)
from company_calendar import payroll_week_nominal, scheduled_hours

class CompanyPayrollNominal6214(unittest.TestCase):
    def test_october_2026_calendar_nominal_176_iso_overtime_period(self):
        self.assertEqual(WEEKS_2026[9], (40,44))
        self.assertEqual(nominal_for_calendar_month(2026,10),176)
        self.assertEqual(scheduled_hours(2026,10),176)  # calendar month, NOT payroll

    def test_cross_month_dates_accounted_to_october(self):
        db={'calendars':{}}
        self.assertEqual(accounting_month('2026-09-28',db),'2026-10')
        self.assertEqual(accounting_month('2026-10-30',db),'2026-10')
        self.assertEqual(accounting_month('2026-11-01',db),'2026-10')
        self.assertEqual(payroll_week_nominal(2026,range(40,45)),200)

    def test_april_holiday_reduces_firm_week_nominal(self):
        # W14–W17: Good Friday 3 April and Easter Monday 6 April
        self.assertEqual(nominal_for_calendar_month(2026,4),160)
        self.assertEqual(scheduled_hours(2026,4),160)

    def test_saved_company_calendar_overrides_default(self):
        db={'calendars':{'2026':{str(m):weeks for m,weeks in
             [(10,[40]),(11,[41,42,43,44])]}}}
        self.assertEqual(nominal_for_calendar_month(2026,10,db),176)
        self.assertEqual(nominal_for_calendar_month(2026,11,db),160)
        self.assertEqual(nominal_for_calendar_month(2026,9,db),scheduled_hours(2026,9))

    def test_unconfigured_future_year_falls_back_to_statutory(self):
        self.assertEqual(nominal_for_calendar_month(2027,10),scheduled_hours(2027,10))

    def test_deduplicate_iso_week(self):
        self.assertEqual(payroll_week_nominal(2026,[40,40]),40)

    def test_invalid_week_rejected(self):
        with self.assertRaises(ValueError):payroll_week_nominal(2025,[53])

    def test_effective_cfg_uses_custom_payroll_weeks(self):
        class Month:
            def get(self):return '2026-10'
        app=App.__new__(App)
        app.db=dict(DEFAULT)
        app.db['calendars']={'2026':{'10':[40]}}
        app.db['monthly_settings_history']={}
        app.month=Month()
        app._month_cfg_cache={}
        app._month_cfg_revision=0
        cfg=app.cfg_for_month('2026-10',_skip_progress=True)
        self.assertEqual(cfg['nominal'],176)
        self.assertEqual(app.db['nominal'],176)  # do not mutate user's saved data

    def test_rate_lookup_for_28_september_uses_october_period(self):
        class Month:
            def get(self):return '2026-10'
        app=App.__new__(App)
        app.db=dict(DEFAULT, salary=15588.78)
        app.db['rows']=[]
        app.db['monthly_settings_history']={}
        app.month=Month()
        app._month_cfg_cache={}
        app._month_cfg_revision=0
        cfg=app.cfg_for_month('2026-10',_skip_progress=False)
        self.assertAlmostEqual(cfg['_rate_for_date']('2026-09-28'),
                               15588.78/176, places=5)
        self.assertAlmostEqual(cfg['_rate_for_date']('2026-10-30'),
                               15588.78/176, places=5)

    def test_nominal_is_not_sum_of_n_on_cards(self):
        db={'rows':[{'N':182,'date':'2026-10-02'}]}
        self.assertEqual(nominal_for_calendar_month(2026,10,db),176)

if __name__ == '__main__':unittest.main()
