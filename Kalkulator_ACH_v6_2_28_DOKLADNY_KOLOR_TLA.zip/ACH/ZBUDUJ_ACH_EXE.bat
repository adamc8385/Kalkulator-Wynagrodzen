@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ACH - budowanie prywatnego EXE

echo ============================================
echo  ACH - BUDOWANIE SZYBSZEGO EXE v6.2 TEST
echo ============================================
echo.

echo [1/4] Sprawdzam Python...
py -3 --version
if errorlevel 1 goto PYTHON_ERROR

echo.
echo [2/4] Sprawdzam potrzebne biblioteki...
py -3 -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
  echo Brak PyInstaller. Instaluje...
  py -3 -m pip install pyinstaller
  if errorlevel 1 goto LIB_ERROR
)
py -3 -m pip show Pillow >nul 2>&1
if errorlevel 1 (
  echo Brak Pillow. Instaluje...
  py -3 -m pip install Pillow
  if errorlevel 1 goto LIB_ERROR
)

py -3 -m pip show reportlab >nul 2>&1
if errorlevel 1 (
 py -3 -m pip install reportlab
 if errorlevel 1 goto LIB_ERROR
)
py -3 -m pip show openpyxl >nul 2>&1
if errorlevel 1 (
 py -3 -m pip install openpyxl
 if errorlevel 1 goto LIB_ERROR
)
echo.
echo [3/4] Buduje program ACH... To moze chwile potrwac.
py -3 -m PyInstaller ^
 --noconfirm --clean --onedir --windowed ^
 --name ACH_Kalkulator_Wynagrodzenia ^
 --icon "kw_icon.ico" ^
 --distpath "GOTOWY_EXE" ^
 --workpath "_PYINSTALLER_BUILD\work" ^
 --hidden-import kalkulator_wynagrodzenia ^
 --hidden-import ach_security ^
 --hidden-import ach_dialogs ^
 --hidden-import payroll_help ^
 --hidden-import leave_pay ^
 --hidden-import leave_balance ^
 --hidden-import leave_balance_ui ^
 --hidden-import settings_history ^
 --hidden-import special_payments ^
 --hidden-import data_store ^
 --hidden-import card_sync ^
 --hidden-import forecast_ui ^
 --hidden-import forecast_tools ^
 --hidden-import forecast_pdf ^
 --hidden-import payroll_export ^
 --add-data "kw_icon.ico;." ^
 --add-data "kw_icon.png;." ^
 --add-data "startup_background.png;." ^
 --add-data "kw_splash_background.jpg;." ^
 --add-data "kw_login_clean.jpg;." ^
 --add-data "kw_approved_login.png;." ^
 --add-data "kw_registration_background.png;." ^
 --add-data "kw_approved_dialog.jpg;." ^
 --add-data "kw_gold_button.png;." ^
 --add-data "kw_status_error.png;." ^
 --add-data "kw_status_info.png;." ^
 --add-data "kw_status_question.png;." ^
 --add-data "kw_status_success.png;." ^
 --add-data "kw_status_warning.png;." ^
 --add-data "kw_login_logo.png;." ^
 --add-data "marine_header.jpg;." ^
 --add-data "marine_header_light.jpg;." ^
 --add-data "marine_header_en.jpg;." ^
 --add-data "ach_logo.jpg;." ^
 --add-data "nav_0.png;." ^
 --add-data "nav_1.png;." ^
 --add-data "nav_2.png;." ^
 --add-data "nav_3.png;." ^
 --add-data "nav_4.png;." ^
 --add-data "nav_5.png;." ^
 --add-data "nav_6.png;." ^
 --add-data "nav_7.png;." ^
 --add-data "flag_pl.png;." ^
 --add-data "flag_en.png;." ^
 --add-data "help.png;." ^
 --add-data "info.png;." ^
 --add-data "logout.png;." ^
 --add-data "calendar.png;." ^
 --add-data "folder.png;." ^
 --add-data "refresh.png;." ^
 launcher.py
if errorlevel 1 goto BUILD_ERROR

if not exist "GOTOWY_EXE\ACH_Kalkulator_Wynagrodzenia\ACH_Kalkulator_Wynagrodzenia.exe" goto BUILD_ERROR

echo.
echo [4/4] Instaluje folder aplikacji i tworze skrot na Pulpicie...
REM OneDir starts faster than OneFile and can show its splash immediately.
REM Never copy just the EXE; its _internal folder is required.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $source=Join-Path (Get-Location).Path 'GOTOWY_EXE\ACH_Kalkulator_Wynagrodzenia'; $target=Join-Path $env:LOCALAPPDATA 'KalkulatorWynagrodzen\ACH'; New-Item -ItemType Directory -Path $target -Force | Out-Null; Copy-Item -Path (Join-Path $source '*') -Destination $target -Recurse -Force; $exe=Join-Path $target 'ACH_Kalkulator_Wynagrodzenia.exe'; if (-not (Test-Path -LiteralPath $exe)) { throw 'Nie znaleziono EXE' }; $desktop=[Environment]::GetFolderPath('Desktop'); $link=Join-Path $desktop 'Kalkulator_Wynagrodzen_ACH_NOWY.lnk'; $shell=New-Object -ComObject WScript.Shell; $shortcut=$shell.CreateShortcut($link); $shortcut.TargetPath=$exe; $shortcut.WorkingDirectory=$target; $shortcut.IconLocation=$exe; $shortcut.Description='Kalkulator wynagrodzen ACH'; $shortcut.Save(); Write-Host ('Zainstalowano: '+$exe); Write-Host ('Skrot: '+$link)"
if errorlevel 1 (
 echo UWAGA: EXE zbudowano, ale nie udalo sie utworzyc skrotu.
 echo Program znajdziesz w folderze GOTOWY_EXE\ACH_Kalkulator_Wynagrodzenia.
) else (
 echo SUKCES! Uruchom skrot Kalkulator_Wynagrodzen_ACH_NOWY na Pulpicie.
)
goto DONE

:PYTHON_ERROR
echo.
echo BLAD: Nie moge znalezc Pythona. Sprawdz instalacje.
goto FAILURE

:LIB_ERROR
echo.
echo BLAD: Nie udalo sie zainstalowac bibliotek.
goto FAILURE

:BUILD_ERROR
echo.
echo BLAD: Budowanie EXE nie powiodlo sie. Zrob zdjecie komunikatu.
goto FAILURE

:DONE
echo.
echo Uruchamiaj aplikacje przez utworzony skrot na Pulpicie.
echo Twoje dane i PIN pozostaja w profilu Windows.
pause
exit /b 0

:FAILURE
pause
exit /b 1
