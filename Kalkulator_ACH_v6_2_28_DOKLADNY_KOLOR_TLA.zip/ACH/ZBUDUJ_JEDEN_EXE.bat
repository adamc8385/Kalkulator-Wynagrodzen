@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ACH - jeden przenosny plik EXE

echo ===========================================
echo  ACH - JEDEN PLIK EXE (bez _internal)
echo ===========================================
echo.
py -3 --version
if errorlevel 1 goto PYTHON_ERROR
py -3 -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
 py -3 -m pip install pyinstaller
 if errorlevel 1 goto BUILD_ERROR
)
py -3 -m pip show Pillow >nul 2>&1
if errorlevel 1 (
 py -3 -m pip install Pillow
 if errorlevel 1 goto BUILD_ERROR
)
py -3 -m pip show reportlab >nul 2>&1
if errorlevel 1 (
 py -3 -m pip install reportlab
 if errorlevel 1 goto BUILD_ERROR
)
py -3 -m pip show openpyxl >nul 2>&1
if errorlevel 1 (
 py -3 -m pip install openpyxl
 if errorlevel 1 goto LIB_ERROR
)
echo.
echo Buduje pojedynczy plik EXE. Start moze byc wolniejszy niz w trybie folderowym.
py -3 -m PyInstaller ^
 --noconfirm --clean --onefile --windowed ^
 --name ACH_Kalkulator_Wynagrodzenia ^
 --icon "kw_icon.ico" ^
 --distpath "GOTOWY_JEDEN_EXE" ^
 --workpath "_PYINSTALLER_ONEFILE\work" ^
 --hidden-import kalkulator_wynagrodzenia ^
 --hidden-import ach_security ^
 --hidden-import ach_dialogs ^
 --hidden-import payroll_help ^
 --hidden-import leave_pay ^
 --hidden-import leave_balance ^
 --hidden-import leave_balance_ui ^
 --hidden-import settings_history ^
 --hidden-import special_payments ^
 --hidden-import data_store ^
 --hidden-import card_sync ^
 --hidden-import forecast_ui ^
 --hidden-import forecast_tools ^
 --hidden-import forecast_pdf ^
 --hidden-import payroll_export ^
 --add-data "kw_icon.ico;." ^
 --add-data "kw_icon.png;." ^
 --add-data "startup_background.png;." ^
 --add-data "kw_splash_background.jpg;." ^
 --add-data "kw_login_clean.jpg;." ^
 --add-data "kw_approved_login.png;." ^
 --add-data "kw_registration_background.png;." ^
 --add-data "kw_approved_dialog.jpg;." ^
 --add-data "kw_gold_button.png;." ^
 --add-data "kw_status_error.png;." ^
 --add-data "kw_status_info.png;." ^
 --add-data "kw_status_question.png;." ^
 --add-data "kw_status_success.png;." ^
 --add-data "kw_status_warning.png;." ^
 --add-data "kw_login_logo.png;." ^
 --add-data "marine_header.jpg;." ^
 --add-data "marine_header_light.jpg;." ^
 --add-data "marine_header_en.jpg;." ^
 --add-data "ach_logo.jpg;." ^
 --add-data "nav_0.png;." ^
 --add-data "nav_1.png;." ^
 --add-data "nav_2.png;." ^
 --add-data "nav_3.png;." ^
 --add-data "nav_4.png;." ^
 --add-data "nav_5.png;." ^
 --add-data "nav_6.png;." ^
 --add-data "nav_7.png;." ^
 --add-data "flag_pl.png;." ^
 --add-data "flag_en.png;." ^
 --add-data "help.png;." ^
 --add-data "info.png;." ^
 --add-data "logout.png;." ^
 --add-data "calendar.png;." ^
 --add-data "folder.png;." ^
 --add-data "refresh.png;." ^
 launcher.py

if errorlevel 1 goto BUILD_ERROR
if not exist "GOTOWY_JEDEN_EXE\ACH_Kalkulator_Wynagrodzenia.exe" goto BUILD_ERROR
echo.
echo SUKCES: GOTOWY_JEDEN_EXE\ACH_Kalkulator_Wynagrodzenia.exe
echo Ten jeden plik mozna wyslac drugiej osobie bez folderu _internal.
echo Nie wysylaj zadnych PIN-ow, danych wynagrodzenia ani plikow bazy.
pause
exit /b 0
:PYTHON_ERROR
echo Nie znaleziono Pythona.
pause
exit /b 1
:BUILD_ERROR
echo Blad tworzenia EXE.
pause
exit /b 1
