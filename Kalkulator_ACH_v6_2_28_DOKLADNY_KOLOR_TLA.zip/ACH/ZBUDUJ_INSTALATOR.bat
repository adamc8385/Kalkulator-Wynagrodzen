@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ACH - instalator dla innych uzytkownikow

if not exist "GOTOWY_EXE\ACH_Kalkulator_Wynagrodzenia\ACH_Kalkulator_Wynagrodzenia.exe" (
 echo Najpierw buduje szybka wersje folderowa...
 call "ZBUDUJ_ACH_EXE.bat"
 if errorlevel 1 goto FAILURE
)
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
 echo.
 echo Brakuje darmowego Inno Setup 6. Zainstaluj go ze strony https://jrsoftware.org/isinfo.php
 echo Potem ponownie uruchom ten plik.
 goto FAILURE
)
"%ISCC%" "INSTALATOR.iss"
if errorlevel 1 goto FAILURE
if not exist "GOTOWY_INSTALATOR\Kalkulator_Wynagrodzen_ACH_v6_2_TEST_Setup.exe" goto FAILURE
echo.
echo SUKCES: GOTOWY_INSTALATOR\Kalkulator_Wynagrodzen_ACH_v6_2_TEST_Setup.exe
echo Wyslij znajomemu tylko ten plik instalacyjny.
echo Nie dolaczaj swoich baz, PIN-ow ani paskow placowych.
pause
exit /b 0
:FAILURE
echo.
echo Nie udalo sie utworzyc instalatora.
pause
exit /b 1
