@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ACH v6.2 TEST - osobne dane i osobny program

echo ===========================================
echo  ACH v6.2 TEST - wersja do sprawdzenia

echo ===========================================
echo Dane bazowej wersji 6.1 pozostana bez zmian.
echo Wersja testowa sama tworzy swoja kopie danych przy pierwszym starcie.
echo.
if exist "GOTOWY_JEDEN_EXE\ACH_Kalkulator_Wynagrodzenia.exe" (
  start "" "GOTOWY_JEDEN_EXE\ACH_Kalkulator_Wynagrodzenia.exe"
  exit /b 0
)
if exist "GOTOWY_EXE\ACH_Kalkulator_Wynagrodzenia\ACH_Kalkulator_Wynagrodzenia.exe" (
  start "" "GOTOWY_EXE\ACH_Kalkulator_Wynagrodzenia\ACH_Kalkulator_Wynagrodzenia.exe"
  exit /b 0
)
echo Nie znaleziono EXE. Najpierw uruchom ZBUDUJ_JEDEN_EXE.bat.
echo Jesli masz zainstalowany Python i Pillow, mozesz uruchomic launcher.py.
pause
exit /b 1
